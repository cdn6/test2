<?php
namespace app\admin\controller;
use think\Db;
use think\Config;
use think\Cache;

class Domain extends Base
{

    public function index()
    {
        $templates = glob('./template' . '/*', GLOB_ONLYDIR);
        foreach ($templates as $k => &$v) {
            $v = str_replace('./template/', '', $v);
        }
        $this->assign('templates', $templates);

        $config = config('domain');
        $this->assign('domain_list', $config);
        $this->assign('title', lang('admin/domain/title'));
        return $this->fetch('admin@domain/index');
    }

    public function newEdit()
    {
        if (Request()->isPost()) {
            $config = config('domain');
            $form = input();
            if(empty($form['site_url'])){
                return $this->error(lang('domain')."不能为空");
            }
            if(!preg_match('/^(?!.*:\/\/)(?!.*\/$)(?!-)(?!.*-$)(?!.*--)[A-Za-z0-9]+(-[A-Za-z0-9]+)*(\.[A-Za-z0-9]+(-[A-Za-z0-9]+)*)*\.[A-Za-z]{2,}(:\d+)?$/', $form['site_url'])){
                return $this->error("非法".lang('domain')."格式");
            }
            $domain = array_merge($config,[$form['site_url']=>[
                'site_url'=>$form['site_url'],
                'site_name'=>$form['site_name'],
                'site_keywords'=>$form['site_keywords'],
                'site_description'=>$form['site_description'],
                'template_dir'=>$form['template_dir'],
                'html_dir'=>$form['html_dir'],
                'ads_dir'=>$form['ads_dir'],
                'path_vod_detail'=>$form['path_vod_detail'],
                'path_vod_play'=>$form['path_vod_play'],
                'encode_id_status'=>$form['encode_id_status'],
                'random_class_status'=>$form['random_class_status'],
                'random_class_secret'=>$form['random_class_secret'],
            ]]);

            $res = mac_arr2file(APP_PATH . 'extra/domain.php', $domain);
            if ($res === false) {
                return $this->error(lang('save_err'));
            }
            return $this->success(lang('save_ok'));
        }
    }

    public function del()
    {
        $param = input();
        if(!empty($param['ids'])){
            $list = config('domain');
            unset($list[$param['ids']]);
            $res = mac_arr2file( APP_PATH .'extra/domain.php', $list);
            if($res===false){
                return $this->error(lang('del_err'));
            }
        }
        return $this->success(lang('del_ok'));
    }

    public function export()
    {
        $list = config('domain');
        $html = '';
        foreach($list as $k=>$v){
            $html .= $v['site_url'].'$'.$v['site_name'].'$'.$v['site_keywords'].'$'.$v['site_description'].'$'.$v['template_dir'].'$'.$v['html_dir'].'$'.$v['ads_dir'].'$'.$v['path_vod_detail'].'$'.$v['path_vod_play'].'$'.$v['encode_id_status'].'$'.$v['random_class_status'].'$'.$v['random_class_secret']."\n";
        }

        header("Content-type: application/octet-stream");
        header("Content-Disposition: attachment; filename=mac_domains.txt");
        echo $html;
    }

    public function import()
    {
        $file = $this->request->file('file');
        $info = $file->rule('uniqid')->validate(['size' => 10240000, 'ext' => 'txt']);
        if ($info) {
            $data = file_get_contents($info->getpathName());
            @unlink($info->getpathName());
            if($data){
                $list = explode(chr(10),$data);

                $domain =[];

                foreach($list as $k=>$v){
                    if(!empty($v)) {
                        $one = explode('$', $v);
                        $domain[$one[0]] = [
                            'site_url' => $one[0],
                            'site_name' => $one[1],
                            'site_keywords' => $one[2],
                            'site_description' => $one[3],
                            'template_dir' => $one[4],
                            'html_dir' => $one[5],
                            'ads_dir'=>$one[6],
                            'path_vod_detail'=>count($one)>=7?$one[7]:'',
                            'path_vod_play'=>count($one)>=8?$one[8]:'',
                            'encode_id_status'=>count($one)>=9?$one[9]:'',
                            'random_class_status'=>count($one)>=10?$one[10]:'',
                            'random_class_secret'=>count($one)>=11?$one[11]:'',
                        ];
                    }
                }

                $res = mac_arr2file( APP_PATH .'extra/domain.php', $domain);
                if($res===false){
                    return $this->error(lang('write_err_config'));
                }
            }
            return $this->success(lang('import_err'));
        }
        else{
            return $this->error($file->getError());
        }
    }
}
