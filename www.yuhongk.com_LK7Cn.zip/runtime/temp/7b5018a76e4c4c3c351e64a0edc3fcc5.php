<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:40:"template/niumays/html/label/loading.html";i:1656084380;}*/ ?>
<html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="renderer" content="webkit|ie-comp|ie-stand" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<meta name="robots" content="none" />
<title>loading……</title>
<link rel="shortcut icon" href="<?php echo $maccms['path_tpl']; ?>statics/img/favicon.ico" type="image/x-icon" />
</head>
<body bgcolor="#000000" oncontextmenu="return false" ondragstart="window.event.returnValue=false" onsource="event.returnValue=false">
<table width="100%" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
<td align="center">
<font color="#FFFFFF"><strong>连接成功,稍等数据正在缓冲中...</strong></font><br>
<img border="0" src="<?php echo $maccms['path_tpl']; ?>statics/img/loading.gif"><br>
<font color="#FFFFFF"><strong>如果您喜欢本站，请收藏！</strong></font><br>
<font color="#FFFFFF"><strong>本站域名请牢记：<?php echo $maccms['site_url']; ?></strong></font><br>
</td>
</tr>
</table>
</body>
</html>