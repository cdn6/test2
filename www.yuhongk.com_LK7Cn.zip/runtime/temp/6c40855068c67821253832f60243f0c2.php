<?php if (!defined('THINK_PATH')) exit(); /*a:13:{s:36:"template/fengniao/html/vod/play.html";i:1740751657;s:70:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/block/include.html";i:1740670124;s:67:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/block/seos.html";i:1740736307;s:67:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/block/head.html";i:1740670454;s:64:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/ads/gdw.html";i:1745170654;s:71:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/vod/playlist_3.html";i:1740668820;s:65:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/vod/desc.html";i:1707668470;s:65:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/vod/like.html";i:1715008306;s:70:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/block/vod_box.html";i:1696090874;s:73:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/block/side_media.html";i:1712408202;s:75:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/block/vod_box_rank.html";i:1696001562;s:67:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/block/foot.html";i:1742471357;s:63:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/ads/ad.html";i:1745170654;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<?php $tpl_version=1.1; if($maccms['aid']==1): ?><!-- 首页 -->
<title><?php echo $maccms['site_name']; ?>_蜂鸟影视_蜂鸟电影网_免费在线电影电视剧</title>
<meta name="keywords" content="<?php echo $maccms['site_name']; ?>" />
<meta name="description" content="<?php echo $maccms['site_name']; ?>为您推荐<?php echo date('Y'); ?>最新影院电影、热播电视剧、网剧免费观看，最快每天同步更新数据，更新最快最全的电影电视剧收录大全，热播好剧热映电影免费观看就上<?php echo $maccms['site_name']; ?>。" />
<?php elseif($maccms['aid']==4): ?><!-- 留言 -->
<meta name="robots" content="none" />
<title>留言板 - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="留言板" />
<meta name="description" content="这里是<?php echo $maccms['site_name']; ?>的留言板，您有什么想观看的影片可以在这里给我们留言，我们会为您寻找片源；海量电影电视剧尽在本站，喜欢请收藏！" />
<?php elseif($maccms['aid']==11): ?><!-- 分类 -->
<title><?php echo date('Y'); ?>最新<?php echo $obj['type_name']; ?>频道 - 好看的<?php echo $obj['type_name']; ?>推荐 - 第<?php echo $param['page']; ?>页 - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo date('Y'); ?>最新<?php echo $obj['type_name']; ?>" />
<meta name="description" content="<?php echo $maccms['site_name']; ?>为广大网友提供最新<?php echo $obj['type_name']; ?>、全集<?php echo $obj['type_name']; ?>、最近热播<?php echo $obj['type_name']; ?>免费观看，高清画质纵享丝滑不卡顿，第一时间更新推送最新<?php echo $obj['type_name']; ?>，在线观看无套路。" />
<?php elseif($maccms['aid']==12): ?><!-- 筛选 -->
<title><?php echo date('Y'); ?>最新<?php echo $obj['type_name']; ?>频道筛选 - 好看的<?php echo $obj['type_name']; ?>推荐 - 第<?php echo $param['page']; ?>页 - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo date('Y'); ?>最新<?php echo $obj['type_name']; ?>" />
<meta name="description" content="<?php echo $maccms['site_name']; ?>为广大网友提供最新<?php echo $obj['type_name']; ?>、全集<?php echo $obj['type_name']; ?>、最近热播<?php echo $obj['type_name']; ?>免费观看，高清画质纵享丝滑不卡顿，第一时间更新推送最新<?php echo $obj['type_name']; ?>，在线观看无套路。" />
<?php elseif($maccms['aid']==13): ?><!-- 搜索 -->
<meta name="robots" content="noindex,follow" />
<title>搜索：<?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?> - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?>" />
<meta name="description" content="搜索结果：<?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?>相关影片全集免费在线观看，高清全集完整版免费观看无删减，更多与<?php echo $param['wd']; ?>相关结果尽在<?php echo $maccms['site_name']; ?>！" />
<?php elseif($maccms['aid']==14): ?><!-- 详情 -->
<title>《<?php echo $obj['vod_name']; ?>》<?php if(($obj['type']['type_id'] == 1) || ($obj['type']['type_id'] == 57) || ($obj['type_id_1'] == 1)): ?>免费在线观看完整版<?php else: ?>免费在线观看全集<?php endif; ?> - <?php echo $obj['type']['type_name']; ?> - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo $obj['vod_name']; if(($obj['type']['type_id'] == 1) || ($obj['type']['type_id'] == 57) || ($obj['type_id_1'] == 1)): ?>免费在线观看完整版<?php else: ?>免费在线观看全集<?php endif; ?>" />
<meta name="description" content="<?php echo mac_substring($obj['vod_blurb'],140); ?>" />
<?php elseif($maccms['aid']==15): ?><!-- 播放 -->
<title>《<?php echo $obj['vod_name']; ?>》<?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?>在线播放免费观看 - <?php echo $obj['type']['type_name']; ?> - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo $obj['vod_name']; ?>在线播放免费观看" />
<meta name="description" content="<?php echo mac_substring($obj['vod_blurb'],140); ?>" />
<?php endif; ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit|ie-comp|ie-stand" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<meta http-equiv="cache-control" content="no-siteapp,no-transform" />
<meta name="applicable-device" content="pc,mobile" />
<link rel="shortcut icon" href="<?php echo $maccms['path_tpl']; ?>statics/img/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>statics/font/iconfont.css?v=<?php echo $tpl_version; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>statics/css/stui_block.css?v=<?php echo $tpl_version; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>statics/css/stui_block_color.css?v=<?php echo $tpl_version; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>statics/css/stui_default.css?v=<?php echo $tpl_version; ?>" type="text/css" />
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/jquery.min.js?v=<?php echo $tpl_version; ?>"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/stui_default.js?v=<?php echo $tpl_version; ?>"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/stui_block.js?v=<?php echo $tpl_version; ?>"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/home.js?v=<?php echo $tpl_version; ?>"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/ban.js?v=<?php echo $tpl_version; ?>"></script>
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<?php if($maccms['aid']==15): ?>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/history.js?v=<?php echo $tpl_version; ?>"></script>
<script type="text/javascript">var vod_name = '<?php echo mac_substring($obj['vod_name'],10); ?>', vod_url = window.location.href, vod_part='<?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?>';</script>
<?php elseif($maccms['aid']==4): ?>
<script>$(function(){MAC.Gbook.Login = <?php echo $gbook['login']; ?>;MAC.Gbook.Verify = <?php echo $gbook['verify']; ?>;MAC.Gbook.Init();});</script>
<?php endif; ?>
<!--[if lt IE 9]>
<script src="https://cdn.staticfile.net/html5shiv/r29/html5.min.js"></script>
<script src="https://cdn.staticfile.net/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body>
	<header class="stui-header__top clearfix">
	<div class="stui-header__bar clearfix">
		<div class="container">
			<div class="row">
				<div class="stui-header__logo">
					<a class="logo" href="<?php echo $maccms['path']; ?>"><?php echo $maccms['site_name']; ?></a>
				</div>
				<div class="stui-header__search">
					<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/jquery.autocomplete.js"></script>
					 <form id="search" name="search" method="get" action="<?php echo mac_url('vod/search'); ?>">
						<input type="text" id="wd" name="wd" class="mac_wd form-control" value="<?php echo $param['wd']; ?>" placeholder="输入片名关键词..." required="required" autocomplete="off"/>
						<button class="submit" id="searchbutton" type="submit" name="submit"><i class="icon iconfont icon-search"></i></button>
					</form>
				</div>
				<ul class="stui-header__user">
					<li class="hidden-xs">
						<a href="<?php echo mac_url('gbook/index'); ?>"><i class="icon iconfont icon-comments"></i> 求片留言</a>
					</li>
					<li>
						<a href="javascript:;"><i class="icon iconfont icon-clock"></i>  <span class="hidden-xs">播放记录</span></a>
						<div class="dropdown history">
							<h5 class="margin-0 text-muted">
								<a class="historyclean text-muted pull-right" href="">清空</a>
								播放记录
							</h5>
							<ul class="clearfix" id="stui_history"></ul>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<div class="container clearfix">
		<div class="row">
			<div class="stui-header__menu">
				<span class="more hidden-xs" style="padding-right: 20px; color: #fff;">今日更新“<?php echo mac_data_count(0,'today','vod'); ?>”条数据</span>
				<ul class="type-slide clearfix">
					<li <?php if($maccms['aid'] == 1): ?>class="active"<?php endif; ?>><a href="<?php echo $maccms['path']; ?>">首页</a></li>
					<?php $__TAG__ = '{"num":"10","order":"asc","by":"sort","ids":"parent","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
					<li <?php if(($vo['type_id'] == $GLOBALS['type_id'] || $vo['type_id'] == $GLOBALS['type_pid'])): ?>class="active"<?php endif; ?>><a href="<?php echo mac_url_type($vo); ?>"><?php echo $vo['type_name']; ?></a></li>
					<?php endforeach; endif; else: echo "" ;endif; ?>
<!--					<?php if($GLOBALS['config']['gbook']['status']==1): ?>
					<li <?php if($maccms['aid'] == 4): ?>class="active"<?php endif; ?>><a href="<?php echo mac_url('gbook/index'); ?>">留言</a></li>
					<?php endif; ?>-->
				</ul>
			</div>
		</div>
	</div>
</header>
<script type="text/javascript">
	$(".stui-header__user li,.stui-header__menu li").click(function(){
		$(this).find(".dropdown").toggle();
		if(!stui.browser.useragent.mobile){
			$(".MacPlayer").toggle();
		}
	});
</script>
	<div class="container">
		<div class="row">
			<div class="col-lg-wide-8 col-xs-1 padding-0">
				<!-- 播放器-->
				<div class="stui-pannel stui-pannel-bg clearfix">
					<div class="stui-pannel-box">
						<div class="stui-pannel-bd">
							<div class="stui-player col-pd">
								<div class="stui-player__video clearfix">
									<?php if($obj['vod_copyright'] == 1): ?>
									<div class="play_tips">
										<div class="dmca_tips">
											对不起，本片暂无版权!
										</div>
									</div>
									<?php else: ?>
									<?php echo $player_data; ?><?php echo $player_js; endif; ?>
								</div>
								<div class="line_tips">
									<?php if(is_array($obj['vod_play_list']) || $obj['vod_play_list'] instanceof \think\Collection || $obj['vod_play_list'] instanceof \think\Paginator): if( count($obj['vod_play_list'])==0 ) : echo "" ;else: foreach($obj['vod_play_list'] as $key=>$vo): if($vo['sid'] == $param['sid']): ?>
										<b>
											收藏本站网址不迷路：<?php echo $maccms['site_url']; ?>
											<!--<br>
											视频中广告勿信，卡顿不能播可在下方换源，当前源：<?php echo $vo['player_info']['show']; ?>-->
										</b>
									<?php endif; endforeach; endif; else: echo "" ;endif; ?>
								</div>
								<div class="stui-player__detail detail">
									<ul class="more-btn">
										<li>
											<a href="javascript:;" class="btn btn-default" onclick="window.location.reload()">刷新 <i class="icon iconfont icon-refresh hidden-xs"></i></a>
										</li>
										<li>
											<a class="btn btn-default copylink" href="javascript:;">分享 <i class="icon iconfont icon-share hidden-xs"></i></a>
										</li>
										<!--<li>
											<a href="javascript:;" class="btn btn-default" onclick="MAC.Gbook.Report('编号【<?php echo $obj['vod_id']; ?>】名称【<?php echo $obj['vod_name']; ?> <?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?>】不能观看请检查修复')">报错 <i class="icon iconfont icon-close hidden-xs"></i></a>
										</li>-->
										<li><a class="btn btn-default <?php if($param['nid']==1): ?>btns_disad<?php endif; ?>" href="<?php echo $obj['player_info']['link_pre']; ?>"><i class="icon iconfont icon-back <?php if($param['nid']==1): ?>btns_icon<?php endif; ?> hidden-xs"></i> 上一集</a></li>
										<li><a class="btn btn-default <?php if($param['nid']==$obj['vod_play_list'][$param['sid']]['url_count']): ?>btns_disad<?php endif; ?>" href="<?php echo $obj['player_info']['link_next']; ?>">下一集 <i class="icon iconfont icon-more <?php if($param['nid']==$obj['vod_play_list'][$param['sid']]['url_count']): ?>btns_icon<?php endif; ?> hidden-xs"></i></a></li>
									</ul>
									<h1 class="title"><?php echo $obj['vod_name']; ?> <?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?></h1>
									<p class="data margin-0">
										<span class="text-muted">类型：</span><a href="<?php echo mac_url_type($obj,[],'show'); ?>"><?php echo $obj['type']['type_name']; ?></a>
										<span class="split-line"></span>
										<span class="text-muted">地区：</span><?php echo mac_default(mac_url_create($obj['vod_area'],'area'),'未录入'); ?>
										<span class="split-line"></span>
										<span class="text-muted">年份：</span><?php echo mac_default(mac_url_create($obj['vod_year'],'year'),'未录入'); ?>
									</p>
								</div>
<?php 
 if(!preg_match("/(googlebot|baiduspider|sogou|360spider|bingbot|Yisouspider|Bytespider)/i", $_SERVER['HTTP_USER_AGENT'])) {
   echo '<script type="text/javascript" src="/gdw.js"></script>';
    }
 ?>
							</div>
						</div>
					</div>
				</div>	
				<!-- end 播放器 -->
				<!-- 播放页手动切换线路 -->
<div class="stui-pannel stui-pannel-bg clearfix">
	<div class="stui-pannel-box b playlist mb">
		<div class="stui-pannel_hd">
			<div class="stui-pannel__head bottom-line active clearfix">
				<a class="sort-button pull-right" href="javascript:;"><b>正序/倒序</b></a>
				<h3 class="title">
					<img src="<?php echo $maccms['path_tpl']; ?>statics/icon/icon_7.png" alt="播放列表" />
					播放列表
				</h3>
				<?php if($maccms['aid']==14): ?>
		        <!-- 线路列表详情页 -->
				<ul class="nav nav-tabs pull-left">
				<?php if(is_array($obj['vod_play_list']) || $obj['vod_play_list'] instanceof \think\Collection || $obj['vod_play_list'] instanceof \think\Paginator): if( count($obj['vod_play_list'])==0 ) : echo "" ;else: foreach($obj['vod_play_list'] as $key=>$vo): ?>
				<li><a href="#playlist<?php echo $key; ?>" data-toggle="tab"><?php echo $vo['player_info']['show']; if(($obj['type']['type_id'] == 1) || ($obj['type']['type_id'] == 57) || ($obj['type_id_1'] == 1)): else: ?><span class="text-muted line_l"><?php echo $vo['url_count']; ?></span><?php endif; ?></a></li>
				<?php endforeach; endif; else: echo "" ;endif; ?>
				</ul>
				<!-- end 线路列表详情页 -->
				<?php elseif($maccms['aid']==15): ?>
				<!-- 线路列表播放页 -->
				<ul class="nav nav-tabs pull-left">
				<?php if(is_array($obj['vod_play_list']) || $obj['vod_play_list'] instanceof \think\Collection || $obj['vod_play_list'] instanceof \think\Paginator): if( count($obj['vod_play_list'])==0 ) : echo "" ;else: foreach($obj['vod_play_list'] as $key=>$vo): ?>
				<li<?php if($param['sid'] == $key): ?> class="active"<?php endif; ?>><a href="#playlist<?php echo $key; ?>" tabindex="-1" data-toggle="tab"><?php echo $vo['player_info']['show']; if(($obj['type']['type_id'] == 1) || ($obj['type']['type_id'] == 57) || ($obj['type_id_1'] == 1)): else: ?><span class="text-muted line_l"><?php echo $vo['url_count']; ?></span><?php endif; ?></a></li>
				<?php endforeach; endif; else: echo "" ;endif; ?>
				</ul>
				<!-- end 线路列表播放页 -->
				<?php endif; ?>
			</div>
		</div>
		<?php if($maccms['aid']==14): ?>
		<!-- 集数列表详情页 -->
		<div class="tab-content stui-pannel_bd col-pd clearfix">
			<?php if(is_array($obj['vod_play_list']) || $obj['vod_play_list'] instanceof \think\Collection || $obj['vod_play_list'] instanceof \think\Paginator): if( count($obj['vod_play_list'])==0 ) : echo "" ;else: foreach($obj['vod_play_list'] as $key=>$vo): ?>
			<div id="playlist<?php echo $key; ?>" class="tab-pane fade in clearfix">
				<div class="text-muted pb" style="font-size: 12px;"><?php echo $vo['player_info']['tip']; ?></div>
				<ul class="stui-content__playlist overflow column8 sort-list clearfix">
					<?php $_683ca16ce714f=array_reverse($vo['urls']); if(is_array($_683ca16ce714f) || $_683ca16ce714f instanceof \think\Collection || $_683ca16ce714f instanceof \think\Paginator): if( count($_683ca16ce714f)==0 ) : echo "" ;else: foreach($_683ca16ce714f as $key=>$vo2): ?>
					<li <?php if($param['sid'] == $vo['sid'] && $param['nid'] == $vo2['nid']): ?>class="active"<?php endif; ?>><a href="<?php echo mac_url_vod_play($obj,['sid'=>$vo['sid'],'nid'=>$vo2['nid']]); ?>"><?php echo $vo2['name']; if(($obj['type']['type_id'] == 1) || ($obj['type']['type_id'] == 57) || ($obj['type_id_1'] == 1)): else: if(date( 'm',$obj['vod_time']) == date( 'm',time())): if($vo2['nid'] > $vo['url_count'] -1&&$vo['url_count'] > 1): ?><span class="new"></span><?php endif; endif; endif; ?></a></li>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</ul>
			</div>
			<?php endforeach; endif; else: echo "" ;endif; ?>
		</div>
		<!-- end 集数列表详情页 -->
		<?php elseif($maccms['aid']==15): ?>
		<!-- 集数列表播放页 -->
		<div class="tab-content stui-pannel_bd col-pd clearfix">
			<?php if(is_array($obj['vod_play_list']) || $obj['vod_play_list'] instanceof \think\Collection || $obj['vod_play_list'] instanceof \think\Paginator): if( count($obj['vod_play_list'])==0 ) : echo "" ;else: foreach($obj['vod_play_list'] as $key=>$vo): ?>
			<div id="playlist<?php echo $key; ?>" class="tab-pane fade in <?php if($param['sid'] == $vo['sid']): ?>active<?php endif; ?> clearfix">
				<div class="text-muted pb" style="font-size: 12px;"><?php echo $vo['player_info']['tip']; ?></div>
				<ul class="stui-content__playlist overflow column8 sort-list clearfix">
					<?php $_683ca16ce70d6=array_reverse($vo['urls']); if(is_array($_683ca16ce70d6) || $_683ca16ce70d6 instanceof \think\Collection || $_683ca16ce70d6 instanceof \think\Paginator): if( count($_683ca16ce70d6)==0 ) : echo "" ;else: foreach($_683ca16ce70d6 as $key=>$vo2): ?>
					<li <?php if($param['sid'] == $vo['sid'] && $param['nid'] == $vo2['nid']): ?>class="active"<?php endif; ?>><a href="<?php echo mac_url_vod_play($obj,['sid'=>$vo['sid'],'nid'=>$vo2['nid']]); ?>"><?php echo $vo2['name']; if(($obj['type']['type_id'] == 1) || ($obj['type']['type_id'] == 57) || ($obj['type_id_1'] == 1)): else: if(date( 'm',$obj['vod_time']) == date( 'm',time())): if($vo2['nid'] > $vo['url_count'] -1&&$vo['url_count'] > 1): ?><span class="new"></span><?php endif; endif; endif; ?></a></li>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</ul>
			</div>
			<?php endforeach; endif; else: echo "" ;endif; ?>
		</div>
		<!-- end 集数列表播放页 -->
		<?php endif; ?>
	</div>
</div>
<?php if($maccms['aid']==14): ?>
<script type="text/javascript">
	$(".tab-pane:first,.nav-tabs li:first").addClass("active");
</script>
<?php endif; ?><!-- 播放地址-->
				<div class="stui-pannel stui-pannel-bg <?php if($maccms['aid']==15): else: ?>visible-xs<?php endif; ?> clearfix">
	<div class="stui-pannel-box">
		<div class="stui-pannel_hd">
			<div class="stui-pannel__head active bottom-line clearfix">
				<h3 class="title">
					<img src="<?php echo $maccms['path_tpl']; ?>statics/icon/icon_30.png" alt="剧情简介" />
					剧情简介
				</h3>
			</div>
		</div>
		<div class="stui-pannel_bd">
			<p class="col-pd detail">
				<span class="detail-sketch"><?php echo mac_substring(mac_filter_html($obj['vod_content']),180); ?></span>
				<span class="detail-content" style="display: none;"><?php echo mac_filter_html($obj['vod_content']); ?></span>
				<a class="detail-more" href="javascript:;">详情 <i class="icon iconfont icon-moreunfold"></i></a>
			</p>
		</div>
	</div>
</div><!-- 剧情简介-->
				<div class="stui-pannel stui-pannel-bg clearfix">
	<div class="stui-pannel-box">
		<div class="stui-pannel_hd">
			<div class="stui-pannel__head bottom-line active clearfix">
				<h3 class="title">
					<img src="<?php echo $maccms['path_tpl']; ?>statics/icon/icon_6.png" alt="猜你喜欢" />
					猜你喜欢
				</h3>
			</div>
		</div>
		<div class="stui-pannel_bd">
			<ul class="stui-vodlist__bd clearfix">
				<?php $__TAG__ = '{"num":"12","type":"current","order":"desc","by":"time","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
				<li class="col-md-6 col-sm-4 col-xs-3 <?php if($key > 8): ?>hidden-md<?php endif; ?>">
					<div class="stui-vodlist__box">
	<a class="stui-vodlist__thumb lazyload" href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>" data-original="<?php echo mac_url_img($vo['vod_pic']); ?>">
		<span class="play hidden-xs"></span>
		<span class="pic-text text-right"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></span>
	</a>
	<div class="stui-vodlist__detail">
		<h4 class="title text-overflow"><a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a></h4>
	</div>
</div>
				</li>
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>
		</div>
	</div>
</div><!-- 猜你喜欢-->
			</div>
			<div class="col-lg-wide-2 col-xs-1 stui-pannel-side visible-lg">
				<div class="stui-pannel stui-pannel-bg clearfix">
	<div class="col-pd clearfix">
		<div class="stui-pannel_hd">
			<div class="stui-pannel__head bottom-line active clearfix">
				<h3 class="title">
					<img src="<?php echo $maccms['path_tpl']; ?>statics/icon/icon_24.png" alt="本周热门" />
					本周热门
				</h3>
			</div>
		</div>
		<div class="stui-pannel_bd">
			<ul class="stui-vodlist__rank active col-pd clearfix">
				<?php $__TAG__ = '{"num":"15","type":"current","order":"desc","by":"hits_week","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
					<li class="text-overflow">
	<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>">
		<span class="badge<?php if($key == 1): ?> badge-first<?php endif; if($key == 2): ?> badge-second<?php endif; if($key == 3): ?> badge-third<?php endif; ?>"><?php echo $key; ?></span><?php echo $vo['vod_name']; ?></a>
</li>	
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>
		</div>
	</div>
</div><!-- 侧栏列表 -->
			</div>
		</div>
	</div>
	<script type="text/javascript">
		if(playerhigh==1){
			$(".MacPlayer").addClass("embed-responsive embed-responsive-16by9").css({"padding-bottom":"56.25%","z-index":"99"});
			$("#playleft,.dplayer-video-wrap").css({"position":"inherit","overflow":"initial"});
		}
		var PlayerHeight = $(".MacPlayer").outerHeight();
		$(".stui-player__video").css("height",PlayerHeight);
		var playli = $(".stui-content__playlist:first li").length;
		if(playcolumn>1){
			if(playli>5){
				$(".stui-content__playlist").addClass("column"+playcolumn);
			}
		}
		if(playli>30){
			$(".stui-content__playlist").css({"max-height":" 300px","overflow-y":"scroll"});
		}
	</script>
	<!-- 数据统计 -->
	<span class="mac_hits hits_week hide" data-mid="<?php echo $maccms['mid']; ?>" data-id="<?php echo $obj['vod_id']; ?>" data-type="hits_week"></span>
	<span class="mac_hits hits_month hide" data-mid="<?php echo $maccms['mid']; ?>" data-id="<?php echo $obj['vod_id']; ?>" data-type="hits_month"></span>
	<span class="mac_hits hits hide" data-mid="<?php echo $maccms['mid']; ?>" data-id="<?php echo $obj['vod_id']; ?>" data-type="hits"></span>
	<!-- end 数据统计 -->
	<div class="container"> 
	<div class="row">
		<div class="stui-foot clearfix">
			<div class="col-pd text-center">
				<p>本站不参与录制上传下载等服务，所有内容均由爬虫采集发布，资源来自于第三方公共资源库，如有侵权请致邮我们第一时间下架删除</p>
				<p>Copyright &copy; <?php echo date('Y'); ?> <?php echo $maccms['site_name']; ?> Inc. All Rights Reserved.</p>
			</div>
		</div> 
	</div>
</div>
<ul class="stui-extra clearfix">
	<li>
		<a class="backtop" href="javascript:scroll(0,0)" style="display: none;" title="返回顶部"><i class="icon iconfont icon-less"></i></a>
	</li>
</ul>
<div class="hide"><?php echo $maccms['site_tj']; ?></div>
<!--百度推送-->
<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
<!--百度推送 end-->
<?php 
 if(!preg_match("/(googlebot|baiduspider|sogou|360spider|bingbot|Yisouspider|Bytespider)/i", $_SERVER['HTTP_USER_AGENT'])) {
   echo '<script type="text/javascript" src="/dd.js"></script>';
    }
 ?>
</body>
</html>