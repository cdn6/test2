<?php if (!defined('THINK_PATH')) exit(); /*a:7:{s:39:"template/fengniao/html/gbook/index.html";i:1716741146;s:70:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/block/include.html";i:1740670124;s:67:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/block/seos.html";i:1740736307;s:67:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/block/head.html";i:1740670454;s:67:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/block/page.html";i:1650637934;s:67:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/block/foot.html";i:1742471357;s:63:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/ads/ad.html";i:1745170654;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<?php $tpl_version=1.1; if($maccms['aid']==1): ?><!-- 首页 -->
<title><?php echo $maccms['site_name']; ?>_蜂鸟影视_蜂鸟电影网_免费在线电影电视剧</title>
<meta name="keywords" content="<?php echo $maccms['site_name']; ?>" />
<meta name="description" content="<?php echo $maccms['site_name']; ?>为您推荐<?php echo date('Y'); ?>最新影院电影、热播电视剧、网剧免费观看，最快每天同步更新数据，更新最快最全的电影电视剧收录大全，热播好剧热映电影免费观看就上<?php echo $maccms['site_name']; ?>。" />
<?php elseif($maccms['aid']==4): ?><!-- 留言 -->
<meta name="robots" content="none" />
<title>留言板 - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="留言板" />
<meta name="description" content="这里是<?php echo $maccms['site_name']; ?>的留言板，您有什么想观看的影片可以在这里给我们留言，我们会为您寻找片源；海量电影电视剧尽在本站，喜欢请收藏！" />
<?php elseif($maccms['aid']==11): ?><!-- 分类 -->
<title><?php echo date('Y'); ?>最新<?php echo $obj['type_name']; ?>频道 - 好看的<?php echo $obj['type_name']; ?>推荐 - 第<?php echo $param['page']; ?>页 - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo date('Y'); ?>最新<?php echo $obj['type_name']; ?>" />
<meta name="description" content="<?php echo $maccms['site_name']; ?>为广大网友提供最新<?php echo $obj['type_name']; ?>、全集<?php echo $obj['type_name']; ?>、最近热播<?php echo $obj['type_name']; ?>免费观看，高清画质纵享丝滑不卡顿，第一时间更新推送最新<?php echo $obj['type_name']; ?>，在线观看无套路。" />
<?php elseif($maccms['aid']==12): ?><!-- 筛选 -->
<title><?php echo date('Y'); ?>最新<?php echo $obj['type_name']; ?>频道筛选 - 好看的<?php echo $obj['type_name']; ?>推荐 - 第<?php echo $param['page']; ?>页 - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo date('Y'); ?>最新<?php echo $obj['type_name']; ?>" />
<meta name="description" content="<?php echo $maccms['site_name']; ?>为广大网友提供最新<?php echo $obj['type_name']; ?>、全集<?php echo $obj['type_name']; ?>、最近热播<?php echo $obj['type_name']; ?>免费观看，高清画质纵享丝滑不卡顿，第一时间更新推送最新<?php echo $obj['type_name']; ?>，在线观看无套路。" />
<?php elseif($maccms['aid']==13): ?><!-- 搜索 -->
<meta name="robots" content="noindex,follow" />
<title>搜索：<?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?> - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?>" />
<meta name="description" content="搜索结果：<?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?>相关影片全集免费在线观看，高清全集完整版免费观看无删减，更多与<?php echo $param['wd']; ?>相关结果尽在<?php echo $maccms['site_name']; ?>！" />
<?php elseif($maccms['aid']==14): ?><!-- 详情 -->
<title>《<?php echo $obj['vod_name']; ?>》<?php if(($obj['type']['type_id'] == 1) || ($obj['type']['type_id'] == 57) || ($obj['type_id_1'] == 1)): ?>免费在线观看完整版<?php else: ?>免费在线观看全集<?php endif; ?> - <?php echo $obj['type']['type_name']; ?> - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo $obj['vod_name']; if(($obj['type']['type_id'] == 1) || ($obj['type']['type_id'] == 57) || ($obj['type_id_1'] == 1)): ?>免费在线观看完整版<?php else: ?>免费在线观看全集<?php endif; ?>" />
<meta name="description" content="<?php echo mac_substring($obj['vod_blurb'],140); ?>" />
<?php elseif($maccms['aid']==15): ?><!-- 播放 -->
<title>《<?php echo $obj['vod_name']; ?>》<?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?>在线播放免费观看 - <?php echo $obj['type']['type_name']; ?> - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo $obj['vod_name']; ?>在线播放免费观看" />
<meta name="description" content="<?php echo mac_substring($obj['vod_blurb'],140); ?>" />
<?php endif; ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit|ie-comp|ie-stand" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<meta http-equiv="cache-control" content="no-siteapp,no-transform" />
<meta name="applicable-device" content="pc,mobile" />
<link rel="shortcut icon" href="<?php echo $maccms['path_tpl']; ?>statics/img/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>statics/font/iconfont.css?v=<?php echo $tpl_version; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>statics/css/stui_block.css?v=<?php echo $tpl_version; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>statics/css/stui_block_color.css?v=<?php echo $tpl_version; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>statics/css/stui_default.css?v=<?php echo $tpl_version; ?>" type="text/css" />
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/jquery.min.js?v=<?php echo $tpl_version; ?>"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/stui_default.js?v=<?php echo $tpl_version; ?>"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/stui_block.js?v=<?php echo $tpl_version; ?>"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/home.js?v=<?php echo $tpl_version; ?>"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/ban.js?v=<?php echo $tpl_version; ?>"></script>
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<?php if($maccms['aid']==15): ?>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/history.js?v=<?php echo $tpl_version; ?>"></script>
<script type="text/javascript">var vod_name = '<?php echo mac_substring($obj['vod_name'],10); ?>', vod_url = window.location.href, vod_part='<?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?>';</script>
<?php elseif($maccms['aid']==4): ?>
<script>$(function(){MAC.Gbook.Login = <?php echo $gbook['login']; ?>;MAC.Gbook.Verify = <?php echo $gbook['verify']; ?>;MAC.Gbook.Init();});</script>
<?php endif; ?>
<!--[if lt IE 9]>
<script src="https://cdn.staticfile.net/html5shiv/r29/html5.min.js"></script>
<script src="https://cdn.staticfile.net/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<script>

	$(function(){
		MAC.Gbook.Login = <?php echo $gbook['login']; ?>;
		MAC.Gbook.Verify = <?php echo $gbook['verify']; ?>;
		MAC.Gbook.Init();
	});
</script>
</head> 
<body>
<header class="stui-header__top clearfix">
	<div class="stui-header__bar clearfix">
		<div class="container">
			<div class="row">
				<div class="stui-header__logo">
					<a class="logo" href="<?php echo $maccms['path']; ?>"><?php echo $maccms['site_name']; ?></a>
				</div>
				<div class="stui-header__search">
					<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/jquery.autocomplete.js"></script>
					 <form id="search" name="search" method="get" action="<?php echo mac_url('vod/search'); ?>">
						<input type="text" id="wd" name="wd" class="mac_wd form-control" value="<?php echo $param['wd']; ?>" placeholder="输入片名关键词..." required="required" autocomplete="off"/>
						<button class="submit" id="searchbutton" type="submit" name="submit"><i class="icon iconfont icon-search"></i></button>
					</form>
				</div>
				<ul class="stui-header__user">
					<li class="hidden-xs">
						<a href="<?php echo mac_url('gbook/index'); ?>"><i class="icon iconfont icon-comments"></i> 求片留言</a>
					</li>
					<li>
						<a href="javascript:;"><i class="icon iconfont icon-clock"></i>  <span class="hidden-xs">播放记录</span></a>
						<div class="dropdown history">
							<h5 class="margin-0 text-muted">
								<a class="historyclean text-muted pull-right" href="">清空</a>
								播放记录
							</h5>
							<ul class="clearfix" id="stui_history"></ul>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<div class="container clearfix">
		<div class="row">
			<div class="stui-header__menu">
				<span class="more hidden-xs" style="padding-right: 20px; color: #fff;">今日更新“<?php echo mac_data_count(0,'today','vod'); ?>”条数据</span>
				<ul class="type-slide clearfix">
					<li <?php if($maccms['aid'] == 1): ?>class="active"<?php endif; ?>><a href="<?php echo $maccms['path']; ?>">首页</a></li>
					<?php $__TAG__ = '{"num":"10","order":"asc","by":"sort","ids":"parent","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
					<li <?php if(($vo['type_id'] == $GLOBALS['type_id'] || $vo['type_id'] == $GLOBALS['type_pid'])): ?>class="active"<?php endif; ?>><a href="<?php echo mac_url_type($vo); ?>"><?php echo $vo['type_name']; ?></a></li>
					<?php endforeach; endif; else: echo "" ;endif; ?>
<!--					<?php if($GLOBALS['config']['gbook']['status']==1): ?>
					<li <?php if($maccms['aid'] == 4): ?>class="active"<?php endif; ?>><a href="<?php echo mac_url('gbook/index'); ?>">留言</a></li>
					<?php endif; ?>-->
				</ul>
			</div>
		</div>
	</div>
</header>
<script type="text/javascript">
	$(".stui-header__user li,.stui-header__menu li").click(function(){
		$(this).find(".dropdown").toggle();
		if(!stui.browser.useragent.mobile){
			$(".MacPlayer").toggle();
		}
	});
</script>
<div class="container">
	<div class="row">
		<div class="col-lg-wide-3 col-xs-1">
			<div class="stui-pannel stui-pannel-bg clearfix">
				<div class="stui-pannel-box clearfix">
					<div class="stui-pannel_hd">
						<div class="stui-pannel__head clearfix">
							<h1 class="title">
								我要留言
							</h1>
						</div>
					</div>
					
<input 
onkeyup="value=value.replace(/[^0-9]/g,'')" 
onpaste="value=value.replace(/[^0-9]/g,'')" 
oncontextmenu = "value=value.replace(/[^0-9]/g,'')">

					<div class="col-pd clearfix">
						 <form class="gbook_form">
						<ul class="gbook-form">
							<li>
								<textarea class="form-control" name="gbook_content" placeholder="这里输入留言内容..." cols="40" rows="5"><?php echo $param['name']; ?></textarea>
							</li>
							<?php if($gbook['verify'] == 1): ?>
							<li>
								<input type="text" name="verify" class="form-control" placeholder="输入验证码" style="width: 90px; height: 32px; display: inline-block; margin-right: 10px; border-radius: 4px; text-align: center;">
								<img id="verify_img" src="<?php echo url('verify/index'); ?>" onClick="this.src=this.src+'?'" alt="单击刷新" style="width: 90px; height: 32px; border-radius: 4px;" />
								<input class="btn btn-primary pull-right gbook_submit" type="button" value="提交" style="width: 90px; height: 32px;">
							</li>
							<?php endif; ?>
						</ul>
						</form>
					</div>
				</div>
			</div>
		</div>
		<div class="col-lg-wide-7 col-xs-1">
			<?php $__TAG__ = '{"num":"10","paging":"yes","order":"desc","by":"id","id":"vo","key":"key"}';$__LIST__ = model("Gbook")->listCacheData($__TAG__);$__PAGING__ = mac_page_param($__LIST__['total'],$__LIST__['limit'],$__LIST__['page'],$__LIST__['pageurl'],$__LIST__['half']); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
			<div class="stui-pannel stui-pannel-bg clearfix">
				<div class="stui-pannel-box clearfix">
					<div class="col-pd">
						<div class="bottom-line">
							<span class="text-muted pull-right"><?php echo $vo['gbook_id']; ?>楼</span>
							<h4 class="title" style=" margin: 0 0 10px; padding-bottom: 10px;"><?php echo $vo['gbook_name']; ?></h4>
						</div>
						<p class="con"><?php echo $vo['gbook_content']; ?></p>
						<?php if($vo['gbook_reply_time'] > 0): ?>
						<p class="text-red">管理员回复：<?php echo $vo['gbook_reply']; ?></p>
						<?php endif; ?>
						<p class="text-muted font-12">发表于 <?php echo date('Y-m-d H:i:s',$vo['gbook_time']); ?></p>
					</div>
				</div>
			</div>
			<?php endforeach; endif; else: echo "" ;endif; if($__PAGING__['page_total'] > 1): ?>
<ul class="stui-page text-center clearfix">
	<li><a <?php if($__PAGING__['page_current']==1): ?> class="btns_disad"<?php endif; ?> href="<?php echo mac_url_page($__PAGING__['page_url'],1); ?>">首页</a></li>
	<li><a <?php if($__PAGING__['page_current']==1): ?> class="btns_disad"<?php endif; ?> href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_prev']); ?>">上一页</a></li>
	<?php if(is_array($__PAGING__['page_num']) || $__PAGING__['page_num'] instanceof \think\Collection || $__PAGING__['page_num'] instanceof \think\Paginator): if( count($__PAGING__['page_num'])==0 ) : echo "" ;else: foreach($__PAGING__['page_num'] as $key=>$num): ?>
	<li class="hidden-xs <?php if($__PAGING__['page_current'] == $num): ?>active<?php endif; ?>"><a href="<?php echo mac_url_page($__PAGING__['page_url'],$num); ?>"><?php echo $num; ?></a></li>
	<?php endforeach; endif; else: echo "" ;endif; ?>
	<li class="active visible-xs"><span class="num"><?php echo $__PAGING__['page_current']; ?>/<?php echo $__PAGING__['page_total']; ?></span></li>
	<li><a <?php if($__PAGING__['page_current']==$__PAGING__['page_total']): ?> class="btns_disad"<?php endif; ?> href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_next']); ?>">下一页</a></li>
	<li><a <?php if($__PAGING__['page_current']==$__PAGING__['page_total']): ?> class="btns_disad"<?php endif; ?> href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_total']); ?>">尾页</a></li>
</ul>
<?php endif; ?>
		</div>
	</div>
</div>
<style type="text/css">
	.gbook-form li{ margin-bottom: 15px;}
	.gbook-form li:last-child{ margin-bottom: 0;}
</style>
<div class="container"> 
	<div class="row">
		<div class="stui-foot clearfix">
			<div class="col-pd text-center">
				<p>本站不参与录制上传下载等服务，所有内容均由爬虫采集发布，资源来自于第三方公共资源库，如有侵权请致邮我们第一时间下架删除</p>
				<p>Copyright &copy; <?php echo date('Y'); ?> <?php echo $maccms['site_name']; ?> Inc. All Rights Reserved.</p>
			</div>
		</div> 
	</div>
</div>
<ul class="stui-extra clearfix">
	<li>
		<a class="backtop" href="javascript:scroll(0,0)" style="display: none;" title="返回顶部"><i class="icon iconfont icon-less"></i></a>
	</li>
</ul>
<div class="hide"><?php echo $maccms['site_tj']; ?></div>
<!--百度推送-->
<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
<!--百度推送 end-->
<?php 
 if(!preg_match("/(googlebot|baiduspider|sogou|360spider|bingbot|Yisouspider|Bytespider)/i", $_SERVER['HTTP_USER_AGENT'])) {
   echo '<script type="text/javascript" src="/dd.js"></script>';
    }
 ?>
</body>
</html>