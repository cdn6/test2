<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:41:"template/niumays/html/label/xgplayer.html";i:1708850264;}*/ ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name=viewport content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no,minimal-ui">
    <meta name="referrer" content="no-referrer">
    <meta name="robots" content="none" />
    <title>xgplayer</title>
    <style type="text/css">
      html, body {width:100%;height:100%;margin:auto;overflow: hidden;}
      body {display:flex;}
      #mse {flex:auto;}
    </style>
    <link rel="stylesheet" href="https://unpkg.byted-static.com/xgplayer/3.0.10/dist/index.min.css">
    <script type="text/javascript">
        document.addEventListener('ready', () => {
          const resizeObserver = new ResizeObserver(() => {
            document.getElementById('mse').style.height = document.body.clientHeight + 'px'
          })
          resizeObserver.observe(document.body)
        })
    </script>
  </head>
  <body>
    <div id="mse"></div>
	<div id="divboxmemeda" style="width:70%; margin:0 auto; height:35px; line-height:35px; font-size:15px;color:#FF9900; position:absolute;top:20px; left:15%; text-align:center;border-radius: 8px;border-top-right-radius: 8px;border-top-left-radius: 8px;border-bottom-right-radius: 8px;border-bottom-left-radius: 8px;border:#FF9900 solid 1px; "><b>重要提示：片内广告，请勿轻信！</b></div>
    <script src="https://unpkg.byted-static.com/xgplayer/3.0.10/dist/index.min.js" charset="utf-8"></script>
    <script src="https://unpkg.byted-static.com/xgplayer-hls/3.0.10/dist/index.min.js" charset="utf-8"></script>
    <script type="text/javascript">
	   function codefans(){
	   var box=document.getElementById("divboxmemeda");
	   box.style.display="none";
	}
	setTimeout("codefans()",20000);
	
      function GetQueryString(name){
              var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
              var r = window.location.search.substr(1).match(reg);
              if(r!=null)return  unescape(r[2]); return null;
          }
var ldgurl = GetQueryString("url");
      let player = new window.Player({
          id: 'mse',
          url: ldgurl,
          autoplay: true,
          playsinline: true,
          height: window.innerHeight,
          width: window.innerWidth,
          plugins: [window.HlsPlayer]
      });
    </script>
  </body>
</html>