<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:35:"template/xxys/html/gbook/index.html";i:1586133822;s:66:"/www/wwwroot/www.dgcsqz.com/template/xxys/html/public/include.html";i:1586132902;s:63:"/www/wwwroot/www.dgcsqz.com/template/xxys/html/public/head.html";i:1586133662;s:65:"/www/wwwroot/www.dgcsqz.com/template/xxys/html/public/paging.html";i:1586133720;s:63:"/www/wwwroot/www.dgcsqz.com/template/xxys/html/public/foot.html";i:1586133782;}*/ ?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width = device-width ,initial-scale = 1,minimum-scale = 1,maximum-scale = 1,user-scalable =no,"/>
    <title>留言板 - <?php echo $maccms['site_name']; ?></title>
	<link href="<?php echo $maccms['path']; ?>static/css/home.css" rel="stylesheet" type="text/css" />
    
		<link rel="shortcut icon" href="<?php echo $maccms['path_tpl']; ?>images/favicon.ico" type="image/x-icon" />
		<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>css/style.css" type="text/css" />
		<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>css/font-awesome.min.css" type="text/css" />
		<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>css/global.css" type="text/css" />
		<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>css/font-awesome.min.css" type="text/css" />
		<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>js/jquery.min.js"></script>
		<script src="<?php echo $maccms['path_tpl']; ?>js/hd.js"></script>
		<script src="<?php echo $maccms['path_tpl']; ?>js/common.js"></script>
		<script src="<?php echo $maccms['path_tpl']; ?>js/function.js"></script>
		<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
		<script src="<?php echo $maccms['path']; ?>static/js/home.js"></script>
		<style type="text/css">
		.pc_acmsd{display:block;}
		.m_acmsd{ display:none}
		@media(max-width:768px) {
		.pc_acmsd{display:none !important;}
		.m_acmsd{display:block !important;}
		}
		</style>
    <script>
        $(function(){
            MAC.Gbook.Login = <?php echo $gbook['login']; ?>;
            MAC.Gbook.Verify = <?php echo $gbook['verify']; ?>;
            MAC.Gbook.Init();
        });
    </script>
</head>
<body>

<!--wap端头部-->
<div class="m_acmsd">
<div class="wrapper">
<div class="mask" id="mask_box"></div>
<header class="header1 clearfix" id="header">
<p class="headLeft"><a href="<?php echo $maccms['path']; ?>" class="aLogo"></a></p>
<p class="headRight">
<a href="javascript:void(0);" class="aNav"><span>导航</span></a>
<a href="javascript:void(0);" class="aSearch"><span>搜索</span></a>
<a href="<?php echo mac_url('gbook/index'); ?>" class="aHome"><span id="unameHeader">求片</span></a>
</p>
</header>
<nav class="subNav globalPadding index_menu_top" id="nav_menu" style="display:none;">
<div class="con clearfix">
<p>
<a href="<?php echo $maccms['path']; ?>" title="首页" class="<?php if($maccms['aid'] == 1): ?> cur<?php endif; ?>">首页</a>
<?php $__TAG__ = '{"num":"10","order":"asc","by":"sort","ids":"1,2,3,4","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
<a  href="<?php echo mac_url_type($vo); ?>" class="<?php echo $vo['type_id']; ?>=<?php echo $vo['type_pid']; if(($vo['type_id'] == $GLOBALS['type_id'] || $vo['type_id'] == $GLOBALS['type_pid'])): ?> cur<?php endif; ?>"><?php echo $vo['type_name']; ?></a>
<?php endforeach; endif; else: echo "" ;endif; ?>
</p>
</div>
</nav>
<section id="search_box" class="searchMenu" style="display:none">
<form id="search" name="search" method="get" action="<?php echo mac_url('vod/search'); ?>" onSubmit="return qrsearch();" >
<div class="searchFormCon globalPadding">
<p class="pSearchForm">
<input type="text" class="searchTxt searchTxtBlur ac_input mac_wd" name="wd" autocomplete="off" value="<?php echo $param['wd']; ?>" placeholder="请输入影片名称" /><input type="submit" value="" class="searchBtn search-button sub" id="searchbutton"><i class="clearSearchBtn" style="display:none;"><em></em></i>
</p>
</div>
</form>        
</section> 
<?php $__TAG__ = '{"num":"1","order":"desc","by":"time","level":"1","id":"vo","key":"key"}';$__LIST__ = model("Art")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
<div style='color:red;padding: 5px;margin: 10 5px;margin-top: 5px;font-size: 14px;border: 1px solid red;'>
<?php echo mac_url_content_img($vo['art_content']); ?>	
</div>
<?php endforeach; endif; else: echo "" ;endif; ?>
<div style="margin-top:10px;"></div>
</div>
<div style="margin-top:-80px;"></div>
</div>
<!--wap端头部 end-->
<div class="pc_acmsd">
<div class="header clearfix">
<div class="head wrap clearfix">
<div class="logo"><a href="<?php echo $maccms['path']; ?>"></a></div>



<div class="searchvod">
<form name="formsearch" id="formsearch" action="<?php echo mac_url('vod/search'); ?>" method="post" target="_self">
<input type="text" id="searchword" name="wd" class="search-input" value="请输入影片名称>>>" onfocus="if(this.value=='请输入影片名称>>>'){this.value='';}" onblur="if(this.value==''){this.value='请输入影片名称>>>';};">
<input type="submit" name="submit" class="sub" value="搜&nbsp;索">
</form>
<div class="hotwords mbyc">热搜：
 <?php $_67bf15126294e=explode(',',$maccms['search_hot']); if(is_array($_67bf15126294e) || $_67bf15126294e instanceof \think\Collection || $_67bf15126294e instanceof \think\Paginator): if( count($_67bf15126294e)==0 ) : echo "" ;else: foreach($_67bf15126294e as $key2=>$vo2): ?>
<a href="<?php echo mac_url('vod/search',['wd'=>$vo2]); ?>"><?php echo $vo2; ?></a>
<?php endforeach; endif; else: echo "" ;endif; ?>
</div>
</div>


<a href="javascript:void(0);" target="_self" class="caidan_btn pcyc"><i class="caidan"></i><span>导航</span></a>
<ul id="tbmov-plus" class="mbyc">
<li><a id="new" href="<?php echo mac_url('label/new'); ?>"><i class="ui-icon new-icon"></i>最近<br>更新</a></li>
<li><a href="<?php echo mac_url('label/hot'); ?>"><i class="ui-icon top-icon"></i>影片<br>排行</a></li>
<li><a rel="nofollow" href="<?php echo mac_url('gbook/index'); ?>"><i class="ui-icon gb-icon"></i>留言<br>反馈</a></li>
<li><a rel="nofollow" target="_self" id="a-clo" href="javascript:void(0);" onmouseout="hideImg()" onmouseover="showImg()">手机<br>观看</a></li>
<div id="wxImg" style="display:none;position: absolute; top: 85px; right: 0; z-index: 100;"><p style="text-align: center;">扫描二维码，访问《<?php echo $maccms['site_name']; ?>》</p><img src="http://qr.topscan.com/api.php?bg=f3f3f3&fg=ff0000&gc=222222&el=l&w=200&m=10&text=http://<?php echo $maccms['site_url']; ?>"></div>
</ul>	
</div>
<div class="sjmenu pcyc">
<ul class="nav wrap clearfix">
<li class="<?php if($maccms['aid'] == 1): ?> current<?php endif; ?>"><a href="<?php echo $maccms['path']; ?>"><i class="fa fa-home"></i>首页</a></li>
<?php $__TAG__ = '{"num":"10","order":"asc","by":"sort","ids":"parent","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
<li><a href="<?php echo mac_url_type($vo); ?>"><?php echo $vo['type_name']; ?></a></li>
<?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
</div>
<div class="menu mbyc">
<ul class="nav wrap clearfix">
<li class="<?php if($maccms['aid'] == 1): ?> current<?php endif; ?>"><a href="<?php echo $maccms['path']; ?>"><i class="fa fa-home"></i>首页</a></li>
<?php $__TAG__ = '{"num":"10","order":"asc","by":"sort","ids":"1,2,3,4","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
<li class="<?php echo $vo['type_id']; ?>=<?php echo $vo['type_pid']; if(($vo['type_id'] == $GLOBALS['type_id'] || $vo['type_id'] == $GLOBALS['type_pid'])): ?> current<?php endif; ?>"><a href="<?php echo mac_url_type($vo); ?>"><?php echo $vo['type_name']; ?></a></li>
<?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
</div>
<div id="subnav" class="mbyc">
<div class="layout fn-clear">
<?php $__TAG__ = '{"ids":"1","order":"asc","by":"sort","id":"vo1","key":"key1","flag":"vod"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key1 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo1): $mod = ($key1 % 2 );++$key1;?>		
<div class="subnav-tv fn-left"><strong class="movie"><?php echo $vo1['type_name']; ?>：</strong>
<?php $__TAG__ = '{"parent":"'.$vo1['type_id'].'","order":"asc","by":"sort","id":"vo2","key":"key2"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key2 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo2): $mod = ($key2 % 2 );++$key2;?>
<a href="<?php echo mac_url_type($vo2,[],'show'); ?>"><?php echo $vo2['type_name']; ?></a><em>|</em>
<?php endforeach; endif; else: echo "" ;endif; ?>
</div>
<?php endforeach; endif; else: echo "" ;endif; $__TAG__ = '{"ids":"2","order":"asc","by":"sort","id":"vo1","key":"key1","flag":"vod"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key1 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo1): $mod = ($key1 % 2 );++$key1;?>		
<div class="subnav-tv fn-right"><strong class="tv"><?php echo $vo1['type_name']; ?>：</strong>
<?php $__TAG__ = '{"parent":"'.$vo1['type_id'].'","order":"asc","by":"sort","id":"vo2","key":"key2"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key2 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo2): $mod = ($key2 % 2 );++$key2;?>
<a href="<?php echo mac_url_type($vo2,[],'show'); ?>"><?php echo $vo2['type_name']; ?></a><em>|</em>
<?php endforeach; endif; else: echo "" ;endif; ?>
</div>
<?php endforeach; endif; else: echo "" ;endif; ?>
</div>
</div>
</div>
<div style="margin-top:10px;"></div>
</div>
<div class="wrap wrap_ff">
    <section class="reply_box clearfix">
        <!--留言开始-->
        <div class="mac_msg_r">
            <div class="msg_tit">我要留言</div>
            <form class="gbook_form">
                <p class="msg_cue">请输入您的留言内容：</p>
                <textarea class="gbook_content" name="gbook_content"></textarea>
                <div class="msg_code">
                    <?php if($gbook['verify'] == 1): ?>
                    验证码：<input type="text" name="verify" class="mac_verify">
                    <?php endif; ?>
                    <div class="remaining-w fr">还可输入<span class="gbook_remaining remaining " >200</span></div>
                </div>
                <input type="button" class="gbook_submit submit_btn" value="提交留言">
            </form>
        </div>
        <div class="mac_msg_l block-xs">
            <?php $__TAG__ = '{"num":"5","paging":"yes","order":"desc","by":"id","id":"vo","key":"key"}';$__LIST__ = model("Gbook")->listCacheData($__TAG__);$__PAGING__ = mac_page_param($__LIST__['total'],$__LIST__['limit'],$__LIST__['page'],$__LIST__['pageurl'],$__LIST__['half']); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
            <div class="mac_msg_item">
                <div class="msg_tag">
                    <div class="count_bg"></div>
                    <div class="msg_count"><strong>第<?php echo $vo['gbook_id']; ?></strong>条留言</div>
                </div>
                <div class="msg_list">
                    <div class="msg_reply">
                        <p class="msg_title"><strong><a class="name" href="javascript:;"><?php echo $vo['gbook_name']; ?></a><a target="_blank">(<?php echo mac_long2ip($vo['gbook_ip']); ?>)</a></strong><span class="time"><?php echo date('Y-m-d H:i:s',$vo['gbook_time']); ?></span></p>
                        <div class="msg_cont">
                            <?php echo $vo['gbook_content']; ?>
                        </div>
                    </div>
                    <?php if($vo['gbook_reply_time'] > 0): ?>
                    <div class="reply_answer">
                        <p class="msg_title"><strong>站长回复：</strong><span class="time"><?php echo date('Y-m-d H:i:s',$vo['gbook_reply_time']); ?></span></p>
                        <div class="msg_cont">
                            <?php echo $vo['gbook_reply']; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
        <!--留言结束-->
    </section>
    
<?php if($__PAGING__['page_total'] > 1): ?>
<div class="page clearfix pc_none">
<a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_prev']); ?>">上一页</a>
<a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_next']); ?>">下一页</a>
<div></div>
</div>
<div class="page clearfix mb_none">
<a href="<?php echo mac_url_page($__PAGING__['page_url'],1); ?>">首页</a>
<?php if(is_array($__PAGING__['page_num']) || $__PAGING__['page_num'] instanceof \think\Collection || $__PAGING__['page_num'] instanceof \think\Paginator): if( count($__PAGING__['page_num'])==0 ) : echo "" ;else: foreach($__PAGING__['page_num'] as $key=>$num): ?>
<a class="<?php if($__PAGING__['page_current'] == $num): ?>active-on<?php endif; ?>"  href="<?php echo mac_url_page($__PAGING__['page_url'],$num); ?>"><?php echo $num; ?></a>
<?php endforeach; endif; else: echo "" ;endif; ?>
<a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_next']); ?>">下页</a>
<a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_total']); ?>">尾页</a>
</div>
<?php endif; ?>
</div>
<div style="margin-top: 20px;"></div>

<div class="footer clearfix">
<div class="wrap">
<p>本站只提供WEB页面服务，本站不存储、不制作任何视频，不承担任何由于内容的合法性及健康性所引起的争议和法律责任。</p>
<p>若本站收录内容侵犯了您的权益，请附说明联系邮箱，本站将第一时间处理。</p>
<p><div id="footer"><div class="flink"><a href="/rss/index.xml">RSS</a>｜<a href="/rss/baidu.xml">Baidu SiteMap</a>｜<a href="<?php echo mac_url('rss/google'); ?>">Google SiteMap</a>｜<a href="<?php echo mac_url('rss/sogou'); ?>">sogou SiteMap</a>｜<a href="<?php echo mac_url('rss/sm'); ?>">sm SiteMap</a></p>
<p>Copyright© 2020 <?php echo $maccms['site_name']; ?> All Rights Reserved</p>
</div>					
<div class="gotop" style="display: block;">
<a href="javascript:; " title="返回顶部"><i class="ico gotopbg"></i></a><a href="<?php echo mac_url('gbook/index'); ?>"><i class="ico gbbg"></i></a>
</div>
</div>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>js/jquery.lazyload.min.js"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>js/iscroll.js"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>js/common.min.js"></script>
<div class="hide"><?php echo $maccms['site_tj']; ?></div>
<style>
	@media (max-width: 767px)
	{
		.reply_box .mac_msg_l{padding: 0;}
		.block-xs{
			width: 96%!important;margin: 15px 2%!important;
		}
		.reply_box .mac_msg_l .msg_tag { width: 55px!important;}
	}
</style>
</body>
</html>