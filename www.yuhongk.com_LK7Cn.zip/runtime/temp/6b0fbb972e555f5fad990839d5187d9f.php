<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:34:"template/xxys/html/vod/detail.html";i:1586133492;s:66:"/www/wwwroot/www.dgcsqz.com/template/xxys/html/public/include.html";i:1586132902;s:63:"/www/wwwroot/www.dgcsqz.com/template/xxys/html/public/head.html";i:1586133662;s:63:"/www/wwwroot/www.dgcsqz.com/template/xxys/html/public/foot.html";i:1586133782;}*/ ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE10" />
    <meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <title>《<?php echo $obj['vod_name']; ?>》<?php echo $obj['type_1']['type_name']; ?>详情介绍<?php echo $obj['type']['type_name']; ?>_高清完整版迅雷下载-免费在线观看 - <?php echo $maccms['site_name']; ?></title>
    <meta name="keywords" content="<?php echo $obj['vod_name']; ?>在线收看,<?php echo $obj['vod_name']; ?>完整版" />
    <meta name="description" content="<?php echo $obj['vod_name']; ?>剧情:<?php echo $obj['vod_blurb']; ?>" />
    
		<link rel="shortcut icon" href="<?php echo $maccms['path_tpl']; ?>images/favicon.ico" type="image/x-icon" />
		<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>css/style.css" type="text/css" />
		<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>css/font-awesome.min.css" type="text/css" />
		<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>css/global.css" type="text/css" />
		<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>css/font-awesome.min.css" type="text/css" />
		<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>js/jquery.min.js"></script>
		<script src="<?php echo $maccms['path_tpl']; ?>js/hd.js"></script>
		<script src="<?php echo $maccms['path_tpl']; ?>js/common.js"></script>
		<script src="<?php echo $maccms['path_tpl']; ?>js/function.js"></script>
		<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
		<script src="<?php echo $maccms['path']; ?>static/js/home.js"></script>
		<style type="text/css">
		.pc_acmsd{display:block;}
		.m_acmsd{ display:none}
		@media(max-width:768px) {
		.pc_acmsd{display:none !important;}
		.m_acmsd{display:block !important;}
		}
		</style>
	</head>
  <body>
    
<!--wap端头部-->
<div class="m_acmsd">
<div class="wrapper">
<div class="mask" id="mask_box"></div>
<header class="header1 clearfix" id="header">
<p class="headLeft"><a href="<?php echo $maccms['path']; ?>" class="aLogo"></a></p>
<p class="headRight">
<a href="javascript:void(0);" class="aNav"><span>导航</span></a>
<a href="javascript:void(0);" class="aSearch"><span>搜索</span></a>
<a href="<?php echo mac_url('gbook/index'); ?>" class="aHome"><span id="unameHeader">求片</span></a>
</p>
</header>
<nav class="subNav globalPadding index_menu_top" id="nav_menu" style="display:none;">
<div class="con clearfix">
<p>
<a href="<?php echo $maccms['path']; ?>" title="首页" class="<?php if($maccms['aid'] == 1): ?> cur<?php endif; ?>">首页</a>
<?php $__TAG__ = '{"num":"10","order":"asc","by":"sort","ids":"1,2,3,4","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
<a  href="<?php echo mac_url_type($vo); ?>" class="<?php echo $vo['type_id']; ?>=<?php echo $vo['type_pid']; if(($vo['type_id'] == $GLOBALS['type_id'] || $vo['type_id'] == $GLOBALS['type_pid'])): ?> cur<?php endif; ?>"><?php echo $vo['type_name']; ?></a>
<?php endforeach; endif; else: echo "" ;endif; ?>
</p>
</div>
</nav>
<section id="search_box" class="searchMenu" style="display:none">
<form id="search" name="search" method="get" action="<?php echo mac_url('vod/search'); ?>" onSubmit="return qrsearch();" >
<div class="searchFormCon globalPadding">
<p class="pSearchForm">
<input type="text" class="searchTxt searchTxtBlur ac_input mac_wd" name="wd" autocomplete="off" value="<?php echo $param['wd']; ?>" placeholder="请输入影片名称" /><input type="submit" value="" class="searchBtn search-button sub" id="searchbutton"><i class="clearSearchBtn" style="display:none;"><em></em></i>
</p>
</div>
</form>        
</section> 
<?php $__TAG__ = '{"num":"1","order":"desc","by":"time","level":"1","id":"vo","key":"key"}';$__LIST__ = model("Art")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
<div style='color:red;padding: 5px;margin: 10 5px;margin-top: 5px;font-size: 14px;border: 1px solid red;'>
<?php echo mac_url_content_img($vo['art_content']); ?>	
</div>
<?php endforeach; endif; else: echo "" ;endif; ?>
<div style="margin-top:10px;"></div>
</div>
<div style="margin-top:-80px;"></div>
</div>
<!--wap端头部 end-->
<div class="pc_acmsd">
<div class="header clearfix">
<div class="head wrap clearfix">
<div class="logo"><a href="<?php echo $maccms['path']; ?>"></a></div>



<div class="searchvod">
<form name="formsearch" id="formsearch" action="<?php echo mac_url('vod/search'); ?>" method="post" target="_self">
<input type="text" id="searchword" name="wd" class="search-input" value="请输入影片名称>>>" onfocus="if(this.value=='请输入影片名称>>>'){this.value='';}" onblur="if(this.value==''){this.value='请输入影片名称>>>';};">
<input type="submit" name="submit" class="sub" value="搜&nbsp;索">
</form>
<div class="hotwords mbyc">热搜：
 <?php $_67bf14fd58abf=explode(',',$maccms['search_hot']); if(is_array($_67bf14fd58abf) || $_67bf14fd58abf instanceof \think\Collection || $_67bf14fd58abf instanceof \think\Paginator): if( count($_67bf14fd58abf)==0 ) : echo "" ;else: foreach($_67bf14fd58abf as $key2=>$vo2): ?>
<a href="<?php echo mac_url('vod/search',['wd'=>$vo2]); ?>"><?php echo $vo2; ?></a>
<?php endforeach; endif; else: echo "" ;endif; ?>
</div>
</div>


<a href="javascript:void(0);" target="_self" class="caidan_btn pcyc"><i class="caidan"></i><span>导航</span></a>
<ul id="tbmov-plus" class="mbyc">
<li><a id="new" href="<?php echo mac_url('label/new'); ?>"><i class="ui-icon new-icon"></i>最近<br>更新</a></li>
<li><a href="<?php echo mac_url('label/hot'); ?>"><i class="ui-icon top-icon"></i>影片<br>排行</a></li>
<li><a rel="nofollow" href="<?php echo mac_url('gbook/index'); ?>"><i class="ui-icon gb-icon"></i>留言<br>反馈</a></li>
<li><a rel="nofollow" target="_self" id="a-clo" href="javascript:void(0);" onmouseout="hideImg()" onmouseover="showImg()">手机<br>观看</a></li>
<div id="wxImg" style="display:none;position: absolute; top: 85px; right: 0; z-index: 100;"><p style="text-align: center;">扫描二维码，访问《<?php echo $maccms['site_name']; ?>》</p><img src="http://qr.topscan.com/api.php?bg=f3f3f3&fg=ff0000&gc=222222&el=l&w=200&m=10&text=http://<?php echo $maccms['site_url']; ?>"></div>
</ul>	
</div>
<div class="sjmenu pcyc">
<ul class="nav wrap clearfix">
<li class="<?php if($maccms['aid'] == 1): ?> current<?php endif; ?>"><a href="<?php echo $maccms['path']; ?>"><i class="fa fa-home"></i>首页</a></li>
<?php $__TAG__ = '{"num":"10","order":"asc","by":"sort","ids":"parent","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
<li><a href="<?php echo mac_url_type($vo); ?>"><?php echo $vo['type_name']; ?></a></li>
<?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
</div>
<div class="menu mbyc">
<ul class="nav wrap clearfix">
<li class="<?php if($maccms['aid'] == 1): ?> current<?php endif; ?>"><a href="<?php echo $maccms['path']; ?>"><i class="fa fa-home"></i>首页</a></li>
<?php $__TAG__ = '{"num":"10","order":"asc","by":"sort","ids":"1,2,3,4","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
<li class="<?php echo $vo['type_id']; ?>=<?php echo $vo['type_pid']; if(($vo['type_id'] == $GLOBALS['type_id'] || $vo['type_id'] == $GLOBALS['type_pid'])): ?> current<?php endif; ?>"><a href="<?php echo mac_url_type($vo); ?>"><?php echo $vo['type_name']; ?></a></li>
<?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
</div>
<div id="subnav" class="mbyc">
<div class="layout fn-clear">
<?php $__TAG__ = '{"ids":"1","order":"asc","by":"sort","id":"vo1","key":"key1","flag":"vod"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key1 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo1): $mod = ($key1 % 2 );++$key1;?>		
<div class="subnav-tv fn-left"><strong class="movie"><?php echo $vo1['type_name']; ?>：</strong>
<?php $__TAG__ = '{"parent":"'.$vo1['type_id'].'","order":"asc","by":"sort","id":"vo2","key":"key2"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key2 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo2): $mod = ($key2 % 2 );++$key2;?>
<a href="<?php echo mac_url_type($vo2,[],'show'); ?>"><?php echo $vo2['type_name']; ?></a><em>|</em>
<?php endforeach; endif; else: echo "" ;endif; ?>
</div>
<?php endforeach; endif; else: echo "" ;endif; $__TAG__ = '{"ids":"2","order":"asc","by":"sort","id":"vo1","key":"key1","flag":"vod"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key1 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo1): $mod = ($key1 % 2 );++$key1;?>		
<div class="subnav-tv fn-right"><strong class="tv"><?php echo $vo1['type_name']; ?>：</strong>
<?php $__TAG__ = '{"parent":"'.$vo1['type_id'].'","order":"asc","by":"sort","id":"vo2","key":"key2"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key2 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo2): $mod = ($key2 % 2 );++$key2;?>
<a href="<?php echo mac_url_type($vo2,[],'show'); ?>"><?php echo $vo2['type_name']; ?></a><em>|</em>
<?php endforeach; endif; else: echo "" ;endif; ?>
</div>
<?php endforeach; endif; else: echo "" ;endif; ?>
</div>
</div>
</div>
<div style="margin-top:10px;"></div>
</div>
	<div class="wrap">
			<div class="stit mb_none clearfix">
				<span class="ico gang1"></span>
				<a href="<?php echo $maccms['path']; ?>">首页</a>  »  
				<a href="<?php echo mac_url_type($obj,[],'show'); ?>"><?php echo $obj['type']['type_name']; ?></a> » <?php echo $obj['vod_name']; ?>
			</div>
			<div class="row_top">
				<div class="detail_all">
					<div class="detail clearfix">
						<div class="detail_name mb_none clearfix">
							<span class="name"><?php echo $obj['vod_name']; ?></span>
						</div>
						<div class="detail_img">
							<img class="dpic" src="<?php echo mac_url_img($obj['vod_pic']); ?>">
						</div>
						<div class="detail_text">
							<p class="name pc_none"><?php echo $obj['vod_name']; ?></p>
						<div class="dlall">
							<div class="dl clearfix">
								<dl>
									<dt>主演：</dt>
									<dd><?php echo mac_url_create(mac_substring($obj['vod_actor'],35),'actor'); ?> </dd>
								</dl>
								<dl>
									<dt>备注：</dt>
									<dd><?php if($obj['vod_remarks'] != ''): ?><?php echo $obj['vod_remarks']; elseif($obj['vod_serial'] > 0): ?>第<?php echo $obj['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></dd>
								</dl>
								<dl>
									<dt>扩展：</dt>
									<dd><?php echo mac_url_create($obj['vod_class'],'class'); ?></dd>
								</dl>
								<dl class="pc_acmsd">
									<dt>点击：</dt>
									<dd><?php echo $obj['vod_hits']; ?></dd>
								</dl>
								<dl class="dl_left pc_acmsd">
									<dt>地区：</dt>
									<dd><?php echo $obj['vod_area']; ?></dd>
								</dl>
								<dl class="dl_right mb_none">
									<dt>导演：</dt>
									<dd><?php echo mac_url_create($obj['vod_director'],'director'); ?>  </dd>
								</dl>
								<dl class="dl_left">
									<dt>年代：</dt>
									<dd><?php echo mac_url_create($obj['vod_year'],'year'); ?></dd>
								</dl>
								<dl class="dl_left">
									<dt>更新：</dt>
									<dd><?php echo date('Y-m-d',$obj['vod_time']); ?></dd>
								</dl>
								<dl class="dl_right mb_none">
									<dt>语言：</dt>
									<dd><?php echo $obj['vod_lang']; ?></dd>
								</dl>
							</div>
							<dl class="pcjq mb_none">
								<dt>剧情：</dt>
								<dd><?php echo mac_substring(mac_filter_html($obj['vod_content']),30); ?>
									<a class="pcjqxx" href="#pcjq">详细</a>
								</dd>
							</dl>
						</div>
					</div>
				</div>
				<div class="detail_r clearfix">
			
				</div>
			</div>
		</div>
		<?php if(is_array($obj['vod_play_list']) || $obj['vod_play_list'] instanceof \think\Collection || $obj['vod_play_list'] instanceof \think\Paginator): if( count($obj['vod_play_list'])==0 ) : echo "" ;else: foreach($obj['vod_play_list'] as $key=>$vo): ?>
		<div id="stab11" class="row clearfix">
			<div class="playlist clearfix">
				<div class="ptit clearfix">
					<i class="bflogo ico_zkm3u8"></i><b><?php echo $vo['player_info']['show']; ?></b>-电脑手机播放-无法播放换线路
				</div>
				<ul class="ulli clearfix">
					<div id="stab_11" class="stab_list">
						<ul class="clearfix">
							<?php if(is_array($vo['urls']) || $vo['urls'] instanceof \think\Collection || $vo['urls'] instanceof \think\Paginator): if( count($vo['urls'])==0 ) : echo "" ;else: foreach($vo['urls'] as $key2=>$vo2): ?>
							<li>
								<a href="<?php echo mac_url_vod_play($obj,['sid'=>$vo['sid'],'nid'=>$vo2['nid']]); ?>" target="_self"><?php echo $vo2['name']; ?></a>
							</li>
							<?php endforeach; endif; else: echo "" ;endif; ?>
						</ul>
					</div>
				</ul>
			</div>
		</div>
		<?php endforeach; endif; else: echo "" ;endif; ?>
		<div class="row">
			<div class="ndes" id="pcjq">
				<div class="ptit">
					<i class="gang"></i>猜你喜欢
				</div>
				<div class="channel">
					<div class="list contentlis clearfix">
						<ul class="cont1 clearfix">
							<?php $__TAG__ = '{"num":"6","type":"current","order":"desc","by":"rnd","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
							<li>
								<div class="li_li clearfix">
									<div class="li_all">
										<div class="li_img">
											<a href="<?php echo mac_url_vod_detail($vo); ?>"><img class="dpic dh" src="<?php echo mac_url_img($vo['vod_pic']); ?>">
												<span class="rgba1"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></span></a>
										</div>
										<div class="li_text">
											<p class="name">
												<a href="<?php echo mac_url_vod_detail($vo); ?>"><?php echo $vo['vod_name']; ?></a>
											</p>
											<p class="actor"><?php echo mac_default($vo['vod_actor'],'内详'); ?></p>
										</div>
										<a class="alink" href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>"></a>
									</div>
								</div>
							</li>
							<?php endforeach; endif; else: echo "" ;endif; ?>
						</ul>
						<ul class="txt-list txt-list-small clearfix">
							<?php $__TAG__ = '{"num":"20","type":"current","order":"desc","by":"rnd","start":"13","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
							<li><span><?php echo $key; ?>.</span>
								<a href="<?php echo mac_url_vod_detail($vo); ?>"><?php echo $vo['vod_name']; ?></a> <?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?>
							</li>
							<?php endforeach; endif; else: echo "" ;endif; ?>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="ndes" id="pcjq">
				<div class="ptit">
					<i class="gang"></i>《<?php echo $obj['vod_name']; ?>》剧情简介
				</div>
				<div class="des_xy">
					<?php echo mac_filter_html($obj['vod_content']); ?>
				</div>
			</div>
		</div>
		</div>
		
<div class="footer clearfix">
<div class="wrap">
<p>本站只提供WEB页面服务，本站不存储、不制作任何视频，不承担任何由于内容的合法性及健康性所引起的争议和法律责任。</p>
<p>若本站收录内容侵犯了您的权益，请附说明联系邮箱，本站将第一时间处理。</p>
<p><div id="footer"><div class="flink"><a href="/rss/index.xml">RSS</a>｜<a href="/rss/baidu.xml">Baidu SiteMap</a>｜<a href="<?php echo mac_url('rss/google'); ?>">Google SiteMap</a>｜<a href="<?php echo mac_url('rss/sogou'); ?>">sogou SiteMap</a>｜<a href="<?php echo mac_url('rss/sm'); ?>">sm SiteMap</a></p>
<p>Copyright© 2020 <?php echo $maccms['site_name']; ?> All Rights Reserved</p>
</div>					
<div class="gotop" style="display: block;">
<a href="javascript:; " title="返回顶部"><i class="ico gotopbg"></i></a><a href="<?php echo mac_url('gbook/index'); ?>"><i class="ico gbbg"></i></a>
</div>
</div>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>js/jquery.lazyload.min.js"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>js/iscroll.js"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>js/common.min.js"></script>
<div class="hide"><?php echo $maccms['site_tj']; ?></div>
  </body>
</html>