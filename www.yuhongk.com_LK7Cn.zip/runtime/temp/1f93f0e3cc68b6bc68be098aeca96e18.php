<?php if (!defined('THINK_PATH')) exit(); /*a:6:{s:38:"template/xiaoxiao/html/vod/detail.html";i:1740658153;s:69:"/www/wwwroot/www.dgcsqz.com/template/xiaoxiao/html/block/include.html";i:1740583306;s:66:"/www/wwwroot/www.dgcsqz.com/template/xiaoxiao/html/block/seos.html";i:1740583936;s:66:"/www/wwwroot/www.dgcsqz.com/template/xiaoxiao/html/block/head.html";i:1740582183;s:69:"/www/wwwroot/www.dgcsqz.com/template/xiaoxiao/html/block/vod_box.html";i:1708691960;s:66:"/www/wwwroot/www.dgcsqz.com/template/xiaoxiao/html/block/foot.html";i:1740576608;}*/ ?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<?php if($maccms['aid']==1): ?><!-- 首页 -->
<title><?php echo $maccms['site_name']; ?>_小小影院_小小电影网_<?php echo date('Y'); ?>最新免费在线电影电视剧</title>
<meta name="keywords" content="<?php echo $maccms['site_name']; ?>" />
<meta name="description" content="<?php echo date('Y'); ?>最新影院电影、热播电视剧、网剧免费观看，最快每天同步更新数据，更新最快最全的电影电视剧收录大全，热播好剧热映电影免费观看就上<?php echo $maccms['site_name']; ?>。" />
<?php elseif($maccms['aid']==7): ?><!-- 排行榜 -->
<title><?php echo date('Y'); ?>最新100个热门影片排行榜推荐 - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo date('Y'); ?>最新100个热门影片" />
<meta name="description" content="<?php echo date('Y'); ?>最新100个热门影片排行榜推荐，不知道看什么？来看看这个推荐的排行榜吧！" />
<?php elseif($maccms['aid']==11): ?><!-- 分类 -->
<title><?php echo date('Y'); ?>最新<?php echo $obj['type_name']; ?> - 好看的<?php echo $obj['type_name']; ?>推荐 - 第<?php echo $param['page']; ?>页 - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo date('Y'); ?>最新<?php echo $obj['type_name']; ?>" />
<meta name="description" content="<?php echo $maccms['site_name']; ?>为广大网友提供最新<?php echo $obj['type_name']; ?>、全集<?php echo $obj['type_name']; ?>、最近热播<?php echo $obj['type_name']; ?>免费观看，高清画质纵享丝滑不卡顿，第一时间更新推送最新<?php echo $obj['type_name']; ?>，在线观看无套路。" />
<?php elseif($maccms['aid']==12): ?><!-- 筛选 -->
<title><?php echo date('Y'); ?>最新<?php echo $obj['type_name']; ?>筛选 - 好看的<?php echo $obj['type_name']; ?>推荐 - 第<?php echo $param['page']; ?>页 - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo date('Y'); ?>最新<?php echo $obj['type_name']; ?>" />
<meta name="description" content="<?php echo $maccms['site_name']; ?>为广大网友提供最新<?php echo $obj['type_name']; ?>、全集<?php echo $obj['type_name']; ?>、最近热播<?php echo $obj['type_name']; ?>免费观看，高清画质纵享丝滑不卡顿，第一时间更新推送最新<?php echo $obj['type_name']; ?>，在线观看无套路。" />
<?php elseif($maccms['aid']==13): ?><!-- 搜索 -->
<meta name="robots" content="noindex,follow" />
<title>搜索：<?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?> - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?>" />
<meta name="description" content="搜索结果：<?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?>相关影片全集免费在线观看，高清全集完整版免费观看无删减，更多与<?php echo $param['wd']; ?>相关结果尽在<?php echo $maccms['site_name']; ?>！" />
<?php elseif($maccms['aid']==14): ?><!-- 详情 -->
<title>《<?php echo $obj['vod_name']; ?>》<?php if(($obj['type']['type_id'] == 1) || ($obj['type']['type_id'] == 57) || ($obj['type_id_1'] == 1)): ?>免费在线观看完整版<?php else: ?>免费在线观看全集<?php endif; ?> - <?php echo $obj['type']['type_name']; ?> - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo $obj['vod_name']; if(($obj['type']['type_id'] == 1) || ($obj['type']['type_id'] == 57) || ($obj['type_id_1'] == 1)): ?>免费在线观看完整版<?php else: ?>免费在线观看全集<?php endif; ?>" />
<meta name="description" content="<?php echo $obj['vod_name']; ?>剧情：<?php echo mac_substring($obj['vod_blurb'],90); ?>" />
<?php elseif($maccms['aid']==15): ?><!-- 播放 -->
<title>《<?php echo $obj['vod_name']; ?>》<?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?>在线播放免费观看 - <?php echo $obj['type']['type_name']; ?> - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo $obj['vod_name']; ?>在线播放免费观看" />
<meta name="description" content="<?php echo $obj['vod_name']; ?>剧情：<?php echo mac_substring($obj['vod_blurb'],90); ?>" />
<?php endif; ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta name="applicable-device" content="pc,mobile">
<meta http-equiv="Cache-Control" content="no-siteapp,no-transform">
<meta name="renderer" content="webkit">
<link rel="shortcut icon" href="<?php echo $maccms['path_tpl']; ?>statics/img/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>statics/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>statics/css/system.css?v=1.4">
<script src="<?php echo $maccms['path_tpl']; ?>statics/js/jquery.min.js"></script>
<script src="<?php echo $maccms['path_tpl']; ?>statics/js/jquery.lazyload.js"></script>
<script src="<?php echo $maccms['path_tpl']; ?>statics/js/bootstrap.min.js"></script>
<script src="<?php echo $maccms['path_tpl']; ?>statics/js/system.js"></script>
<script src="<?php echo $maccms['path_tpl']; ?>statics/js/ban.js"></script>
<script src="/static/js/home.js"></script>
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<!--[if lt IE 9]>
<script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
<script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body>
<nav class="navbar navbar-inverse" role="navigation">
  <div class="container"><a href="/" class="aLogo"><?php echo $maccms['site_name']; ?></a>
    <ul class="nav navbar-nav navbar-left visible-lg visible-md">
		<li <?php if($maccms['aid'] == 1): ?>class="active"<?php endif; ?>><a href="<?php echo $maccms['path']; ?>">首页</a></li>
		<?php $__TAG__ = '{"num":"10","order":"asc","by":"sort","ids":"parent","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
		<li <?php if(($vo['type_id'] == $GLOBALS['type_id'] || $vo['type_id'] == $GLOBALS['type_pid'])): ?>class="active"<?php endif; ?>><a href="<?php echo mac_url_type($vo); ?>"><?php echo $vo['type_name']; ?></a></li>
		<?php endforeach; endif; else: echo "" ;endif; ?>
        <li <?php if($maccms['aid'] == 7): ?>class="active"<?php endif; ?>><a href="<?php echo mac_url('label/hot'); ?>">排行榜</a></li>
    </ul>
    <!--<p class="navbar-text navbar-right"><span class="glyphicon glyphicon-phone" data-toggle="popover" data-trigger="hover" data-placement="left" data-container="body" data-title="手机浏览请扫瞄二维码"></span></p>-->
    <div class="Header_search">
      <form class="ff-search" id="ff-search" role="search" action="<?php echo mac_url('vod/search'); ?>" method="get">
        <div class="form-group"> <i class="icon-search"></i>
          <input type="text" class="form-control" id="ff-wd" name="wd" value="<?php echo $param['wd']; ?>" required="required" placeholder="输入关键词搜索^_^">
        </div>
        <button type="submit" class="btn btn-default">搜索</button>
      </form>
    </div>
  </div>
</nav>
<!-- 简化导航 
<div class="container ff-nav visible-xs visible-sm">
  <div class="row">
    <ul class="list-inline">
      <li class="col-xs-3 text-left">
        <h4><a href="javascript:;" id="ff-goback"><span class="glyphicon glyphicon-chevron-left"></span></a></h4>
      </li>
      <li class="col-xs-6 text-center">
        <h4><?php echo $maccms['site_name']; ?></h4>
      </li>
      <li class="col-xs-3 text-right">
        <h4> <a href="/"><span class="glyphicon glyphicon-home"></span></a> <a href="<?php echo mac_url('label/search'); ?>"><span class="glyphicon glyphicon-search"></span></a></h4>
      </li>
    </ul>
  </div>
</div>
-->
<div class="container ff-bg">
  <div class="row">
    <div class="clearfix"></div>
    <ul class="row list-unstyled text-center index-nav visible-xs visible-sm">
		<li class="col-xs-4"><a href="<?php echo $maccms['path']; ?>" class="btn btn-success btn-block">首页</a></li>
		<?php $__TAG__ = '{"num":"10","order":"asc","by":"sort","ids":"parent","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
        <li class="col-xs-4"> <a href="<?php echo mac_url_type($vo); ?>" class="btn btn-success btn-block"><?php echo $vo['type_name']; ?></a></li>
		<?php endforeach; endif; else: echo "" ;endif; ?>
		<!--<li class="col-xs-4"><a href="<?php echo mac_url('label/hot'); ?>" class="btn btn-success btn-block">排行榜</a></li>-->
  </div>
</div>
<div class="clearfix ff-clearfix"></div><!-- 头部 -->
<div class="container vod-detail ff-bg">
  <div class="row">
    <div class="col-md-8 ff-col">
      <div class="page-header">
        <h4><span class="glyphicon glyphicon-film ff-text"></span><a href="<?php echo $maccms['path']; ?>">首页</a><?php if(!empty($obj['type_id_1'])): ?><i>&gt;</i><a href="<?php echo mac_url_type($obj['type_1']); ?>"><?php echo $obj['type_1']['type_name']; ?></a><?php endif; ?><i>&gt;</i><a href="<?php echo mac_url_type($obj,[],'show'); ?>"><?php echo $obj['type']['type_name']; ?></a><i>&gt;</i><a href="<?php echo mac_url_vod_detail($obj); ?>"><?php echo $obj['vod_name']; ?></a></h4>
      </div>
      <ul class="list-unstyled vod-infos">
        <li class="col-xs-4 ff-col-0"> <img class="img-responsives ff-img vod-pic" src="<?php echo $maccms['path_tpl']; ?>statics/img/nopic.jpg" data-original="<?php echo mac_url_img($obj['vod_pic']); ?>" alt="<?php echo $obj['vod_name']; ?>"><div class="douban_score picrgot"><em class="label littplus"><?php if($obj['vod_remarks'] != ''): ?><?php echo $obj['vod_remarks']; elseif($obj['vod_serial'] > 0): ?>第<?php echo $obj['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></em></div></li>
        <li class="col-xs-8">
          <h4><?php echo $obj['vod_name']; ?></h4>
          <dl class="dl-horizontal">
            <dt>主演：</dt>
            <dd class="ff-text-hidden ff-nb"><?php echo mac_default(mac_url_create(mac_substring($obj['vod_actor'],60),'actor'),'未录入'); ?></dd>
            <dt>类型：</dt>
            <dd class="ff-text-hidden ff-nb"><a href="<?php echo mac_url_type($obj,[],'show'); ?>"><?php echo $obj['type']['type_name']; ?></a>
            <dt>导演：</dt>
            <dd class="ff-text-hidden ff-nb"><?php echo mac_default(mac_url_create(mac_substring($obj['vod_director'],18),'director'),'未录入'); ?></dd>
            <dt class="hidden-xs">地区：</dt>
            <dd class="hidden-xs"><?php echo mac_default($obj['vod_area'],'未录入'); ?></dd>
            <dt>年份：</dt>
            <dd><?php echo mac_default($obj['vod_year'],'未录入'); ?></dd>
            <dt class="hidden-xs">简介：</dt>
            <dd class="hidden-xs vod-content"><?php echo mac_substring(mac_filter_html($obj['vod_content']),100); ?><a href="#vod_content" class="btn btn-link ff-text">详细...</a></dd>
          </dl>
        </li>
      </ul>
      <div class="clearfix ff-clearfix"></div>
	  <!-- 播放列表 -->
	  <ul class="nav nav-tabs" id="ff-tab">
		<?php if(is_array($obj['vod_play_list']) || $obj['vod_play_list'] instanceof \think\Collection || $obj['vod_play_list'] instanceof \think\Paginator): if( count($obj['vod_play_list'])==0 ) : echo "" ;else: foreach($obj['vod_play_list'] as $key=>$vo): ?>
        <li><a href="#playlist<?php echo $key; ?>" data-toggle="tab"><span class="glyphicon glyphicon-play-circle"></span><?php echo $vo['player_info']['show']; ?></a></li>
		<?php endforeach; endif; else: echo "" ;endif; ?>
      </ul>
      <div class="tab-content" id="ff-tab-content">
	  <?php if(is_array($obj['vod_play_list']) || $obj['vod_play_list'] instanceof \think\Collection || $obj['vod_play_list'] instanceof \think\Paginator): if( count($obj['vod_play_list'])==0 ) : echo "" ;else: foreach($obj['vod_play_list'] as $key=>$vo): ?>
	  <div class="js-tab-content tab-pane fade in" id="playlist<?php echo $key; ?>">
          <ul class="list-unstyled-play text-center play-list">
			<?php $_67c056b5e256c=array_reverse($vo['urls']); if(is_array($_67c056b5e256c) || $_67c056b5e256c instanceof \think\Collection || $_67c056b5e256c instanceof \think\Paginator): if( count($_67c056b5e256c)==0 ) : echo "" ;else: foreach($_67c056b5e256c as $key=>$vo2): ?>
			<li class="col-md-2 col-sm-3 col-xs-4 <?php if($param['sid'] == $vo['sid'] && $param['nid'] == $vo2['nid']): ?>active<?php endif; ?>"><a href="<?php echo mac_url_vod_play($obj,['sid'=>$vo['sid'],'nid'=>$vo2['nid']]); ?>" class="btn btn-default btn-sm"><?php echo $vo2['name']; ?></a></li>
			<?php endforeach; endif; else: echo "" ;endif; ?>
          </ul>
      </div>
	  <?php endforeach; endif; else: echo "" ;endif; ?>
      </div>
<script type="text/javascript">
	$(".tab-pane:first,.nav-tabs li:first").addClass("active");
</script>
	  <!-- 播放列表 end -->
	  <!-- 猜你喜欢 -->
	  <div class="clearfix ff-clearfix"></div>
	  <div class="page-header">
		<h4><span class="glyphicon glyphicon-heart-empty ff-text"></span> 猜你喜欢</h4>
      </div>
      <ul class="list-unstyled-index">
		<?php $__TAG__ = '{"num":"12","type":"current","order":"desc","by":"time","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
		<li class="ff-vod-img-list col-md-3 col-sm-2 col-xs-4 text-center ff-col ff-vod-img-hot">
<a href="<?php echo mac_url_vod_detail($vo); ?>"><img class="img-responsives ff-img" src="<?php echo $maccms['path_tpl']; ?>statics/img/nopic.jpg" data-original="<?php echo mac_url_img($vo['vod_pic']); ?>" alt="<?php echo $vo['vod_name']; ?>">
<div class="douban_score picrgot"><em class="label littplus"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></em></div>
</a>
<h4 class="ff-text-hidden"> <a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a> </h4>
</li>
	    <?php endforeach; endif; else: echo "" ;endif; ?>
      </ul>
	  <!-- 猜你喜欢 end -->
	  <!-- 剧情简介 -->
	  <div class="clearfix ff-clearfix"></div>
      <div class="page-header"> <a name="vod_content"></a>
        <h4><span class="glyphicon glyphicon-th-list ff-text"></span> 剧情简介</h4>
      </div>
      <div class="vod-content">
		<?php echo mac_filter_html($obj['vod_content']); ?>
      </div>
	<!-- 剧情简介 end -->
	</div>
	<!-- 热播榜 -->
		<div class="col-md-4 ff-col index-right visible-lg visible-md">
      <div class="page-header">
        <h4><span class="glyphicon glyphicon-signal ff-text"></span> 本月热播</h4>
      </div>
      <ol class="ff-vod-hot">
	  <?php $__TAG__ = '{"num":"30","type":"current","order":"desc","by":"hits_month","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
	  <li><i <?php if($key == 1): ?> class="n1"<?php endif; if($key == 2): ?> class="n1"<?php endif; if($key == 3): ?> class="n1"<?php endif; ?>><?php echo $key; ?></i><a href="<?php echo mac_url_vod_detail($vo); ?>"><?php echo $vo['vod_name']; ?></a> <small class="pull-right"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></small></li>
	  <?php endforeach; endif; else: echo "" ;endif; ?>
	  </ol>
    </div>
	<!-- 热播帮榜end -->
  </div>
</div>
<div class="clearfix ff-clearfix"></div>
<div class="ff-footer">
  <div class="container">
    <div class="row">
      <div class="col-md-10 col-sm-12 col-xs-12"> 
        <p class="hide"><?php echo $maccms['site_tj']; ?></p>
        <p>友情提示：请勿长时间观看影视，注意保护视力并预防近视，合理安排时间，享受健康生活。</p>
        <p>版权声明：<?php echo $maccms['site_name']; ?>为非赢利性站点，本网站所有内容均来源于互联网相关站点自动搜索采集信息，相关链接已经注明来源。</p>
        <p>免责声明：<?php echo $maccms['site_name']; ?>将逐步删除和规避程序自动搜索采集到的不提供分享的版权影视。本站<?php echo $maccms['site_name']; ?>仅供测试和学习交流。请大家支持正版。</p>
      </div>
      <ul class="col-md-2 hidden-sm hidden-xs">
        <li><a href="<?php echo mac_url('rss/index'); ?>" target="_blank">sitemap</a></li>
      </ul>
    </div>
  </div>
</div>
<!--百度推送-->
<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
<!--百度推送 end--><!-- 页脚 -->
</body>
</html>