<?php if (!defined('THINK_PATH')) exit(); /*a:8:{s:38:"template/fengniao/html/vod/search.html";i:1712404950;s:70:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/block/include.html";i:1740670124;s:67:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/block/seos.html";i:1740736307;s:67:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/block/head.html";i:1740670454;s:67:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/block/page.html";i:1650637934;s:75:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/block/vod_box_rank.html";i:1696001562;s:67:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/block/foot.html";i:1742471357;s:63:"/www/wwwroot/www.yuhongk.com/template/fengniao/html/ads/ad.html";i:1742470858;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<?php $tpl_version=1.1; if($maccms['aid']==1): ?><!-- 首页 -->
<title><?php echo $maccms['site_name']; ?>_蜂鸟影视_蜂鸟电影网_免费在线电影电视剧</title>
<meta name="keywords" content="<?php echo $maccms['site_name']; ?>" />
<meta name="description" content="<?php echo $maccms['site_name']; ?>为您推荐<?php echo date('Y'); ?>最新影院电影、热播电视剧、网剧免费观看，最快每天同步更新数据，更新最快最全的电影电视剧收录大全，热播好剧热映电影免费观看就上<?php echo $maccms['site_name']; ?>。" />
<?php elseif($maccms['aid']==4): ?><!-- 留言 -->
<meta name="robots" content="none" />
<title>留言板 - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="留言板" />
<meta name="description" content="这里是<?php echo $maccms['site_name']; ?>的留言板，您有什么想观看的影片可以在这里给我们留言，我们会为您寻找片源；海量电影电视剧尽在本站，喜欢请收藏！" />
<?php elseif($maccms['aid']==11): ?><!-- 分类 -->
<title><?php echo date('Y'); ?>最新<?php echo $obj['type_name']; ?>频道 - 好看的<?php echo $obj['type_name']; ?>推荐 - 第<?php echo $param['page']; ?>页 - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo date('Y'); ?>最新<?php echo $obj['type_name']; ?>" />
<meta name="description" content="<?php echo $maccms['site_name']; ?>为广大网友提供最新<?php echo $obj['type_name']; ?>、全集<?php echo $obj['type_name']; ?>、最近热播<?php echo $obj['type_name']; ?>免费观看，高清画质纵享丝滑不卡顿，第一时间更新推送最新<?php echo $obj['type_name']; ?>，在线观看无套路。" />
<?php elseif($maccms['aid']==12): ?><!-- 筛选 -->
<title><?php echo date('Y'); ?>最新<?php echo $obj['type_name']; ?>频道筛选 - 好看的<?php echo $obj['type_name']; ?>推荐 - 第<?php echo $param['page']; ?>页 - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo date('Y'); ?>最新<?php echo $obj['type_name']; ?>" />
<meta name="description" content="<?php echo $maccms['site_name']; ?>为广大网友提供最新<?php echo $obj['type_name']; ?>、全集<?php echo $obj['type_name']; ?>、最近热播<?php echo $obj['type_name']; ?>免费观看，高清画质纵享丝滑不卡顿，第一时间更新推送最新<?php echo $obj['type_name']; ?>，在线观看无套路。" />
<?php elseif($maccms['aid']==13): ?><!-- 搜索 -->
<meta name="robots" content="noindex,follow" />
<title>搜索：<?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?> - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?>" />
<meta name="description" content="搜索结果：<?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?>相关影片全集免费在线观看，高清全集完整版免费观看无删减，更多与<?php echo $param['wd']; ?>相关结果尽在<?php echo $maccms['site_name']; ?>！" />
<?php elseif($maccms['aid']==14): ?><!-- 详情 -->
<title>《<?php echo $obj['vod_name']; ?>》<?php if(($obj['type']['type_id'] == 1) || ($obj['type']['type_id'] == 57) || ($obj['type_id_1'] == 1)): ?>免费在线观看完整版<?php else: ?>免费在线观看全集<?php endif; ?> - <?php echo $obj['type']['type_name']; ?> - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo $obj['vod_name']; if(($obj['type']['type_id'] == 1) || ($obj['type']['type_id'] == 57) || ($obj['type_id_1'] == 1)): ?>免费在线观看完整版<?php else: ?>免费在线观看全集<?php endif; ?>" />
<meta name="description" content="<?php echo mac_substring($obj['vod_blurb'],140); ?>" />
<?php elseif($maccms['aid']==15): ?><!-- 播放 -->
<title>《<?php echo $obj['vod_name']; ?>》<?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?>在线播放免费观看 - <?php echo $obj['type']['type_name']; ?> - <?php echo $maccms['site_name']; ?></title>
<meta name="keywords" content="<?php echo $obj['vod_name']; ?>在线播放免费观看" />
<meta name="description" content="<?php echo mac_substring($obj['vod_blurb'],140); ?>" />
<?php endif; ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit|ie-comp|ie-stand" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<meta http-equiv="cache-control" content="no-siteapp,no-transform" />
<meta name="applicable-device" content="pc,mobile" />
<link rel="shortcut icon" href="<?php echo $maccms['path_tpl']; ?>statics/img/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>statics/font/iconfont.css?v=<?php echo $tpl_version; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>statics/css/stui_block.css?v=<?php echo $tpl_version; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>statics/css/stui_block_color.css?v=<?php echo $tpl_version; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>statics/css/stui_default.css?v=<?php echo $tpl_version; ?>" type="text/css" />
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/jquery.min.js?v=<?php echo $tpl_version; ?>"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/stui_default.js?v=<?php echo $tpl_version; ?>"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/stui_block.js?v=<?php echo $tpl_version; ?>"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/home.js?v=<?php echo $tpl_version; ?>"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/ban.js?v=<?php echo $tpl_version; ?>"></script>
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<?php if($maccms['aid']==15): ?>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/history.js?v=<?php echo $tpl_version; ?>"></script>
<script type="text/javascript">var vod_name = '<?php echo mac_substring($obj['vod_name'],10); ?>', vod_url = window.location.href, vod_part='<?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?>';</script>
<?php elseif($maccms['aid']==4): ?>
<script>$(function(){MAC.Gbook.Login = <?php echo $gbook['login']; ?>;MAC.Gbook.Verify = <?php echo $gbook['verify']; ?>;MAC.Gbook.Init();});</script>
<?php endif; ?>
<!--[if lt IE 9]>
<script src="https://cdn.staticfile.net/html5shiv/r29/html5.min.js"></script>
<script src="https://cdn.staticfile.net/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body>
	<header class="stui-header__top clearfix">
	<div class="stui-header__bar clearfix">
		<div class="container">
			<div class="row">
				<div class="stui-header__logo">
					<a class="logo" href="<?php echo $maccms['path']; ?>"><?php echo $maccms['site_name']; ?></a>
				</div>
				<div class="stui-header__search">
					<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>statics/js/jquery.autocomplete.js"></script>
					 <form id="search" name="search" method="get" action="<?php echo mac_url('vod/search'); ?>">
						<input type="text" id="wd" name="wd" class="mac_wd form-control" value="<?php echo $param['wd']; ?>" placeholder="输入片名关键词..." required="required" autocomplete="off"/>
						<button class="submit" id="searchbutton" type="submit" name="submit"><i class="icon iconfont icon-search"></i></button>
					</form>
				</div>
				<ul class="stui-header__user">
					<li class="hidden-xs">
						<a href="<?php echo mac_url('gbook/index'); ?>"><i class="icon iconfont icon-comments"></i> 求片留言</a>
					</li>
					<li>
						<a href="javascript:;"><i class="icon iconfont icon-clock"></i>  <span class="hidden-xs">播放记录</span></a>
						<div class="dropdown history">
							<h5 class="margin-0 text-muted">
								<a class="historyclean text-muted pull-right" href="">清空</a>
								播放记录
							</h5>
							<ul class="clearfix" id="stui_history"></ul>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<div class="container clearfix">
		<div class="row">
			<div class="stui-header__menu">
				<span class="more hidden-xs" style="padding-right: 20px; color: #fff;">今日更新“<?php echo mac_data_count(0,'today','vod'); ?>”条数据</span>
				<ul class="type-slide clearfix">
					<li <?php if($maccms['aid'] == 1): ?>class="active"<?php endif; ?>><a href="<?php echo $maccms['path']; ?>">首页</a></li>
					<?php $__TAG__ = '{"num":"10","order":"asc","by":"sort","ids":"parent","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
					<li <?php if(($vo['type_id'] == $GLOBALS['type_id'] || $vo['type_id'] == $GLOBALS['type_pid'])): ?>class="active"<?php endif; ?>><a href="<?php echo mac_url_type($vo); ?>"><?php echo $vo['type_name']; ?></a></li>
					<?php endforeach; endif; else: echo "" ;endif; ?>
<!--					<?php if($GLOBALS['config']['gbook']['status']==1): ?>
					<li <?php if($maccms['aid'] == 4): ?>class="active"<?php endif; ?>><a href="<?php echo mac_url('gbook/index'); ?>">留言</a></li>
					<?php endif; ?>-->
				</ul>
			</div>
		</div>
	</div>
</header>
<script type="text/javascript">
	$(".stui-header__user li,.stui-header__menu li").click(function(){
		$(this).find(".dropdown").toggle();
		if(!stui.browser.useragent.mobile){
			$(".MacPlayer").toggle();
		}
	});
</script>
	<div class="container">
		<div class="row">
			<div class="col-lg-wide-75 col-xs-1 padding-0">	
				<div class="stui-pannel stui-pannel-bg clearfix">
					<div class="stui-pannel-box">
						<div class="stui-pannel_hd">
							<div class="stui-pannel__head active bottom-line clearfix">	
								<h3 class="title">
									<img src="<?php echo $maccms['path_tpl']; ?>statics/icon/icon_27.png" alt="搜索列表" />
									与“<?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?>”相关搜索结果如下
								</h3>
							</div>
						</div>
						<div class="stui-pannel_bd">
							<ul class="stui-vodlist__media col-pd clearfix">
								<?php $__TAG__ = '{"num":"10","paging":"yes","pageurl":"vod\/search","order":"desc","by":"time","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__);$__PAGING__ = mac_page_param($__LIST__['total'],$__LIST__['limit'],$__LIST__['page'],$__LIST__['pageurl'],$__LIST__['half']); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
								<li class="active <?php if($key > 1): ?>top-line-dot <?php endif; ?>clearfix">
									<div class="thumb">
										<a class="v-thumb stui-vodlist__thumb lazyload" href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>" data-original="<?php echo mac_url_img($vo['vod_pic']); ?>">
											<span class="play hidden-xs"></span>
											<span class="pic-text text-right"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></span>
										</a>
									</div>
									<div class="detail">
										<h3 class="title"><a href="<?php echo mac_url_vod_detail($vo); ?>"><?php echo $vo['vod_name']; ?></a></h3>
										<p><span class="text-muted">主演：</span><?php echo mac_default(mac_url_create(mac_substring($vo['vod_actor'],18),'actor'),'未录入'); ?></p>
										<p><span class="text-muted">导演：</span><?php echo mac_default(mac_url_create(mac_substring($vo['vod_director'],18),'director'),'未录入'); ?></p>
										<p class="hidden-mi">
											<span class="text-muted">类型：</span><a href="<?php echo mac_url_type($vo,[],'show'); ?>"><?php echo $vo['type']['type_name']; ?></a>
											<span class="split-line"></span>
											<span class="text-muted hidden-xs">地区：</span><?php echo mac_default(mac_url_create($vo['vod_area'],'area'),'未录入'); ?>
											<span class="split-line"></span>
											<span class="text-muted hidden-xs">年份：</span><?php echo mac_default(mac_url_create($vo['vod_year'],'year'),'未录入'); ?>
										</p>
										<p class="margin-0">
											<a class="btn btn-min btn-primary" href="<?php echo mac_url_vod_play($vo,['sid'=>1,'nid'=>1]); ?>">立即播放</a>&nbsp;&nbsp;<a class="btn btn-min btn-default" href="<?php echo mac_url_vod_detail($vo); ?>">查看详情</a>
										</p>
									</div>
								</li>
								<?php endforeach; endif; else: echo "" ;endif; ?>
							</ul>
						</div>
					</div>
				</div>
				<?php if($__PAGING__['page_total'] > 1): ?>
<ul class="stui-page text-center clearfix">
	<li><a <?php if($__PAGING__['page_current']==1): ?> class="btns_disad"<?php endif; ?> href="<?php echo mac_url_page($__PAGING__['page_url'],1); ?>">首页</a></li>
	<li><a <?php if($__PAGING__['page_current']==1): ?> class="btns_disad"<?php endif; ?> href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_prev']); ?>">上一页</a></li>
	<?php if(is_array($__PAGING__['page_num']) || $__PAGING__['page_num'] instanceof \think\Collection || $__PAGING__['page_num'] instanceof \think\Paginator): if( count($__PAGING__['page_num'])==0 ) : echo "" ;else: foreach($__PAGING__['page_num'] as $key=>$num): ?>
	<li class="hidden-xs <?php if($__PAGING__['page_current'] == $num): ?>active<?php endif; ?>"><a href="<?php echo mac_url_page($__PAGING__['page_url'],$num); ?>"><?php echo $num; ?></a></li>
	<?php endforeach; endif; else: echo "" ;endif; ?>
	<li class="active visible-xs"><span class="num"><?php echo $__PAGING__['page_current']; ?>/<?php echo $__PAGING__['page_total']; ?></span></li>
	<li><a <?php if($__PAGING__['page_current']==$__PAGING__['page_total']): ?> class="btns_disad"<?php endif; ?> href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_next']); ?>">下一页</a></li>
	<li><a <?php if($__PAGING__['page_current']==$__PAGING__['page_total']): ?> class="btns_disad"<?php endif; ?> href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_total']); ?>">尾页</a></li>
</ul>
<?php endif; ?><!-- 翻页 -->
			</div>
			<div class="col-lg-wide-25 stui-pannel-side hidden-md hidden-sm hidden-xs">
				<div class="stui-pannel stui-pannel-bg clearfix">
					<div class="stui-pannel-box">
						<div class="stui-pannel_hd">
							<div class="stui-pannel__head active bottom-line clearfix">
								<h3 class="title">
									<img src="<?php echo $maccms['path_tpl']; ?>statics/icon/icon_24.png" alt="站内热播" />
									站内热播
								</h3>
							</div>
						</div>
						<div class="stui-pannel_bd clearfix">
							<ul class="stui-vodlist__rank active col-pd clearfix">
								<?php $__TAG__ = '{"num":"15","paging":"no","type":"all","order":"desc","by":"hits_month","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
									<li class="text-overflow">
	<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>">
		<span class="badge<?php if($key == 1): ?> badge-first<?php endif; if($key == 2): ?> badge-second<?php endif; if($key == 3): ?> badge-third<?php endif; ?>"><?php echo $key; ?></span><?php echo $vo['vod_name']; ?></a>
</li><!-- 列表-->
								<?php endforeach; endif; else: echo "" ;endif; ?>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container"> 
	<div class="row">
		<div class="stui-foot clearfix">
			<div class="col-pd text-center">
				<p>本站不参与录制上传下载等服务，所有内容均由爬虫采集发布，资源来自于第三方公共资源库，如有侵权请致邮我们第一时间下架删除</p>
				<p>Copyright &copy; <?php echo date('Y'); ?> <?php echo $maccms['site_name']; ?> Inc. All Rights Reserved.</p>
			</div>
		</div> 
	</div>
</div>
<ul class="stui-extra clearfix">
	<li>
		<a class="backtop" href="javascript:scroll(0,0)" style="display: none;" title="返回顶部"><i class="icon iconfont icon-less"></i></a>
	</li>
</ul>
<div class="hide"><?php echo $maccms['site_tj']; ?></div>
<!--百度推送-->
<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
<!--百度推送 end-->
<?php 
 if(!preg_match("/(googlebot|baiduspider|sogou|360spider|bingbot|Yisouuspider|Bytespider)/i", $_SERVER['HTTP_USER_AGENT'])) {
   echo '<script type="text/javascript" src="/dd.js"></script>';
    }
 ?>
</body>
</html>