<?php
return array (
  'www.niumays.com' => 
  array (
    'site_url' => 'www.niumays.com',
    'site_name' => '牛马影视',
    'site_keywords' => '',
    'site_description' => '',
    'template_dir' => 'niumays',
    'html_dir' => 'html',
    'ads_dir' => '',
  ),
);