<?php
return array (
  'aa' => 
  array (
    'id' => 'aa',
    'status' => '0',
    'name' => 'aa',
    'des' => '采集今日数据',
    'file' => 'collect',
    'param' => 'ac=cjday&xt=1&ct=&rday=24&cjflag=tv6_com&cjurl=http://cj2.tv6.com/mox/inc/youku.php',
    'weeks' => '1,2,3,4,5,6,0',
    'hours' => '00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23',
    'runtime' => 1597629775,
  ),
  'bb' => 
  array (
    'status' => '0',
    'name' => 'bb',
    'des' => '生成首页',
    'file' => 'make',
    'param' => 'ac=index',
    'weeks' => '1,2,3,4,5,6,0',
    'hours' => '00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23',
    'id' => 'bb',
    'runtime' => 1535348998,
  ),
  'ry' => 
  array (
    '__token__' => '4ce63caa65525ade43aa75c4fc9601bf',
    'status' => '1',
    'name' => 'ry',
    'des' => '如意',
    'file' => 'collect',
    'param' => 'https://www.yuhongk.com/shixin.php/admin/collect/api.html?ac=cj&cjflag=c39a8404054990c6464a3c3281435260&cjurl=https%3A%2F%2Fcj.rycjapi.com%2Fapi.php%2Fprovide%2Fvod%2Ffrom%2Frym3u8%2Fat%2Fxml%2F&h=24&t=&ids=&wd=&type=1&mid=1&opt=0&sync_pic_opt=0&filter=0&filter_from=&filter_year=&param=',
    'weeks' => '1,2,3,4,5,6,0',
    'hours' => '00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23',
    'runtime' => 1753587001,
  ),
);