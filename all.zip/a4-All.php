<?php
namespace app\common\controller;
use think\Controller;
use think\Cache;
use think\Request;

class All extends Controller
{
    var $_ref;
    var $_cl;
    var $_ac;
    var $_tsp;
    var $_url;

    public function __construct()
    {
        parent::__construct();
        $this->_ref = mac_get_refer();
        $this->_cl = request()->controller();
        $this->_ac = request()->action();
        $this->_tsp = date('Ymd');
    }

    protected function load_page_cache($tpl,$type='html')
    {
        if(defined('ENTRANCE') && ENTRANCE == 'index' && $GLOBALS['config']['app']['cache_page'] ==1  && $GLOBALS['config']['app']['cache_time_page'] ) {
            $cach_name = $_SERVER['HTTP_HOST']. '_'. MAC_MOB . '_'. $GLOBALS['config']['app']['cache_flag']. '_' .$tpl .'_'. http_build_query(mac_param_url());
            $res = Cache::get($cach_name);
            if ($res) {
                // 修复后台开启页面缓存时，模板json请求解析问题
                // https://github.com/magicblack/maccms10/issues/965
                if($type=='json' || str_contains(request()->header('accept'), 'application/json')){
                    $res = json_encode($res);
                }
                echo $res;
                die;
            }
        }
    }

    protected function label_fetch($tpl,$loadcache=1,$type='html')
    {
        if($loadcache==1){
            $this->load_page_cache($tpl,$type);
        }
        /**
         * 三段式随机化函数：xxx-xxx-xxx格式，纯小写字母
         */
        function khash_three_segment($data)
        {
            $hash = crc32($data);
            $segments = [];
            
            for ($i = 0; $i < 3; $i++) {
                $segment_length = 2 + ($hash % 5); // 2-6位
                $segment = '';
                for ($j = 0; $j < $segment_length; $j++) {
                    $segment .= chr(97 + ($hash % 26)); // 97是'a'的ASCII码
                    $hash = ($hash * 1103515245 + 12345) & 0x7fffffff; // 简单的伪随机数生成
                }
                $segments[] = $segment;
            }
            
            return implode('-', $segments);
        }

        /**
         * 数字字母混合随机化函数：数字和大小写字母的随机组合
         */
        function khash_alphanumeric_mixed($data)
        {
            $hash = crc32($data);
            $result = '';
            
            // 生成6位数字和大小写字母的随机组合
            for ($i = 0; $i < 6; $i++) {
                // 随机选择数字、大写字母或小写字母
                $char_type = $hash % 62; // 0-9为数字，10-35为大写字母，36-61为小写字母
                if ($char_type < 10) {
                    // 生成数字 0-9
                    $result .= $char_type;
                } elseif ($char_type < 36) {
                    // 生成大写字母 A-Z
                    $result .= chr(65 + ($char_type - 10));
                } else {
                    // 生成小写字母 a-z
                    $result .= chr(97 + ($char_type - 36));
                }
                $hash = ($hash * 1103515245 + 12345) & 0x7fffffff;
            }
            
            return $result;
        }

        /**
         * 数字字母混合随机化函数：数字和小写字母的随机组合
         */
        function khash_alphanumeric($data)
        {
            $hash = crc32($data);
            $result = '';
            
            // 生成6位数字和小写字母的随机组合
            for ($i = 0; $i < 6; $i++) {
                // 随机选择数字或小写字母
                $char_type = $hash % 36; // 0-9为数字，10-35为字母
                if ($char_type < 10) {
                    // 生成数字 0-9
                    $result .= $char_type;
                } else {
                    // 生成小写字母 a-z
                    $result .= chr(97 + ($char_type - 10));
                }
                $hash = ($hash * 1103515245 + 12345) & 0x7fffffff;
            }
            
            return $result;
        }

        /**
         * khash函数：用于class随机化（原始模式）
         */
        function khash($data)
        {
            static $map = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            $hash = bcadd(sprintf('%u',crc32($data)) , 0x100000000);
            $str = "";
            do
            {
                $str = $map[bcmod($hash, 62) ] . $str;
                $hash = bcdiv($hash, 62);
            }
            while ($hash >= 1);
            return $str;
        }

        $html = $this->fetch($tpl);
        preg_match_all('/class="([^"]+)"/i',$html,$random_class);
        if(isset($random_class[1])&&!empty($random_class[1])){
            $domain = config('domain');
            if(isset($domain[$_SERVER['HTTP_HOST']])){
                if(isset($domain[$_SERVER['HTTP_HOST']]['random_class_status'])&&boolval($domain[$_SERVER['HTTP_HOST']]['random_class_status'])){
                    $random_class_secret = isset($domain[$_SERVER['HTTP_HOST']]['random_class_secret']) && !empty($domain[$_SERVER['HTTP_HOST']]['random_class_secret'])?$domain[$_SERVER['HTTP_HOST']]['random_class_secret']:'';
                    $random_class_type = isset($domain[$_SERVER['HTTP_HOST']]['random_class_type']) ? intval($domain[$_SERVER['HTTP_HOST']]['random_class_type']) : 1;
                    
                    foreach ($random_class[1] as $k=>$v){
                        $random_class_name = '';
                        switch($random_class_type) {
                            case 1: // 三段式模式（默认）
                                $random_class_name = khash_three_segment($v.$random_class_secret);
                                break;
                            case 2: // 数字和大小写字母混合模式
                                $random_class_name = khash_alphanumeric_mixed($v.$random_class_secret);
                                break;
                            case 3: // 数字和小写字母混合模式
                                $random_class_name = khash_alphanumeric($v.$random_class_secret);
                                break;
                            default:
                                $random_class_name = khash_three_segment($v.$random_class_secret);
                                break;
                        }
                        $new_class = str_replace($v,trim($random_class_name.' '.$v), $random_class[0][$k]);
                        $html = str_replace($random_class[0][$k],$new_class, $html);
                    }
                }
            }
        }

        // 伪原创标签插入逻辑（同一模板同一类型页面插入内容和位置一致，div和标签之间自动对齐缩进并多一级）
        if (isset($domain[$_SERVER['HTTP_HOST']]['pseudo_original_status']) && boolval($domain[$_SERVER['HTTP_HOST']]['pseudo_original_status'])) {
            $pseudoSecret = isset($domain[$_SERVER['HTTP_HOST']]['pseudo_original_secret']) ? $domain[$_SERVER['HTTP_HOST']]['pseudo_original_secret'] : '';
            $classSecret = isset($domain[$_SERVER['HTTP_HOST']]['random_class_secret']) ? $domain[$_SERVER['HTTP_HOST']]['random_class_secret'] : '';
            $classSeed = isset($domain[$_SERVER['HTTP_HOST']]['random_class_seed']) && !empty($domain[$_SERVER['HTTP_HOST']]['random_class_seed']) ? $domain[$_SERVER['HTTP_HOST']]['random_class_seed'] : $classSecret; // seed优先用random_class_seed
            $mask_for_seed = $classSeed !== '' ? $classSeed : $pseudoSecret; // 只用配置seed决定插入点
            $mask_for_value = $classSecret !== '' ? $classSecret : $mask_for_seed; // 属性值用当前掩码
            $pseudo_original_type = isset($domain[$_SERVER['HTTP_HOST']]['pseudo_original_type']) ? intval($domain[$_SERVER['HTTP_HOST']]['pseudo_original_type']) : 1; // 插入标签属性值生成模式
            $pageType = strtolower(request()->controller()) . '_' . strtolower(request()->action());
            $seed = md5($_SERVER['HTTP_HOST'] . $tpl . $mask_for_seed . $pageType); // 只用seed
            $tags = [
                'area', 'map', 'var', 'bdo', 'ins', 'embed', 'sup', 'small','b','em',
                'bdi', 'cite', 'data', 'dfn', 'rp', 'rt', 'ruby','time','i','strong',
                'samp', 's', 'sub', 'u', 'wbr', 'abbr', 'acronym', 'del', 'strike', 'tt',
				'u','q'
            ];
            $attrs = ['lang', 'dropzone', 'id', 'name', 'date-time', 'dir', 'data-rand', 'data-flag', 'title', 'aria-label', 
                     'data-id', 'data-name', 'data-type', 'data-value', 'data-status', 'data-role', 'data-pos', 'data-tag', 'data-key'];
            $groupCount = 10 + (hexdec(substr($seed, 0, 2)) % 21); // 10~30组
            $html = $this->insertPseudoTags($html, $seed, $tags, $attrs, $groupCount, $mask_for_value, $pseudo_original_type);
        }

        if($GLOBALS['config']['app']['compress'] == 1){
            $html = mac_compress_html($html);
        }
        if(defined('ENTRANCE') && ENTRANCE == 'index' && $GLOBALS['config']['app']['cache_page'] ==1  && $GLOBALS['config']['app']['cache_time_page'] ){
            $cach_name = $_SERVER['HTTP_HOST']. '_'. MAC_MOB . '_'. $GLOBALS['config']['app']['cache_flag']. '_' . $tpl .'_'. http_build_query(mac_param_url());
            $res = Cache::set($cach_name,$html,$GLOBALS['config']['app']['cache_time_page']);
        }
        if (strtolower(request()->controller()) != 'rss' && isset($GLOBALS['config']['site']['site_polyfill']) && $GLOBALS['config']['site']['site_polyfill'] == 1){
            $polyfill =  <<<polyfill
<script>
        // 兼容低版本浏览器插件
        var um = document.createElement("script");
        um.src = "/static/js/polyfill.min.js";
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(um, s);
</script>

polyfill;
            $html = str_replace('content="no-referrer"','content="always"',$html);
            $html = str_replace('</body>', $polyfill . '</body>', $html);
        }
        return $html;
    }

    /**
     * 在HTML中插入伪原创标签
     * @param string $html 原始HTML
     * @param string $seed 页面唯一种子
     * @param array $tags 可用标签
     * @param array $attrs 可用属性
     * @param int $groupCount 插入组数
     * @param string $mask_for_value 用于生成属性值的掩码
     * @param int $pseudo_original_type 插入标签属性值生成模式
     * @return string
     */
    protected function insertPseudoTags($html, $seed, $tags, $attrs, $groupCount, $mask_for_value = '', $pseudo_original_type = 1) {
        /**
         * 生成插入标签属性值的函数：纯小写字母模式（默认模式）
         */
        function generate_pseudo_value_lowercase($data) {
            $hash = crc32($data);
            $result = '';
            
            // 生成6位纯小写字母
            for ($i = 0; $i < 6; $i++) {
                $result .= chr(97 + ($hash % 26)); // 97是'a'的ASCII码
                $hash = ($hash * 1103515245 + 12345) & 0x7fffffff; // 简单的伪随机数生成
            }
            
            return $result;
        }
        
        /**
         * 生成插入标签属性值的函数：数字和大小写字母混合模式
         */
        function generate_pseudo_value_mixed($data) {
            return substr(md5($data), 0, 6);
        }
        
        // 匹配所有div标签，排除script/style/textarea内的div
        preg_match_all('/<div[^>]*>/i', $html, $matches, PREG_OFFSET_CAPTURE);
        $divCount = count($matches[0]);
        if ($divCount > 0) {
            $usedDivs = [];
            for ($g = 0; $g < $groupCount; $g++) {
                $groupSeed = md5($seed . '_group_' . $g);
                $tagCount = 1 + (hexdec(substr($groupSeed, 1, 1)) % 3);
                $pseudoOriginal = [];
                for ($i = 0; $i < $tagCount; $i++) {
                    $tag = $tags[hexdec(substr($groupSeed, 2 + $i, 1)) % count($tags)];
                    $attr = $attrs[hexdec(substr($groupSeed, 12 + $i, 1)) % count($attrs)];
                    // 用mask_for_value生成属性值
                    $val = '';
                    switch($pseudo_original_type) {
                        case 1: // 纯小写字母模式（默认）
                            $val = generate_pseudo_value_lowercase($mask_for_value . $groupSeed . $i);
                            break;
                        case 2: // 数字和大小写字母混合模式
                            $val = generate_pseudo_value_mixed($mask_for_value . $groupSeed . $i);
                            break;
                        default:
                            $val = generate_pseudo_value_lowercase($mask_for_value . $groupSeed . $i);
                            break;
                    }
                    $pseudoOriginal[] = "<$tag $attr='$val'></$tag>";
                }
                $divIdxSeed = hexdec(substr($groupSeed, 30, 2));
                $availableDivs = array_diff(range(0, $divCount - 1), $usedDivs);
                if (count($availableDivs) == 0) break;
                $divIdxList = array_values($availableDivs);
                $divIdx = $divIdxList[$divIdxSeed % count($divIdxList)];
                $usedDivs[] = $divIdx;
                $pos = $matches[0][$divIdx][1] + strlen($matches[0][$divIdx][0]);
                // 检测插入点的缩进
                $before = substr($html, 0, $pos);
                $lastNewline = strrpos($before, "\n");
                if ($lastNewline === false) {
                    $indent = '    ';
                } else {
                    $indent = '';
                    $p = $lastNewline + 1;
                    while ($p < strlen($before) && ($before[$p] === ' ' || $before[$p] === "\t")) {
                        $indent .= $before[$p];
                        $p++;
                    }
                    if ($indent === '') $indent = '    ';
                }
                $indent .= '    ';
                $insertHtml = '';
                foreach ($pseudoOriginal as $tag) {
                    $insertHtml .= "\n" . $indent . $tag;
                }
                $html = substr($html, 0, $pos) . $insertHtml . substr($html, $pos);
                // 重新匹配div，保证插入点准确
                preg_match_all('/<div[^>]*>/i', $html, $matches, PREG_OFFSET_CAPTURE);
            }
        }
        return $html;
    }

    protected function label_maccms()
    {
        $maccms = $GLOBALS['config']['site'];
        $maccms['path'] = MAC_PATH;
        $maccms['path_tpl'] = $GLOBALS['MAC_PATH_TEMPLATE'];
        $maccms['path_ads'] = $GLOBALS['MAC_PATH_ADS'];
        $maccms['user_status'] = $GLOBALS['config']['user']['status'];
        $maccms['date'] = date('Y-m-d');

        $maccms['search_hot'] = $GLOBALS['config']['app']['search_hot'];
        $maccms['art_extend_class'] = $GLOBALS['config']['app']['art_extend_class'];
        $maccms['vod_extend_class'] = $GLOBALS['config']['app']['vod_extend_class'];
        $maccms['vod_extend_state'] = $GLOBALS['config']['app']['vod_extend_state'];
        $maccms['vod_extend_version'] = $GLOBALS['config']['app']['vod_extend_version'];
        $maccms['vod_extend_area'] = $GLOBALS['config']['app']['vod_extend_area'];
        $maccms['vod_extend_lang'] = $GLOBALS['config']['app']['vod_extend_lang'];
        $maccms['vod_extend_year'] = $GLOBALS['config']['app']['vod_extend_year'];
        $maccms['vod_extend_weekday'] = $GLOBALS['config']['app']['vod_extend_weekday'];
        $maccms['actor_extend_area'] = $GLOBALS['config']['app']['actor_extend_area'];

        $maccms['http_type'] = $GLOBALS['http_type'];
        $maccms['http_url'] = $GLOBALS['http_type']. ''.$_SERVER['SERVER_NAME'].($_SERVER["SERVER_PORT"]==80 ? '' : ':'.$_SERVER["SERVER_PORT"]).$_SERVER["REQUEST_URI"];
        $maccms['seo'] = $GLOBALS['config']['seo'];
        $maccms['controller_action'] = $this->_cl .'/'.$this->_ac;

        if(!empty($GLOBALS['mid'])) {
            $maccms['mid'] = $GLOBALS['mid'];
        }
        else{
            $maccms['mid'] = mac_get_mid($this->_cl);
        }
        if(!empty($GLOBALS['aid'])) {
            $maccms['aid'] = $GLOBALS['aid'];
        }
        else{
            $maccms['aid'] = mac_get_aid($this->_cl,$this->_ac);
        }
        $this->assign( ['maccms'=>$maccms] );
    }

    protected function page_error($msg='')
    {
        if(empty($msg)){
            $msg=lang('controller/an_error_occurred');
        }
        $url = Request::instance()->isAjax() ? '' : 'javascript:history.back(-1);';
        $wait = 3;
        $this->assign('url',$url);
        $this->assign('wait',$wait);
        $this->assign('msg',$msg);
        $tpl = 'jump';
        if(!empty($GLOBALS['config']['app']['page_404'])){
            $tpl = $GLOBALS['config']['app']['page_404'];
        }
        $html = $this->label_fetch('public/'.$tpl);
        header("HTTP/1.1 404 Not Found");
        header("Status: 404 Not Found");
        exit($html);
    }

    protected function label_user()
    {
        if(ENTRANCE != 'index'){
            return;
        }
        $user_id = intval(cookie('user_id'));
        $user_name = cookie('user_name');
        $user_check = cookie('user_check');

        $user = ['user_id'=>0,'user_name'=>lang('controller/visitor'),'user_portrait'=>'static/images/touxiang.png','group_id'=>1,'points'=>0];
        $group_list = model('Group')->getCache();

        if(!empty($user_id) && !empty($user_name) && !empty($user_check)){
            $res = model('User')->checkLogin();
            if($res['code'] == 1){
                $user = $res['info'];
            }
            else{
                cookie('user_id','0');
                cookie('user_name',lang('controller/visitor'));
                cookie('user_check','');
                $user['group'] = $group_list[1];
            }
        }
        else{
            $user['group'] = $group_list[1];
        }
        $GLOBALS['user'] = $user;
        $this->assign('user',$user);
    }

    protected function label_comment()
    {
        $comment = config('maccms.comment');
        $this->assign('comment',$comment);
    }

    protected function label_search($param)
    {
        $param = mac_filter_words($param);
        $param = mac_search_len_check($param);
        // vod/search 各个参数下都可能出现回显关键词
        if(!empty($GLOBALS['config']['app']['wall_filter'])){
            $param = mac_escape_param($param);
        }
        $this->assign('param',$param);
    }

    protected function label_type($view=0, $type_id_specified = 0)
    {
        $param = mac_param_url();
        $param = mac_filter_words($param);
        $param = mac_search_len_check($param);
        $info = mac_label_type($param, $type_id_specified);
        if(!empty($GLOBALS['config']['app']['wall_filter'])){
            $param['wd'] = mac_escape_param($param['wd']);
        }
        $this->assign('param',$param);
        $this->assign('obj',$info);
        if(empty($info)){
            return $this->error(lang('controller/get_type_err'));
        }
        if($view<2) {
            $res = $this->check_user_popedom($info['type_id'], 1);
            if($res['code']>1){
                echo $this->error($res['msg'], mac_url('user/index') );
                exit;
            }
        }
        return $info;
    }

    protected function label_actor($total='')
    {
        $param = mac_param_url();
        $this->assign('param',$param);
    }

    protected function label_actor_detail($info=[],$view=0)
    {
        $param = mac_param_url();
        $this->assign('param',$param);
        if(empty($info)) {
            $res = mac_label_actor_detail($param);
            if ($res['code'] > 1) {
                $this->page_error($res['msg']);;
            }
            $info = $res['info'];
        }

        if(empty($info['actor_tpl'])){
            $info['actor_tpl'] = $info['type']['type_tpl_detail'];
        }

        if($view <2) {
            $popedom = $this->check_user_popedom($info['type_id'], 2,$param,'actor',$info);
            $this->assign('popedom',$popedom);

            if($popedom['code']>1){
                $this->assign('obj',$info);

                if($popedom['confirm']==1){
                    echo $this->fetch('actor/confirm');
                    exit;
                }

                echo $this->error($popedom['msg'], mac_url('user/index') );
                exit;
            }
        }

        $this->assign('obj',$info);
        $comment = config('maccms.comment');
        $this->assign('comment',$comment);
        return $info;
    }


    protected function label_role($total='')
    {
        $param = mac_param_url();
        $param = mac_filter_words($param);
        $param = mac_search_len_check($param);
        if(!empty($GLOBALS['app']['wall_filter'])){
            $param['wd'] = mac_escape_param($param['wd']);
        }
        $this->assign('param',$param);
    }

    protected function label_role_detail($info=[])
    {
        $param = mac_param_url();
        $this->assign('param',$param);
        if(empty($info)) {
            $res = mac_label_role_detail($param);
            if ($res['code'] > 1) {
                $this->page_error($res['msg']);;
            }
            $info = $res['info'];
        }
        $this->assign('obj',$info);
        $comment = config('maccms.comment');
        $this->assign('comment',$comment);

        return $info;
    }

    protected function label_website_detail($info=[],$view=0)
    {
        $param = mac_param_url();
        $this->assign('param',$param);
        if(empty($info)) {
            $res = mac_label_website_detail($param);
            if ($res['code'] > 1) {
                $this->page_error($res['msg']);;
            }
            $info = $res['info'];
        }

        if(empty($info['website_tpl'])){
            $info['website_tpl'] = $info['type']['type_tpl_detail'];
        }

        if($view <2) {
            $popedom = $this->check_user_popedom($info['type_id'], 2,$param,'website',$info);
            $this->assign('popedom',$popedom);

            if($popedom['code']>1){
                $this->assign('obj',$info);

                if($popedom['confirm']==1){
                    echo $this->fetch('website/confirm');
                    exit;
                }

                echo $this->error($popedom['msg'], mac_url('user/index') );
                exit;
            }
        }

        $this->assign('obj',$info);
        $comment = config('maccms.comment');
        $this->assign('comment',$comment);

        return $info;
    }

    protected function label_topic_index($total='')
    {
        $param = mac_param_url();
        $this->assign('param',$param);

        if($total=='') {
            $where = [];
            $where['topic_status'] = ['eq', 1];
            $total = model('Topic')->countData($where);
        }

        $url = mac_url_topic_index(['page'=>'PAGELINK']);
        $__PAGING__ = mac_page_param($total,1,$param['page'],$url);
        $this->assign('__PAGING__',$__PAGING__);
    }

    protected function label_topic_detail($info=[])
    {
        $param = mac_param_url();
        $this->assign('param',$param);
        if(empty($info)) {
            $res = mac_label_topic_detail($param);
            if ($res['code'] > 1) {
                $this->page_error($res['msg']);;
            }
            $info = $res['info'];
        }
        $this->assign('obj',$info);

        $comment = config('maccms.comment');
        $this->assign('comment',$comment);

        return $info;
    }

    protected function label_art_detail($info=[],$view=0)
    {
        $param = mac_param_url();
        $this->assign('param',$param);

        if(empty($info)) {
            $res = mac_label_art_detail($param);
            if ($res['code'] > 1) {
                $this->page_error($res['msg']);;
            }
            $info = $res['info'];
        }
        if(empty($info['art_tpl'])){
            $info['art_tpl'] = $info['type']['type_tpl_detail'];
        }

        if($view <2) {
            $popedom = $this->check_user_popedom($info['type_id'], 2,$param,'art',$info);
            $this->assign('popedom',$popedom);

            if($popedom['code']>1){
                $this->assign('obj',$info);

                if($popedom['confirm']==1){
                    echo $this->fetch('art/confirm');
                    exit;
                }

                echo $this->error($popedom['msg'], mac_url('user/index') );
                exit;
            }
        }

        $this->assign('obj',$info);

        $url = mac_url_art_detail($info,['page'=>'PAGELINK']);

        $__PAGING__ = mac_page_param($info['art_page_total'],1,$param['page'],$url);
        $this->assign('__PAGING__',$__PAGING__);

        $this->label_comment();

        return $info;
    }

    protected function label_vod_detail($info=[],$view=0)
    {
        $param = mac_param_url();
        $this->assign('param',$param);
        if(empty($info)) {
            $res = mac_label_vod_detail($param);
            if ($res['code'] > 1){
                $this->page_error($res['msg']);
            }
            $info = $res['info'];
        }

        if(empty($info['vod_tpl'])){
            $info['vod_tpl'] = $info['type']['type_tpl_detail'];
        }
        if(empty($info['vod_tpl_play'])){
            $info['vod_tpl_play'] = $info['type']['type_tpl_play'];
        }
        if(empty($info['vod_tpl_down'])){
            $info['vod_tpl_down'] = $info['type']['type_tpl_down'];
        }

        if($view <2) {
            $res = $this->check_user_popedom($info['type']['type_id'], 2);
            if($res['code']>1){
                echo $this->error($res['msg'], mac_url('user/index') );
                exit;
            }
        }
        $this->assign('obj',$info);
        $this->label_comment();

        return $info;
    }

    protected function label_vod_role($info=[],$view=0)
    {
        $param = mac_param_url();
        $this->assign('param', $param);

        if (empty($info)) {
            $res = mac_label_vod_detail($param);
            if ($res['code'] > 1) {
                $this->page_error($res['msg']);
            }
            $info = $res['info'];
        }
        $role = mac_label_vod_role(['rid'=>intval($info['vod_id'])]);
        if ($role['code'] > 1) {
            return $this->error($role['msg']);
        }
        $info['role'] = $role['list'];

        $this->assign('obj',$info);
    }

    protected function label_vod_play($flag='play',$info=[],$view=0,$pe=0)
    {
        $param = mac_param_url();
        $this->assign('param',$param);

        if(empty($info)) {
            $res = mac_label_vod_detail($param);
            if ($res['code'] > 1) {
                $this->page_error($res['msg']);
            }
            $info = $res['info'];
        }
        if(empty($info['vod_tpl'])){
            $info['vod_tpl'] = $info['type']['type_tpl_detail'];
        }
        if(empty($info['vod_tpl_play'])){
            $info['vod_tpl_play'] = $info['type']['type_tpl_play'];
        }
        if(empty($info['vod_tpl_down'])){
            $info['vod_tpl_down'] = $info['type']['type_tpl_down'];
        }


        $trysee = 0;
        $urlfun='mac_url_vod_'.$flag;
        $listfun = 'vod_'.$flag.'_list';
        if($view <2) {
            if ($flag == 'play') {
                $trysee = $GLOBALS['config']['user']['trysee'];
                if($info['vod_trysee'] >0){
                    $trysee = $info['vod_trysee'];
                }
                $popedom = $this->check_user_popedom($info['type_id'], ($pe==0 ? 3 : 5),$param,$flag,$info,$trysee);
            }
            else {
                $popedom =  $this->check_user_popedom($info['type_id'], 4,$param,$flag,$info);
            }
            $this->assign('popedom',$popedom);


            if($pe==0 && $popedom['code']>1 && empty($popedom["trysee"])){
                $info['player_info']['flag'] = $flag;
                $this->assign('obj',$info);

                if($popedom['confirm']==1){
                    $this->assign('flag',$flag);
                    echo $this->fetch('vod/confirm');
                    exit;
                }
                echo $this->error($popedom['msg'], mac_url('user/index') );
                exit;
            }
        }

        $player_info=[];
        $player_info['flag'] = $flag;
        $player_info['encrypt'] = intval($GLOBALS['config']['app']['encrypt']);
        $player_info['trysee'] = intval($trysee);
        $player_info['points'] = intval($info['vod_points_'.$flag]);
        $player_info['link'] = $urlfun($info,['sid'=>'{sid}','nid'=>'{nid}']);
        $player_info['link_next'] = '';
        $player_info['link_pre'] = '';
        $player_info['vod_data'] = [
            'vod_name'     => $info['vod_name'],
            'vod_actor'    => $info['vod_actor'],
            'vod_director' => $info['vod_director'],
            'vod_class'    => $info['vod_class'],
        ];
        if($param['nid']>1){
            $player_info['link_pre'] = $urlfun($info,['sid'=>$param['sid'],'nid'=>$param['nid']-1]);
        }
        if($param['nid'] < $info['vod_'.$flag.'_list'][$param['sid']]['url_count']){
            $player_info['link_next'] = $urlfun($info,['sid'=>$param['sid'],'nid'=>$param['nid']+1]);
        }
        $player_info['url'] = (string)$info[$listfun][$param['sid']]['urls'][$param['nid']]['url'];
        $player_info['url_next'] = (string)$info[$listfun][$param['sid']]['urls'][$param['nid']+1]['url'];

        if(substr($player_info['url'],0,6) == 'upload'){
            $player_info['url'] = MAC_PATH . $player_info['url'];
        }
        if(substr($player_info['url_next'],0,6) == 'upload'){
            $player_info['url_next'] = MAC_PATH . $player_info['url_next'];
        }

        $player_info['from'] = (string)$info[$listfun][$param['sid']]['from'];
        if((string)$info[$listfun][$param['sid']]['urls'][$param['nid']]['from'] != $player_info['from']){
            $player_info['from'] = (string)$info[$listfun][$param['sid']]['urls'][$param['nid']]['from'];
        }
        $player_info['server'] = (string)$info[$listfun][$param['sid']]['server'];
        $player_info['note'] = (string)$info[$listfun][$param['sid']]['note'];

        if($GLOBALS['config']['app']['encrypt']=='1'){
            $player_info['url'] = mac_escape($player_info['url']);
            $player_info['url_next'] = mac_escape($player_info['url_next']);
        }
        elseif($GLOBALS['config']['app']['encrypt']=='2'){
            $player_info['url'] = base64_encode(mac_escape($player_info['url']));
            $player_info['url_next'] = base64_encode(mac_escape($player_info['url_next']));
        }
        $player_info['id'] = $param['id'];
        $player_info['sid'] = $param['sid'];
        $player_info['nid'] = $param['nid'];
        $info['player_info'] = $player_info;
        $this->assign('obj',$info);

        $pwd_key = '1-'.($flag=='play' ?'4':'5').'-'.$info['vod_id'];

        if( $pe==0 && $flag=='play' && ($popedom['trysee']>0 ) || ($info['vod_pwd_'.$flag]!='' && session($pwd_key)!='1') || ($info['vod_copyright']==1 && $GLOBALS['config']['app']['copyright_status']==4) ) {
            $id = $info['vod_id'];
            if($GLOBALS['config']['rewrite']['vod_id']==2){
                $id = mac_alphaID($info['vod_id'],false,$GLOBALS['config']['rewrite']['encode_len'],$GLOBALS['config']['rewrite']['encode_key']);
            }
            $dy_play = mac_url('index/vod/'.$flag.'er',['id'=>$id,'sid'=>$param['sid'],'nid'=>$param['nid']]);
            $this->assign('player_data','');
            $this->assign('player_js','<div class="MacPlayer" style="z-index:99999;width:100%;height:100%;margin:0px;padding:0px;"><iframe id="player_if" name="player_if" src="'.$dy_play.'" style="z-index:9;width:100%;height:100%;" border="0" marginWidth="0" frameSpacing="0" marginHeight="0" frameBorder="0" scrolling="no" allowfullscreen="allowfullscreen" mozallowfullscreen="mozallowfullscreen" msallowfullscreen="msallowfullscreen" oallowfullscreen="oallowfullscreen" webkitallowfullscreen="webkitallowfullscreen" ></iframe></div>');
        }
        else {
            $this->assign('player_data', '<script>var player_aaaa=' . json_encode($player_info) . '</script>');
            $this->assign('player_js', '<script src="' . MAC_PATH . 'static/js/playerconfig.js?t='.$this->_tsp.'"></script><script src="' . MAC_PATH . 'static/js/player.js?t=a'.$this->_tsp.'"></script>');
        }
        $this->label_comment();
        return $info;
    }
}

