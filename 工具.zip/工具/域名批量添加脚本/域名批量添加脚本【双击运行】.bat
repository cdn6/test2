@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo === 域名到站点目录映射生成工具 ===
echo.

if not exist "ym.txt" (
    echo 错误: 当前目录下未找到 ym.txt 文件！
    echo 请确保 ym.txt 与脚本在同一目录，并按行存放域名（如 demo.com）。
    pause
    exit /b 1
)

set "output=已生成域名列表.txt"
if exist "%output%" (
    echo 检测到已存在的输出文件 %output%，将覆盖...
    echo.
)

set /a count=0
(for /f "usebackq delims=" %%a in ("ym.txt") do (
    set "domain=%%a"
    if not "!domain!"=="" (
        set "line=www.!domain!,!domain!|/www/wwwroot/b7.dmcy.cc|0|0|74"
        echo !line!
        set /a count+=1
    )
)) > "%output%"

echo 生成完成！
echo 共处理 !count! 个域名，结果已保存到: %output%
echo.
pause