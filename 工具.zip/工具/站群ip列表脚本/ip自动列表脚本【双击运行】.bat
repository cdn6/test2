@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo === IP地址段展开工具 ===
echo.

if not exist "ip.txt" (
    echo 错误: 当前目录下未找到 ip.txt 文件！
    echo 请确保 ip.txt 与脚本在同一目录，并按行存放IP段（如 123.32.0.2-20）。
    pause
    exit /b 1
)

set "output=已生成ip列表.txt"
if exist "%output%" (
    echo 检测到已存在的输出文件 %output%，将覆盖...
    echo.
)

set /a total_count=0
(for /f "usebackq delims=" %%a in ("ip.txt") do (
    set "line=%%a"
    if not "!line!"=="" (
        for /f "tokens=1,2 delims=-" %%i in ("!line!") do (
            set "prefix=%%i"
            set "range_end=%%j"
            if "!range_end!"=="" (
                rem 没有横杠，直接输出
                echo !line!
                set /a total_count+=1
            ) else (
                rem 分割前缀IP
                for /f "tokens=1-4 delims=." %%a in ("!prefix!") do (
                    set "octet1=%%a"
                    set "octet2=%%b"
                    set "octet3=%%c"
                    set "octet4=%%d"
                )
                
                if "!octet4!"=="" (
                    rem IP格式错误
                    echo 错误: "!line!" 格式错误！应为 X.X.X.起始-结束 格式
                ) else (
                    rem 计算起始和结束
                    set /a start=!octet4!
                    set /a end=!range_end!
                    
                    if !end! lss !start! (
                        rem 如果结束小于开始，交换顺序
                        set /a temp=!start!
                        set /a start=!end!
                        set /a end=!temp!
                    )
                    
                    rem 生成IP范围
                    for /l %%n in (!start!,1,!end!) do (
                        echo !octet1!.!octet2!.!octet3!.%%n
                        set /a total_count+=1
                    )
                )
            )
        )
    )
)) > "%output%"

echo 生成完成！
echo 共生成 !total_count! 个IP地址，结果已保存到: %output%
echo.
pause