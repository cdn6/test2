@echo off
:: 设置你想要的域名
set "DOMAIN=demo.com"

:: 设置输出的域名列表文件名
set "OUTPUT_FILE=ym.txt"

:: 清空旧的文件（如果存在的话）
type nul > "%OUTPUT_FILE%"

:: 循环生成 a1 到 a10 并写入文件
for /L %%i in (1,1,10) do (
    echo c%%i.%DOMAIN%-c%%i >> "%OUTPUT_FILE%"
)

echo 成功！已生成文件：%OUTPUT_FILE%
pause
