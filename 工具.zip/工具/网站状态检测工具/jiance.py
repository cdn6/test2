import os
import time
import re
import requests
import html  # 导入html模块，用于转义安全字符
from concurrent.futures import ThreadPoolExecutor, as_completed

# 脚本所在目录
BASE_DIR = "/www/wwwroot/jiance"
TXT_FILE = os.path.join(BASE_DIR, "urls.txt")
# 修改后缀为 .html
HTML_FILE = os.path.join(BASE_DIR, "bg.html")

# 模拟的移动端 UA (默认用 iPhone Safari)
MOBILE_UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1"

def load_urls():
    if not os.path.exists(TXT_FILE):
        return []
    url_data = []
    with open(TXT_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                if "-" in line:
                    parts = line.rsplit("-", 1)
                    url = parts[0].strip()
                    tag = parts[1].strip() if len(parts) > 1 and parts[1].strip() else url
                else:
                    url = line
                    tag = line
                if url:
                    url_data.append({"url": url, "tag": tag, "raw_line": line})
    return url_data

def get_html_title(html_content):
    """使用正则从网页源码中提取标题，并过滤掉减号、下划线及右侧的内容"""
    try:
        title_match = re.search(r'<title[^>]*>(.*?)</title>', html_content, re.IGNORECASE | re.DOTALL)
        if title_match:
            title = title_match.group(1).strip()
            title = re.sub(r'\s+', ' ', title)
            if title:
                title_parts = re.split(r'[-—–_]', title)
                title = title_parts[0].strip()
                return title if title else "无标题"
            return "无标题"
    except Exception:
        pass
    return "未知标题"

def single_check(item):
    """单个网站检测，返回带标识字典数据"""
    url = item["url"]
    tag = item["tag"]
    
    # 修复此处的语法错误：正确使用条件表达式并补全 else
    request_url = url if url.startswith(("http://", "https://")) else "https://" + url
    
    headers = {"User-Agent": MOBILE_UA}
    start_time = time.time()
    
    # 初始化返回字典，安全转义
    res_data = {
        "raw_line": item["raw_line"],
        "tag": html.escape(tag),
        "url": html.escape(request_url),
        "status": "🔴 失败",
        "class": "status-fail",
        "code": "-",
        "time": "-",
        "title": "无法访问",
    }
    
    try:
        response = requests.get(request_url, headers=headers, timeout=8, allow_redirects=True, verify=False)
        elapsed = round((time.time() - start_time) * 1000)
        res_data["time"] = f"{elapsed}ms"
        res_data["code"] = str(response.status_code)
        
        if response.encoding == 'ISO-8859-1' or response.encoding is None:
            response.encoding = response.apparent_encoding
            
        if response.ok:
            title = get_html_title(response.text)
            res_data["status"] = "🟢 正常"
            res_data["class"] = "status-ok"
            res_data["title"] = html.escape(title)
        else:
            res_data["status"] = "🟠 异常"
            res_data["class"] = "status-warning"
            res_data["title"] = "无法正常获取标题"
            
    except requests.exceptions.Timeout:
        res_data["title"] = "请求超时"
    except Exception:
        res_data["title"] = "无法解析或拒绝连接"
        
    return res_data

def generate_html_report(results, check_time):
    """生成带有网页编码（UTF-8）的HTML代码"""
    table_rows = ""
    for r in results:
        table_rows += f"""
        <tr class="{r['class']}">
            <td>{r['status']}</td>
            <td>{r['tag']}</td>
            <td><a href="{r['url']}" target="_blank">{r['url']}</a></td>
            <td>{r['code']}</td>
            <td>{r['time']}</td>
            <td class="title-cell">{r['title']}</td>
        </tr>
        """
        
    if not results:
        table_rows = "<tr><td colspan='6' style='text-align:center; color:red;'>urls.txt 中没有有效的网址。</td></tr>"

    html_template = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>网站状态自动检测报告</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background-color: #f5f7fa; color: #333; margin: 0; padding: 20px; }}
        .container {{ max-width: 1200px; margin: 0 auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }}
        h1 {{ text-align: center; color: #2c3e50; font-size: 24px; margin-bottom: 5px; }}
        .time {{ text-align: center; color: #7f8c8d; font-size: 14px; margin-bottom: 20px; }}
        table {{ width: 100%; border-collapse: collapse; margin-top: 10px; }}
        th, td {{ padding: 12px 15px; text-align: left; border-bottom: 1px solid #e2e8f0; font-size: 14px; }}
        th {{ background-color: #edf2f7; color: #4a5568; font-weight: 600; }}
        tr:hover {{ background-color: #f8fafc; }}
        .status-ok {{ background-color: #f0fdf4; }}
        .status-warning {{ background-color: #fffbeb; }}
        .status-fail {{ background-color: #fef2f2; }}
        .title-cell {{ font-weight: 500; color: #1a202c; }}
        a {{ color: #3182ce; text-decoration: none; }}
        a:hover {{ text-decoration: underline; }}
        @media (max-width: 768px) {{
            table, thead, tbody, th, td, tr {{ display: block; }}
            thead tr {{ position: absolute; top: -9999px; left: -9999px; }}
            tr {{ border: 1px solid #cbd5e1; margin-bottom: 10px; border-radius: 6px; padding: 5px; background: #fff !important; }}
            td {{ border: none; border-bottom: 1px solid #f1f5f9; position: relative; padding-left: 35%; text-align: right; }}
            td:last-child {{ border-bottom: none; }}
            td:before {{ position: absolute; left: 10px; top: 12px; width: 30%; text-align: left; font-weight: bold; color: #718096; }}
            td:nth-of-type(1):before {{ content: "状态"; }}
            td:nth-of-type(2):before {{ content: "标识"; }}
            td:nth-of-type(3):before {{ content: "网址"; }}
            td:nth-of-type(4):before {{ content: "状态码"; }}
            td:nth-of-type(5):before {{ content: "耗时"; }}
            td:nth-of-type(6):before {{ content: "标题"; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🌐 网站状态自动检测报告</h1>
        <div class="time">⏰ 检查时间: {check_time}</div>
        <table>
            <thead>
                <tr>
                    <th style="width: 100px;">检测状态</th>
                    <th style="width: 150px;">标识</th>
                    <th>网址</th>
                    <th style="width: 80px;">状态码</th>
                    <th style="width: 90px;">耗时</th>
                    <th>提取标题</th>
                </tr>
            </thead>
            <tbody>
                {table_rows}
            </tbody>
        </table>
    </div>
</body>
</html>
"""
    return html_template

def main():
    url_data = load_urls()
    results = []
    
    if url_data:
        max_workers = min(len(url_data), 20)
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_item = {executor.submit(single_check, item): item for item in url_data}
            for future in as_completed(future_to_item):
                results.append(future.result())
                
        line_order = {item["raw_line"]: i for i, item in enumerate(url_data)}
        results.sort(key=lambda x: line_order.get(x["raw_line"], 999))
        
    current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    html_content = generate_html_report(results, current_time)
    
    with open(HTML_FILE, "w", encoding="utf-8") as f:
        f.write(html_content)
        
    print(f"🎉 检测完成，报告已成功生成至 HTML：{HTML_FILE}")

if __name__ == "__main__":
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    main()
