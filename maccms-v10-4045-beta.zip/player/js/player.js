//原版备份js
		 function codefans(){
            var box=document.getElementById("divboxmemeda");
            box.style.display="none";
        };
        setTimeout(codefans, 20000);
        var m3u8Url = new URLSearchParams(location.search.substring(1)).get('url');
        
        document.addEventListener("DOMContentLoaded", () => {
            window.player = new Artplayer({
                container: '#container',
                url: m3u8Url,
				poster: 'https://img.meituan.net/csc/c3dcf37014f2dacc1f93b669f3dd2c1c783656.jpg',
				autoSize: false,
				pip: true,
				fullscreen: true,
				autoplay: true,
				autoMini: false,
				playbackRate: true,
				lock: false,
				screenshot: false,
				hotkey: true,
				flip: false,
				autoPlayback: true,
				aspectRatio: true,
				fastForward: true,
				setting: true,
                customType: {
                    m3u8: function(video, url) {
                        if (Hls.isSupported()) {
                            if (window.player.hls) window.player.hls.destroy();
                            const hls = new Hls();
                            hls.loadSource(url);
                            hls.attachMedia(video);
                            window.player.hls = hls;
                            window.player.on('destroy', () => hls.destroy());
                        } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
                            video.src = url;
                        } else {
                            window.player.notice.show = '不支持的播放格式: m3u8';
                        }
                    }
                }
            });
        });