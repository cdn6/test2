<?php
return array (
    'name' => '苹果CMS内容管理系统',
    'copyright' => 'MacCMS',
    'url' => '',
    'code' => '2024.1000.4045',
    'license' => '去后门版',

);
?>
