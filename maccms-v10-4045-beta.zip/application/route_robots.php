<?php
return array (
	'robots.txt' => 
	array (
		0 => 'robots/index',
		1 => 
		array (
		),
		2 => 
		array (
		),
	),
);