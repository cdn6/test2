<?php
namespace app\index\controller;
use think\Controller;

class Robots extends Controller
{
	public function index()
	{
		// 仅允许访问 /robots.txt，其它路径返回 404
		$requestUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
		if ($requestUri && stripos($requestUri, 'robots.txt') === false) {
			header('HTTP/1.1 404 Not Found');
			echo '404 Not Found';
			exit;
		}

		$scheme = 'http';
		if ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] && strtolower($_SERVER['HTTPS']) !== 'off') || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443)) {
			$scheme = 'https';
		}
		$host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : (isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : 'localhost');
		$base = $scheme . '://' . $host;

		header('Content-Type: text/plain; charset=UTF-8');

        $lines = [
            // ========== 一、禁止搜索引擎及商业爬虫 ==========
            'User-agent: Googlebot',       // 谷歌
            'Disallow: /',
            '',
            'User-agent: Amazonbot',       // 亚马逊
            'Disallow: /',
            '',
            'User-agent: Applebot',        // 苹果
            'Disallow: /',
            '',
            'User-agent: Bytespider',      // 字节/头条
            'Disallow: /',
            '',
            'User-agent: Toutiaospider',   // 头条
            'Disallow: /',
            '',
            // ========== 二、禁止AI爬虫 ==========
            'User-agent: GPTBot',           // OpenAI
            'Disallow: /',
            '',
            'User-agent: ChatGPT-User',    // ChatGPT
            'Disallow: /',
            '',
            'User-agent: Google-Extended',  // Google AI (Gemini)
            'Disallow: /',
            '',
            'User-agent: ClaudeBot',       // Anthropic Claude
            'Disallow: /',
            '',
            'User-agent: anthropic-ai',    // Anthropic
            'Disallow: /',
            '',
            'User-agent: CCBot',           // Common Crawl (AI训练)
            'Disallow: /',
            '',
            'User-agent: cohere-ai',       // Cohere
            'Disallow: /',
            '',
            'User-agent: PerplexityBot',   // Perplexity
            'Disallow: /',
            '',
            // ========== 三、禁止垃圾爬虫 ==========
            'User-agent: MJ12bot',         // Majestic
            'Disallow: /',
            '',
            'User-agent: AhrefsBot',       // Ahrefs
            'Disallow: /',
            '',
            'User-agent: SemrushBot',      // Semrush
            'Disallow: /',
            '',
            'User-agent: DotBot',          // Moz
            'Disallow: /',
            '',
            'User-agent: PetalBot',        // 华为花瓣
            'Disallow: /',
            '',
            'User-agent: DataForSeoBot',   // DataForSEO
            'Disallow: /',
            '',
            // ========== 放行其他爬虫（百度、搜狗、360、必应、神马等）及禁止爬取目录 ==========
            'User-agent: *',
            'Disallow: /index.php/ajax/',
            'Disallow: /index.php/user/',
            'Disallow: /index.php/comment/',
            'Disallow: /runtime/',
            '',
			// ========== 网站地图 ==========
            'Sitemap: ' . $base . '/sitemap.xml',
        ];

		echo implode("\n", $lines);
		exit;
	}
}
