<?php
namespace app\index\controller;

class Robots extends Base
{
	public function index()
	{
		// 仅允许访问 /robots.txt，其它路径返回 404
		$requestUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
		if ($requestUri && stripos($requestUri, 'robots.txt') === false) {
			header('HTTP/1.1 404 Not Found');
			echo '404 Not Found';
			exit;
		}

		$scheme = 'http';
		if ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] && strtolower($_SERVER['HTTPS']) !== 'off') || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443)) {
			$scheme = 'https';
		}
		$host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : (isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : 'localhost');
		$base = $scheme . '://' . $host;

		header('Content-Type: text/plain; charset=UTF-8');

		$lines = [
			'User-agent: Googlebot',
			'Disallow: /',
			'',
			'User-agent: GoogleOther',
			'Disallow: /',
			'',
			'User-agent: Amazonbot',
			'Disallow: /',
			'',
			'User-agent: AhrefsBot',
			'Disallow: /',
			'',
			'User-agent: MJ12bot',
			'Disallow: /',
			'',
			'User-agent: SemrushBot',
			'Disallow: /',
			'',
			'User-agent: SeznamBot',
			'Disallow: /',
			'',
			'User-agent: BLEXBot',
			'Disallow: /',
			'',
			'User-agent: PetalBot',
			'Disallow: /',
			'',
			'User-agent: GPTBot',
			'Disallow: /',
			'',
			'User-agent: Barkrowler',
			'Disallow: /',
			'',
			'User-agent: FacebookExternalHit',
			'Disallow: /',
			'',
			'User-agent: Bytespider',
			'Disallow: /',
			'',
			'User-agent: *',
			'Disallow:',
			'',
			'Sitemap: ' . $base . '/sitemap.xml',
		];

		echo implode("\n", $lines);
		exit;
	}
}


