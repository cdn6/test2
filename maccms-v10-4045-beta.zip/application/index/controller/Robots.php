<?php
namespace app\index\controller;
use think\Controller;

class Robots extends Controller
{
	public function index()
	{
		// 仅允许访问 /robots.txt，其它路径返回 404
		$requestUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
		if ($requestUri && stripos($requestUri, 'robots.txt') === false) {
			header('HTTP/1.1 404 Not Found');
			echo '404 Not Found';
			exit;
		}

		$scheme = 'http';
		if ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] && strtolower($_SERVER['HTTPS']) !== 'off') || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443)) {
			$scheme = 'https';
		}
		$host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : (isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : 'localhost');
		$base = $scheme . '://' . $host;

		header('Content-Type: text/plain; charset=UTF-8');

        $lines = [
            // 放行指定的搜索引擎爬虫
            'User-agent: Baiduspider',      // 百度
            'Allow: /',
            '',
            'User-agent: Yisouspider',     // 神马
            'Allow: /',
            '',
            'User-agent: Sogou web spider', // 搜狗
            'Allow: /',
            '',
            'User-agent: 360Spider',       // 360
            'Allow: /',
            '',
            'User-agent: bingbot',         // 必应
            'Allow: /',
            '',
            // 禁止其它所有爬虫 (如 Google, 头条, GPT 等)
            'User-agent: *',
            'Disallow: /',
            '',
			// 网站地图
            'Sitemap: ' . $base . '/sitemap.xml',
        ];

		echo implode("\n", $lines);
		exit;
	}
}
