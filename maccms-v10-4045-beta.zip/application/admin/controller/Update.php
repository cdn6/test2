<?php
namespace app\admin\controller;
use think\Db;
use app\common\util\PclZip;

class Update extends Base
{
    var $_url;
    var $_save_path;

    public function __construct()
    {
        parent::__construct();
        $this->_save_path = './application/data/update/';
    }

    public function index()
    {
        return $this->fetch('admin@test/index');
    }

    public function step1($file='')
    {
        if(empty($file)){
            return $this->error(lang('param_err'));
        }
        $version = config('version.code');
        $save_file = $version.'.zip';
        echo $this->fetch('admin@public/head');
        echo "<div class='update'><h1>".lang('admin/update/step1_a')."</h1><textarea rows=\"25\" class='layui-textarea' readonly>".lang('admin/update/step1_b')."\n";
        ob_flush();flush();
        sleep(1);

        echo lang('admin/update/upgrade_package_processed')."\n";
        ob_flush();flush();
        sleep(1);

        echo '</textarea></div>';
        mac_jump( url('update/step2',['jump'=>1]) ,3);
    }

    public function step2()
    {
        $version = config('version.code');

        $save_file = 'database.php';

        echo $this->fetch('admin@public/head');
        echo "<div class='update'><h1>".lang('admin/update/step2_a')."</h1><textarea rows=\"25\" class='layui-textarea' readonly>\n";
        ob_flush();flush();
        sleep(1);

        $res=true;
        // 导入SQL
        $sql_file = $this->_save_path .$save_file;

        if (is_file($sql_file)) {
            echo lang('admin/update/upgrade_sql')."\n";
            ob_flush();flush();
            $pre = config('database.prefix');
            $schema = Db::query('select * from information_schema.columns where table_schema = ?',[ config('database.database') ]);
            $col_list = [];
            $sql='';
            foreach($schema as $k=>$v){
                $col_list[$v['TABLE_NAME']][$v['COLUMN_NAME']] = $v;
            }
            @include $sql_file;

            if(!empty($sql)) {
                $sql_list = mac_parse_sql($sql, 0, ['mac_' => $pre]);

                if ($sql_list) {
                    $sql_list = array_filter($sql_list);
                    foreach ($sql_list as $v) {
                        echo $v;
                        try {
                            Db::execute($v);
                            echo "    ---".lang('success')."\n\n";
                        } catch (\Exception $e) {
                            echo "    ---".lang('fail')."\n\n";
                        }
                        ob_flush();flush();
                    }
                }
            }
            else{

            }
            @unlink($sql_file);
        }
        else{
            echo lang('admin/update/no_sql')."\n";
        }
        echo '</textarea></div>';
        mac_jump(url('update/step3', ['jump' => 1]), 3);
    }

    public function step3()
    {
        echo $this->fetch('admin@public/head');
        echo "<div class='update'><h1>".lang('admin/update/step3_a')."</h1><textarea rows=\"25\" class='layui-textarea' readonly>\n";
        ob_flush();flush();
        sleep(1);

        $this->_cache_clear();

        echo lang('admin/update/update_cache')."\n";
        echo lang('admin/update/upgrade_complete')."";
        ob_flush();flush();
        echo '</textarea></div>';
    }
}
