<?php
namespace app\admin\controller;
use think\Db;
use think\Cache;
use think\Exception;
use app\common\util\Pinyin;

class Collect extends Base
{
    public function __construct()
    {
        parent::__construct();
        //header('X-Accel-Buffering: no');
    }

    public function index()
    {
        $param = input();
        $param['page'] = intval($param['page']) < 1 ? 1 : $param['page'];
        $param['limit'] = intval($param['limit']) < 1 ? 100 : $param['limit'];
        $where = [];

        $order = 'collect_id desc';
        $res = model('Collect')->listData($where, $order, $param['page'], $param['limit']);

        $this->assign('list', $res['list']);
        $this->assign('total', $res['total']);
        $this->assign('page', $res['page']);
        $this->assign('limit', $res['limit']);

        $param['page'] = '{page}';
        $param['limit'] = '{limit}';
        $this->assign('param', $param);

        $key = $GLOBALS['config']['app']['cache_flag']. '_'. 'collect_break_vod';
        $collect_break_vod = Cache::get($key);
        $key = $GLOBALS['config']['app']['cache_flag']. '_'. 'collect_break_art';
        $collect_break_art = Cache::get($key);
        $key = $GLOBALS['config']['app']['cache_flag']. '_'. 'collect_break_actor';
        $collect_break_actor = Cache::get($key);
        $key = $GLOBALS['config']['app']['cache_flag']. '_'. 'collect_break_role';
        $collect_break_role = Cache::get($key);
        $key = $GLOBALS['config']['app']['cache_flag']. '_'. 'collect_break_website';
        $collect_break_website = Cache::get($key);


        $this->assign('collect_break_vod', $collect_break_vod);
        $this->assign('collect_break_art', $collect_break_art);
        $this->assign('collect_break_actor', $collect_break_actor);
        $this->assign('collect_break_role', $collect_break_role);
        $this->assign('collect_break_website', $collect_break_website);

        $this->assign('title',lang('admin/collect/title'));
        return $this->fetch('admin@collect/index');
    }

    public function test()
    {
        $param = input();
        $res = model('Collect')->vod($param);
        return json($res);
    }

    public function info()
    {
        if (Request()->isPost()) {
            $param = input('post.');
            $validate = \think\Loader::validate('Token');
            if(!$validate->check($param)){
                return $this->error($validate->getError());
            }
            $res = model('Collect')->saveData($param);
            if ($res['code'] > 1) {
                return $this->error($res['msg']);
            }
            return $this->success($res['msg']);
        }

        $id = input('id');
        $where = [];
        $where['collect_id'] = ['eq', $id];
        $res = model('Collect')->infoData($where);
        $this->assign('info', $res['info']);
        $this->assign('title', lang('admin/collect/title'));
        return $this->fetch('admin@collect/info');
    }

    public function del()
    {
        $param = input();
        $ids = $param['ids'];

        if (!empty($ids)) {
            $where = [];
            $where['collect_id'] = ['in', $ids];

            $res = model('Collect')->delData($where);
            if ($res['code'] > 1) {
                return $this->error($res['msg']);
            }
            return $this->success($res['msg']);
        }
        return $this->error(lang('param_err'));
    }

    public function union()
    {
        $key = $GLOBALS['config']['app']['cache_flag']. '_'. 'collect_break_vod';
        $collect_break_vod = Cache::get($key);
        $key = $GLOBALS['config']['app']['cache_flag']. '_'. 'collect_break_art';
        $collect_break_art = Cache::get($key);
        $key = $GLOBALS['config']['app']['cache_flag']. '_'. 'collect_break_actor';
        $collect_break_actor = Cache::get($key);
        $key = $GLOBALS['config']['app']['cache_flag']. '_'. 'collect_break_role';
        $collect_break_role = Cache::get($key);
        $key = $GLOBALS['config']['app']['cache_flag']. '_'. 'collect_break_website';
        $collect_break_website = Cache::get($key);

        $this->assign('collect_break_vod', $collect_break_vod);
        $this->assign('collect_break_art', $collect_break_art);
        $this->assign('collect_break_actor', $collect_break_actor);
        $this->assign('collect_break_role', $collect_break_role);
        $this->assign('collect_break_website', $collect_break_website);

        $this->assign('title', lang('admin/collect/title'));
        return $this->fetch('admin@collect/union');
    }

    public function load()
    {
        $param = input();
        $key = $GLOBALS['config']['app']['cache_flag']. '_'. 'collect_break_' . $param['flag'];
        $collect_break = Cache::get($key);
        $url = $this->_ref;
        if (!empty($collect_break)) {
            echo lang('admin/collect/load_break');
            $url = $collect_break;
        }
        mac_jump($url);
    }

    public function api($pp = [])
    {
        $param = input();
        if (!empty($pp)) {
            $param = $pp;
        }

        //分类
        $type_list = model('Type')->getCache('type_list');
        $this->assign('type_list', $type_list);

        if (!empty($param['pg'])) {
            $param['page'] = $param['pg'];
            unset($param['pg']);
        }
        @session_write_close();
        
        if ($param['mid'] == '' || $param['mid'] == '1') {
            return $this->vod($param);
        } elseif ($param['mid'] == '2') {
            return $this->art($param);
        } elseif ($param['mid'] == '8') {
            return $this->actor($param);
        }
        elseif ($param['mid'] == '9') {
            return $this->role($param);
        }
        elseif ($param['mid'] == '11') {
            return $this->website($param);
        }
    }

    public function timing()
    {
        //当日视频分类ids
        $res = model('Vod')->updateToday('type');
        $this->assign('vod_type_ids_today', $res['data']);

        return $this->fetch('admin@collect/timing');
    }

    public function clearbind()
    {
        $param = input();
        $config = [];
        if(!empty($param['cjflag'])){
            $bind_list = config('bind');
            foreach($bind_list as $k=>$v){
                if(strpos($k,$param['cjflag'])===false){
                    $config[$k] = $v;
                }
            }
        }

        $res = mac_arr2file( APP_PATH .'extra/bind.php', $config);
        if($res===false){
            return json(['code'=>0,'msg'=>lang('clear_err')]);
        }
        return json(['code'=>1,'msg'=>lang('clear_ok')]);
    }

    public function bind()
    {
        $param = input();
        $ids = $param['ids'];
        $col = $param['col'];
        $val = $param['val'];

        if(!empty($col)){
            $config = config('bind');
            $config[$col] = intval($val);
            $data = [];
            $data['id'] = $col;
            $data['st'] = 0;
            $data['local_type_id'] = $val;
            $data['local_type_name'] = '';
            if(intval($val)>0){
                $data['st'] = 1;
                $type_list = model('Type')->getCache('type_list');
                $data['local_type_name'] = $type_list[$val]['type_name'];
            }

            $res = mac_arr2file( APP_PATH .'extra/bind.php', $config);
            if($res===false){
                return $this->error(lang('save_err'));
            }
            return $this->success(lang('save_ok'),null, $data);
        }
        return $this->error(lang('param_err'));
    }

    public function vod($param)
    {
        if($param['ac'] != 'list'){
            $key = $GLOBALS['config']['app']['cache_flag']. '_'.'collect_break_vod';
            Cache::set($key, url('collect/api').'?'. http_build_query($param) );
        }
        $res = model('Collect')->vod($param);
        if($res['code']>1){
            return $this->error($res['msg']);
        }

        if($param['ac'] == 'list'){

            $bind_list = config('bind');
            $type_list = model('Type')->getCache('type_list');

            foreach($res['type'] as $k=>$v){
                $key = $param['cjflag'] . '_' . $v['type_id'];
                $res['type'][$k]['isbind'] = 0;
                $local_id = intval($bind_list[$key]);
                if( $local_id>0 ){
                    $res['type'][$k]['isbind'] = 1;
                    $res['type'][$k]['local_type_id'] = $local_id;
                    $type_name = $type_list[$local_id]['type_name'];
                    if(empty($type_name)){
                        $type_name = lang('unknown_type');
                    }
                    $res['type'][$k]['local_type_name'] = $type_name;
                }
            }

            $this->assign('page',$res['page']);
            $this->assign('type',$res['type']);
            $this->assign('list',$res['data']);

            $this->assign('total',$res['page']['recordcount']);
            $this->assign('page',$res['page']['page']);
            $this->assign('limit',$res['page']['pagesize']);

            $param['page'] = '{page}';
            $param['limit'] = '{limit}';
            $this->assign('param',$param);

            $this->assign('param_str',http_build_query($param)) ;

            return $this->fetch('admin@collect/vod');
        }
        $page_now = isset($param['page']) && strlen($param['page']) > 0 ? (int)$param['page'] : 1;
        mac_echo('<title>' . $page_now . '/' . (int)$res['page']['pagecount'] . ' collecting..</title>');
        mac_echo('<style type="text/css">body{font-size:12px;color: #333333;line-height:21px;}span{font-weight:bold;color:#FF0000}</style>');
        model('Collect')->vod_data($param,$res );

    }

    public function art($param)
    {
        if($param['ac'] != 'list'){
            $key = $GLOBALS['config']['app']['cache_flag']. '_'.'collect_break_art';
            Cache::set($key, url('collect/api').'?'. http_build_query($param) );
        }
        $res = model('Collect')->art($param);
        if($res['code']>1){
            return $this->error($res['msg']);
        }

        if($param['ac'] == 'list'){

            $bind_list = config('bind');
            $type_list = model('Type')->getCache('type_list');

            foreach($res['type'] as $k=>$v){
                $key = $param['cjflag'] . '_' . $v['type_id'];
                $res['type'][$k]['isbind'] = 0;
                $local_id = intval($bind_list[$key]);
                if( $local_id>0 ){
                    $res['type'][$k]['isbind'] = 1;
                    $res['type'][$k]['local_type_id'] = $local_id;
                    $type_name = $type_list[$local_id]['type_name'];
                    if(empty($type_name)){
                        $type_name = lang('unknown_type');
                    }
                    $res['type'][$k]['local_type_name'] = $type_name;
                }
            }

            $this->assign('page',$res['page']);
            $this->assign('type',$res['type']);
            $this->assign('list',$res['data']);

            $this->assign('total',$res['page']['recordcount']);
            $this->assign('page',$res['page']['page']);
            $this->assign('limit',$res['page']['pagesize']);

            $param['page'] = '{page}';
            $param['limit'] = '{limit}';
            $this->assign('param',$param);

            $this->assign('param_str',http_build_query($param)) ;

            return $this->fetch('admin@collect/art');
        }

        mac_echo('<style type="text/css">body{font-size:12px;color: #333333;line-height:21px;}span{font-weight:bold;color:#FF0000}</style>');
        model('Collect')->art_data($param,$res );
    }

    public function actor($param)
    {
        if($param['ac'] != 'list'){
            $key = $GLOBALS['config']['app']['cache_flag']. '_'.'collect_break_actor';
            Cache::set($key, url('collect/api').'?'. http_build_query($param) );
        }
        $res = model('Collect')->actor($param);
        if($res['code']>1){
            return $this->error($res['msg']);
        }

        if($param['ac'] == 'list'){

            $bind_list = config('bind');
            $type_list = model('Type')->getCache('type_list');

            foreach($res['type'] as $k=>$v){
                $key = $param['cjflag'] . '_' . $v['type_id'];
                $res['type'][$k]['isbind'] = 0;
                $local_id = intval($bind_list[$key]);
                if( $local_id>0 ){
                    $res['type'][$k]['isbind'] = 1;
                    $res['type'][$k]['local_type_id'] = $local_id;
                    $type_name = $type_list[$local_id]['type_name'];
                    if(empty($type_name)){
                        $type_name = lang('unknown_type');
                    }
                    $res['type'][$k]['local_type_name'] = $type_name;
                }
            }

            $this->assign('page',$res['page']);
            $this->assign('type',$res['type']);
            $this->assign('list',$res['data']);

            $this->assign('total',$res['page']['recordcount']);
            $this->assign('page',$res['page']['page']);
            $this->assign('limit',$res['page']['pagesize']);

            $param['page'] = '{page}';
            $param['limit'] = '{limit}';
            $this->assign('param',$param);

            $this->assign('param_str',http_build_query($param)) ;

            return $this->fetch('admin@collect/actor');
        }

        mac_echo('<style type="text/css">body{font-size:12px;color: #333333;line-height:21px;}span{font-weight:bold;color:#FF0000}</style>');
        model('Collect')->actor_data($param,$res );
    }

    public function role($param)
    {
        if ($param['ac'] != 'list') {
            $key = $GLOBALS['config']['app']['cache_flag']. '_'.'collect_break_role';
            Cache::set($key, url('collect/api') . '?' . http_build_query($param));
        }
        $res = model('Collect')->role($param);
        if ($res['code'] > 1) {
            return $this->error($res['msg']);
        }

        if ($param['ac'] == 'list') {

            $bind_list = config('bind');
            $type_list = model('Type')->getCache('type_list');

            foreach ($res['type'] as $k => $v) {
                $key = $param['cjflag'] . '_' . $v['type_id'];
                $res['type'][$k]['isbind'] = 0;
                $local_id = intval($bind_list[$key]);
                if ($local_id > 0) {
                    $res['type'][$k]['isbind'] = 1;
                    $res['type'][$k]['local_type_id'] = $local_id;
                    $type_name = $type_list[$local_id]['type_name'];
                    if (empty($type_name)) {
                        $type_name = lang('unknown_type');
                    }
                    $res['type'][$k]['local_type_name'] = $type_name;
                }
            }

            $this->assign('page', $res['page']);
            $this->assign('type', $res['type']);
            $this->assign('list', $res['data']);

            $this->assign('total', $res['page']['recordcount']);
            $this->assign('page', $res['page']['page']);
            $this->assign('limit', $res['page']['pagesize']);

            $param['page'] = '{page}';
            $param['limit'] = '{limit}';
            $this->assign('param', $param);

            $this->assign('param_str', http_build_query($param));

            return $this->fetch('admin@collect/role');
        }

        mac_echo('<style type="text/css">body{font-size:12px;color: #333333;line-height:21px;}span{font-weight:bold;color:#FF0000}</style>');
        model('Collect')->role_data($param,$res );
    }

    public function website($param)
    {
        if ($param['ac'] != 'list') {
            $key = $GLOBALS['config']['app']['cache_flag']. '_'.'collect_break_website';
            Cache::set($key, url('collect/api') . '?' . http_build_query($param));
        }
        $res = model('Collect')->website($param);
        if ($res['code'] > 1) {
            return $this->error($res['msg']);
        }

        if ($param['ac'] == 'list') {

            $bind_list = config('bind');
            $type_list = model('Type')->getCache('type_list');

            foreach ($res['type'] as $k => $v) {
                $key = $param['cjflag'] . '_' . $v['type_id'];
                $res['type'][$k]['isbind'] = 0;
                $local_id = intval($bind_list[$key]);
                if ($local_id > 0) {
                    $res['type'][$k]['isbind'] = 1;
                    $res['type'][$k]['local_type_id'] = $local_id;
                    $type_name = $type_list[$local_id]['type_name'];
                    if (empty($type_name)) {
                        $type_name = lang('unknown_type');
                    }
                    $res['type'][$k]['local_type_name'] = $type_name;
                }
            }

            $this->assign('page', $res['page']);
            $this->assign('type', $res['type']);
            $this->assign('list', $res['data']);

            $this->assign('total', $res['page']['recordcount']);
            $this->assign('page', $res['page']['page']);
            $this->assign('limit', $res['page']['pagesize']);

            $param['page'] = '{page}';
            $param['limit'] = '{limit}';
            $this->assign('param', $param);

            $this->assign('param_str', http_build_query($param));

            return $this->fetch('admin@collect/website');
        }

        mac_echo('<style type="text/css">body{font-size:12px;color: #333333;line-height:21px;}span{font-weight:bold;color:#FF0000}</style>');
        model('Collect')->website_data($param,$res );
    }

    public function bang()
    {
        if (Request()->isPost()) {
            $param = input('post.');
            $jiekouarray = $param['jiekouarray'] ?? '';
            $diqu = $param['diqu'] ?? '';
            $niandai = $param['niandai'] ?? '';
            
            if (empty($jiekouarray)) {
                return $this->error('请填写接口配置');
            }
            
            // 解析接口配置
            $jiekou_lines = explode("\n", $jiekouarray);
            $valid_jiekou = [];
            
            foreach ($jiekou_lines as $line) {
                $line = trim($line);
                if (!empty($line) && strpos($line, '#') !== false) {
                    $valid_jiekou[] = $line;
                }
            }
            
            if (empty($valid_jiekou)) {
                return $this->error('接口配置格式错误，请使用"接口名#接口地址"格式');
            }
            

            
            // 执行快捷绑定
            $result = $this->executeBang($valid_jiekou, $diqu, $niandai, $clear_existing, $param);
            
            if ($result['code'] == 1) {
                return $this->success($result['msg'], url('index'));
            } else {
                return $this->error($result['msg']);
            }
        }
        
        $this->assign('title', '自动建立分类');
        return $this->fetch('admin@collect/bang');
    }
    
    /**
     * 快捷匹配分类
     * @param string $type_name 分类名称
     * @return array 匹配结果
     */
    private function quickMatchCategory($type_name)
    {
        $type_name = trim($type_name);

                    // 1. 电影（category_id = 1）
            if (strpos($type_name, '片') !== false || strpos($type_name, '电影解说') !== false) {
                // 排除动画片、动漫片、伦理片、倫理片、预告片
                if (
                    strpos($type_name, '动画片') !== false ||
                    strpos($type_name, '动漫片') !== false ||
                    strpos($type_name, '伦理') !== false ||
                    strpos($type_name, '倫理') !== false ||
                    strpos($type_name, '预告') !== false
                ) {
                    return ['category_id' => 0, 'category_name' => '不处理', 'matched' => false];
                }
                return ['category_id' => 1, 'category_name' => '电影', 'matched' => true];
            }

                    // 2. 连续剧（category_id = 2）
            if (strpos($type_name, '剧') !== false && strpos($type_name, '短剧') === false && strpos($type_name, '反转') === false && strpos($type_name, '爽剧') === false) {
                return ['category_id' => 2, 'category_name' => '连续剧', 'matched' => true];
            }

        // 3. 综艺（category_id = 3）
        if (strpos($type_name, '综艺') !== false) {
            return ['category_id' => 3, 'category_name' => '综艺', 'matched' => true];
        }

        // 4. 动漫（category_id = 4）
        if (strpos($type_name, '动漫') !== false || strpos($type_name, '动画') !== false) {
            return ['category_id' => 4, 'category_name' => '动漫', 'matched' => true];
        }

                    // 5. 短剧（category_id = 5）
            if (strpos($type_name, '短剧') !== false || 
                strpos($type_name, '重生') !== false || 
                strpos($type_name, '民国') !== false || 
                strpos($type_name, '穿越') !== false || 
                strpos($type_name, '现代') !== false || 
                strpos($type_name, '反转') !== false || 
                strpos($type_name, '爽剧') !== false || 
                strpos($type_name, '言情') !== false || 
                strpos($type_name, '总裁') !== false || 
                strpos($type_name, '都市') !== false || 
                strpos($type_name, '古装') !== false || 
                strpos($type_name, '仙侠') !== false || 
                strpos($type_name, '悬疑') !== false || 
                strpos($type_name, '烧脑') !== false) {
                return ['category_id' => 5, 'category_name' => '短剧', 'matched' => true, 'is_main' => true];
            }

        // 默认不匹配
        return ['category_id' => 0, 'category_name' => '不处理', 'matched' => false];
    }
    
    private function executeBang($jiekouarray, $diqu, $niandai, $clear_existing = 0, $param = [])
    {
        try {
            $bind = config('bind');
            $pre = config('database.prefix');
            
            // 检查是否需要清空现有分类
            if ($clear_existing) {
                // 清空所有子分类
                Db::execute('DELETE FROM ' . $pre . 'type WHERE type_id > 5');
                // 清空绑定配置
                $bind = [];
            } else {
                // 首次添加接口时清空现有所有分类（除了主分类）
                $existing_collect = Db::query('SELECT COUNT(*) as count FROM ' . $pre . 'collect');
                if (empty($existing_collect[0]['count'])) {
                    // 首次添加，清空所有子分类
                    Db::execute('DELETE FROM ' . $pre . 'type WHERE type_id > 5');
                    // 清空绑定配置
                    $bind = [];
                }
            }
            
            // 定义五大主分类及其扩展分类
            $main_types = [
                1 => [
                    'name' => '电影',
                    'extend' => [
                        'class' => $param['extend_class_1'] ?? '',
                        'area' => $diqu,
                        'lang' => $param['extend_lang_1'] ?? '国语,英语,日语,韩语,粤语,其他',
                        'year' => $niandai,
                        'star' => '',
                        'director' => '',
                        'state' => '完结',
                        'version' => 'HD,BD,DVD,TC,TS'
                    ]
                ],
                2 => [
                    'name' => '连续剧',
                    'extend' => [
                        'class' => $param['extend_class_2'] ?? '',
                        'area' => $diqu,
                        'lang' => $param['extend_lang_2'] ?? '国语,英语,日语,韩语,粤语,其他',
                        'year' => $niandai,
                        'star' => '',
                        'director' => '',
                        'state' => '完结,连载',
                        'version' => 'HD,BD,DVD,TC,TS'
                    ]
                ],
                3 => [
                    'name' => '综艺',
                    'extend' => [
                        'class' => $param['extend_class_3'] ?? '',
                        'area' => $diqu,
                        'lang' => $param['extend_lang_3'] ?? '国语,英语,日语,韩语,粤语,其他',
                        'year' => $niandai,
                        'star' => '',
                        'director' => '',
                        'state' => '完结,连载',
                        'version' => 'HD,BD,DVD,TC,TS'
                    ]
                ],
                4 => [
                    'name' => '动漫',
                    'extend' => [
                        'class' => $param['extend_class_4'] ?? '',
                        'area' => $diqu,
                        'lang' => $param['extend_lang_4'] ?? '国语,日语,英语,韩语,粤语,其他',
                        'year' => $niandai,
                        'star' => '',
                        'director' => '',
                        'state' => '完结,连载',
                        'version' => 'HD,BD,DVD,TC,TS'
                    ]
                ],
                5 => [
                    'name' => '短剧',
                    'extend' => [
                        'class' => $param['extend_class_5'] ?? '',
                        'area' => $diqu,
                        'lang' => $param['extend_lang_5'] ?? '国语,英语,日语,韩语,粤语,其他',
                        'year' => $niandai,
                        'star' => '',
                        'director' => '',
                        'state' => '完结,连载',
                        'version' => 'HD,BD,DVD,TC,TS'
                    ]
                ]
            ];
            
            // 检查主分类是否已存在，如果存在就更新，不存在就创建
            foreach ($main_types as $main_id => $main_info) {
                $main_name = $main_info['name'];
                $type_en = Pinyin::get($main_name);
                $dalei = json_encode($main_info['extend']);
                
                // 检查分类是否存在
                $existing_type = Db::query('SELECT type_id FROM ' . $pre . 'type WHERE type_id = ?', [$main_id]);
                
                if (!empty($existing_type)) {
                    // 分类已存在，只更新名称和扩展配置
                    $sql = 'UPDATE ' . $pre . 'type SET `type_name`=?, `type_en`=?, `type_extend`=? WHERE `type_id`=?';
                    Db::execute($sql, [$main_name, $type_en, $dalei, $main_id]);
                } else {
                    // 分类不存在，创建新分类
                    $sql = 'INSERT INTO ' . $pre . 'type (`type_id`,`type_name`,`type_en`,`type_pid`, `type_sort`, `type_tpl`,`type_tpl_list`,`type_tpl_detail`,`type_tpl_play`,`type_tpl_down`,`type_extend`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
                    Db::execute($sql, [$main_id, $main_name, $type_en, 0, $main_id, 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', $dalei]);
                }
            }
            
            // 添加采集接口
            foreach ($jiekouarray as $jiekou) {
                $parts = explode('#', $jiekou);
                if (count($parts) != 2) {
                    continue;
                }
                
                $name = $parts[0];
                $api = $parts[1];
                
                // 删除已存在的相同接口
                Db::execute('DELETE FROM ' . $pre . 'collect WHERE collect_url=?', [$api]);
                
                // 判断接口类型并插入
                $collect_type = (strpos($api, 'xml') !== false) ? 1 : 2;
                $sql = 'INSERT INTO ' . $pre . 'collect (`collect_name`,`collect_url`,`collect_type`,`collect_mid`, `collect_filter`,`collect_opt`) VALUES (?, ?, ?, ?, ?, ?)';
                Db::execute($sql, [$name, $api, $collect_type, 1, 0, 0]);
            }
            
            // 创建选中的子分类并生成绑定关系
            $created_sub_types = [];
            $sub_type_id_counter = 10; // 从10开始，避免与主分类ID冲突
            $processed_count = 0;
            $matched_count = 0;
            $arr = []; // 绑定关系数组
            
            // 为每个主分类维护排序计数器
            $sort_counters = [
                1 => 1, // 电影子分类从1开始排序
                2 => 1, // 连续剧子分类从1开始排序
                3 => 1, // 综艺子分类从1开始排序
                4 => 1, // 动漫子分类从1开始排序
                5 => 1  // 短剧子分类从1开始排序
            ];
            
            // 快捷绑定模式：自动处理所有接口分类
            foreach ($jiekouarray as $jiekou) {
                $parts = explode('#', $jiekou);
                if (count($parts) != 2) {
                    continue;
                }
                
                $name = $parts[0];
                $api = $parts[1];
                $collect_type = (strpos($api, 'xml') !== false) ? 1 : 2;
                
                $api_types = $this->getApiTypes($api, $collect_type);
                if (!empty($api_types)) {
                    foreach ($api_types as $type_info) {
                        $processed_count++;
                        $quick_match = $this->quickMatchCategory($type_info['type_name']);
                        
                        // 只处理匹配成功的分类
                        if ($quick_match['matched']) {
                            $matched_count++;
                            $type_name = $type_info['type_name'];
                            
                            // 如果是短剧，直接绑定到主分类，不创建子分类
                            if (isset($quick_match['is_main']) && $quick_match['is_main']) {
                                $arr[md5($api) . '_' . $type_info['type_id']] = $quick_match['category_id'];
                                continue;
                            }
                            
                            // 应用同义词转换
                            $converted_type_name = $this->applySynonym($type_name);
                            
                            // 检查是否已存在相同名称的子分类（使用转换后的名称）
                            if (!isset($created_sub_types[$converted_type_name])) {
                                // 检查数据库中是否已存在相同的type_id
                                $existing_type = Db::query('SELECT type_id FROM ' . $pre . 'type WHERE type_id = ?', [$sub_type_id_counter]);
                                if (!empty($existing_type)) {
                                    $sub_type_id_counter++;
                                    continue;
                                }
                                
                                // 检查数据库中是否已存在相同名称的分类
                                $existing_name = Db::query('SELECT type_id FROM ' . $pre . 'type WHERE type_name = ?', [$converted_type_name]);
                                if (!empty($existing_name)) {
                                    $created_sub_types[$converted_type_name] = $existing_name[0]['type_id'];
                                    continue;
                                }
                                $type_en = Pinyin::get($converted_type_name);
                                $parent_id = $quick_match['category_id'];
                                
                                // 子分类使用简单的扩展配置
                                $dalei = json_encode([
                                    'class' => '',
                                    'area' => '',
                                    'lang' => '',
                                    'year' => '',
                                    'star' => '',
                                    'director' => '',
                                    'state' => '',
                                    'version' => ''
                                ]);
                                
                                try {
                                    $current_sort = $sort_counters[$parent_id];
                                    $sql = 'INSERT INTO ' . $pre . 'type (`type_id`,`type_name`,`type_en`,`type_pid`, `type_sort`, `type_tpl`,`type_tpl_list`,`type_tpl_detail`,`type_tpl_play`,`type_tpl_down`,`type_extend`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
                                    $result = Db::execute($sql, [$sub_type_id_counter, $converted_type_name, $type_en, $parent_id, $current_sort, 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', $dalei]);
                                    
                                    if ($result !== false) {
                                        $created_sub_types[$converted_type_name] = $sub_type_id_counter;
                                        $sub_type_id_counter++;
                                        $sort_counters[$parent_id]++; // 增加排序计数器
                                    } else {
                                        error_log("插入分类失败: {$converted_type_name}, SQL执行返回false");
                                    }
                                } catch (Exception $e) {
                                    error_log("插入分类失败: {$converted_type_name}, 错误: " . $e->getMessage());
                                }
                            }
                            
                            // 生成绑定关系
                            if (isset($created_sub_types[$converted_type_name])) {
                                $local_type_id = $created_sub_types[$converted_type_name];
                                $arr[md5($api) . '_' . $type_info['type_id']] = $local_type_id;
                            }
                        }
                    }
                }
            }
            
            // 更新绑定配置
            $bind = array_merge($bind, $arr);
            $bind_file = APP_PATH . 'extra/bind.php';
            mac_arr2file($bind_file, $bind);
            
            $sub_type_count = count($created_sub_types);
            $bind_count = count($arr);
            
            return [
                'code' => 1, 
                'msg' => "快捷绑定分类成功！处理了{$processed_count}个分类，匹配了{$matched_count}个分类，创建了{$sub_type_count}个子分类，建立了{$bind_count}个绑定关系。"
            ];
            
        } catch (Exception $e) {
            return ['code' => 0, 'msg' => '执行失败：' . $e->getMessage()];
        }
    }
    
    /**
     * 从采集接口获取分类信息
     */
    private function getApiTypes($api_url, $collect_type)
    {
        try {
            // 构建获取分类列表的URL
            $url_param = ['ac' => 'list'];
            $url = $api_url;
            if (strpos($url, '?') === false) {
                $url .= '?';
            } else {
                $url .= '&';
            }
            $url .= http_build_query($url_param);
            
            // 获取接口返回数据
            $html = mac_curl_get($url);
            if (empty($html)) {
                return [];
            }
            
            $html = mac_filter_tags($html);
            
            if ($collect_type == 1) {
                // XML格式
                $xml = simplexml_load_string($html);
                if (!$xml || !isset($xml->class->ty)) {
                    return [];
                }
                
                $types = [];
                foreach ($xml->class->ty as $ty) {
                    $types[] = [
                        'type_id' => (string)$ty->attributes()->id,
                        'type_name' => (string)$ty
                    ];
                }
                return $types;
                
            } else {
                // JSON格式
                $json = json_decode($html, true);
                if (!$json || !isset($json['class'])) {
                    return [];
                }
                
                $types = [];
                foreach ($json['class'] as $class) {
                    $types[] = [
                        'type_id' => $class['type_id'],
                        'type_name' => $class['type_name']
                    ];
                }
                return $types;
            }
            
        } catch (Exception $e) {
            return [];
        }
    }
    

    

    
    /**
     * 同义词管理
     */
    public function synonym()
    {
        if (Request()->isPost()) {
            $param = input('post.');
            $synonym_text = $param['synonym_text'] ?? '';
            
            // 解析同义词配置 - 一行一个格式
            $synonyms = [];
            $lines = explode("\n", $synonym_text);
            foreach ($lines as $line) {
                $line = trim($line);
                if (!empty($line) && strpos($line, '=') !== false) {
                    $parts = explode('=', $line);
                    if (count($parts) == 2) {
                        $source = trim($parts[0]); // 源分类名
                        $target = trim($parts[1]); // 目标分类名
                        if (!empty($source) && !empty($target)) {
                            $synonyms[$source] = $target;
                        }
                    }
                }
            }
            
            // 保存同义词配置
            $synonym_file = APP_PATH . 'extra/synonym.php';
            $res = mac_arr2file($synonym_file, $synonyms);
            
            if ($res === false) {
                return $this->error('保存失败');
            }
            
            return $this->success('保存成功');
        }
        
        // 获取现有同义词配置
        $synonym_file = APP_PATH . 'extra/synonym.php';
        $synonyms = [];
        if (file_exists($synonym_file)) {
            $synonyms = include $synonym_file;
        }
        
        // 转换为显示格式 - 一行一个
        $synonym_text = '';
        foreach ($synonyms as $source => $target) {
            $synonym_text .= $source . '=' . $target . "\n";
        }
        
        $this->assign('synonym_text', $synonym_text);
        $this->assign('title', '同义词管理');
        return $this->fetch('admin@collect/synonym');
    }
    
    /**
     * 获取同义词配置
     */
    private function getSynonyms()
    {
        $synonym_file = APP_PATH . 'extra/synonym.php';
        if (file_exists($synonym_file)) {
            return include $synonym_file;
        }
        return [];
    }
    
    /**
     * 应用同义词转换
     */
    private function applySynonym($type_name)
    {
        // 从配置文件获取同义词
        $synonyms = $this->getSynonyms();
        return isset($synonyms[$type_name]) ? $synonyms[$type_name] : $type_name;
    }
    

    
}
