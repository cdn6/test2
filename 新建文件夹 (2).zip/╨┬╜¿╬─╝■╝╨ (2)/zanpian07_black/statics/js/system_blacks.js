//全局黑色js
var zanpian = {
	// 幻灯片功能
	'image': {
		'swiper': function() {
			$.ajaxSetup({
				cache: true
			});
			$.getScript("https://lf6-cdn-tos.bytecdntp.com/cdn/expire-1-M/Swiper/3.4.2/js/swiper.min.js", function() {
				var swiper = new Swiper('.box-slide', {
					pagination: '.swiper-pagination',
					lazyLoading: true,
					preventClicks: true,
					paginationClickable: true,
					autoplayDisableOnInteraction: false,
					autoplay: 3000,
					loop: true,
					nextButton: '.swiper-button-next',
					prevButton: '.swiper-button-prev',
				});
				var swiper = new Swiper('.details-slide', {
					pagination: '.swiper-pagination',
					autoHeight: true,
					loop: true,
					nextButton: '.details-slide-next',
					prevButton: '.details-slide-pre',
					paginationType: 'fraction',
					keyboardControl: true,
					lazyLoading: true,
					lazyLoadingInPrevNext: true,
					lazyLoadingInPrevNextAmount: 1,
					lazyLoadingOnTransitionStart: true,
				});
				var swiper = new Swiper('.news-switch-3', {
					lazyLoading: true,
					slidesPerView: 3,
					spaceBetween: 0,
					nextButton: '.swiper-button-next',
					prevButton: '.swiper-button-prev',
					breakpoints: {
						1200: {
							slidesPerView: 3,
							spaceBetween: 0
						},
						992: {
							slidesPerView: 2,
							spaceBetween: 0
						},
						767: {
							slidesPerView: 1,
							spaceBetween: 0
						}
					}
				});
				var swiper = new Swiper('.vod-swiper-4', {
					lazyLoading: true,
					slidesPerView: 4,
					spaceBetween: 0,
					nextButton: '.swiper-button-next',
					prevButton: '.swiper-button-prev',
					breakpoints: {
						1200: {
							slidesPerView: 4,
							spaceBetween: 0
						},
						767: {
							slidesPerView: 3,
							spaceBetween: 0
						}
					}
				});
				var swiper = new Swiper('.vod-swiper-5', {
					lazyLoading: true,
					slidesPerView: 5,
					spaceBetween: 0,
					nextButton: '.swiper-button-next',
					prevButton: '.swiper-button-prev',
					breakpoints: {
						1200: {
							slidesPerView: 4,
							spaceBetween: 0
						},
						767: {
							slidesPerView: 3,
							spaceBetween: 0
						}
					}
				});
				var swiper = new Swiper('.vod-swiper-6', {
					lazyLoading: true,
					slidesPerView: 6,
					spaceBetween: 0,
					nextButton: '.swiper-button-next',
					prevButton: '.swiper-button-prev',
					breakpoints: {
						1200: {
							slidesPerView: 5,
							spaceBetween: 0
						},
						992: {
							slidesPerView: 4,
							spaceBetween: 0
						},
						768: {
							slidesPerView: 3,
							spaceBetween: 0
						}
					}
				});
			});
		},
		// 延迟加载
		'lazyload': function() {
			$.ajaxSetup({
				cache: true
			});
			$.getScript("https://lf3-cdn-tos.bytecdntp.com/cdn/expire-1-M/jquery_lazyload/1.9.7/jquery.lazyload.min.js", function(response, status) {
				$(".loading").lazyload({
					effect: "fadeIn",
					failurelimit: 15
				});
			});
		}
	},

	// 主要加载功能
	'cms': {
		'all': function(url) {
			$('body').on("click", "#login,#user_login,#navbar_user_login", function(event) {
				$('.zanpian-modal').modal('hide');
				if (!zanpian.user.islogin()) {
					event.preventDefault();
					zanpian.user.loginform();
					return false;
				}
			});
			$('.navbar-search').click(function() {
				$('.user-search').toggle();
				$('#nav-signed,#example-navbar-collapse').hide();
			})
			$('.navbar-navmore').click(function() {
				$('.user-search').toggle();
				$('#nav-signed,.user-search').hide();
			})

			// 显示更多
			$('body').on("click", ".more-click", function() {
				var self = $(this);
				var box = $(this).attr('data-box');
				var allNum = $(this).attr('data-count');
				var buNum = allNum - $(this).attr('data-limit');
				var sta = $(this).attr('data-sta');
				var hideItem = $('.' + box).find('li[rel="h"]');
				if (sta == undefined || sta == 0) {
					hideItem.show(200);
					$(this).find('span').text('收起部分' + buNum);
					self.attr('data-sta', 1);
				} else {
					hideItem.hide(200);
					$(this).find('span').text('查看全部' + allNum);
					self.attr('data-sta', 0);
				}
			});
			// 键盘上一页下一页
			var prevpage = $("#pre").attr("href");
			var nextpage = $("#next").attr("href");
			$("body").keydown(function(event) {
				if (event.keyCode == 37 && prevpage != undefined) location = prevpage;
				if (event.keyCode == 39 && nextpage != undefined) location = nextpage;
			});
			// 播放窗口隐藏右侧板块
			$('body').on("click", "#player-shrink", function() {
				$(".player_right").toggle();
				$(".player_left").toggleClass("max");
				$(".player-shrink").toggleClass("icon-left");
			});
			$('body').on("click", "#lyric", function(event) {
				$("#" + $(this).data('id')).toggle();
			});
			$(".player-tool em").click(function() {
				$html = $(this).html();
				try {
					if ($html == '关灯') {
						$(this).html('开灯')
					} else {
						$(this).html('关灯')
					}
				} catch (e) {}
				$(".player-open").toggle(300);
				$(".player_left").toggleClass("player-top")
				$(".player_right").toggleClass("player-top")
			});
		},

		// 切换功能
		'tab': function() {
			$("#myTab li a").click(function(e) {
				$(this).tab('show');
			});
		},

		// 返回顶部功能
		'scrolltop': function() {
			var a = $(window);
			$scrollTopLink = $("a.backtop");
			a.scroll(function() {
				500 < $(this).scrollTop() ? $scrollTopLink.css("display", "block") : $scrollTopLink.css("display", "none")
			});
			$scrollTopLink.on("click", function() {
				$("html, body").animate({
					scrollTop: 0
				}, 400);
				return !1
			})
		},

		// 展开收起功能
		'collapse': function() {
			var w = document.documentElement ? document.documentElement.clientWidth : document.body.clientWidth;
			if (w > 640) {
				$(".list_type").addClass("in");
			}

			$('body').on("click", "[data-toggle=collapse]", function() {
				$this = $(this);
				$($this.attr('data-target')).toggle();
				$($this.attr('data-default')).toggle();
				if ($this.attr('data-html')) {
					$data_html = $this.html();
					$this.html($this.attr('data-html'));
					$this.attr('data-html', $data_html);
				}
				if ($this.attr('data-val')) {
					$data_val = $this.val();
					$this.val($this.attr('data-val'));
					$this.attr('data-val', $data_val);
				}
			});
		}
	},

	'detail': {
		'playlist': function() {
			// 更多播放地址切换
			$(".player-more .dropdown-menu li").click(function() {
				$("#playTab").find('li').removeClass('active');
				var activeTab = $(this).html();
				var prevTab = $('.player-more').prev('li').html();
				$('.player-more').prev('li').addClass('active').html(activeTab);
				$(this).html(prevTab);
			});
			if ($('.player-more').length > 0) {
				$(".dropdown-menu li.active").each(function() {
					var activeTab = $(this).html();
					var prevTab = $('.player-more').prev('li').html();
					$('.player-more').prev('li').addClass('active').html(activeTab);
					$(this).html(prevTab).removeClass('active');
				});
			}
			// 手机端播放源切换
			$(".mplayer .dropdown-menu li").click(function() {
				var $link = $(this).find('a');
				var sclass = $link.attr('class');
				var shtml = $link.html();
				$("#myTabDrop2 .name").html(shtml);
				$("#myTabDrop2").removeClass().addClass('gico ' + sclass);
			});
			$(".mplayer .dropdown-menu li").click(function() {
				var $link = $(this).find('a');
				var sclass = $link.attr('class');
				var shtml = $link.html();
				$("#myTabDrop3 .name").html(shtml);
				$("#myTabDrop3").removeClass().addClass('gico ' + sclass);
			});

			// 更多剧集
			$('.playlist ul').each(function() {
				var $playlist = $(this);
				var episodes = $playlist.find('li').get();

				// 清空并重新添加剧集
				$playlist.empty();

				// 默认显示前21集
				var visibleCount = 21;
				var showAll = episodes.length <= visibleCount;

				if (!showAll) {
					// 定义一个函数来添加更多按钮和最新两集
					function addMoreButtonAndLatestEpisodes() {
						// 添加"更多"按钮
						var moreBtn = $('<li class="more-btn"><a href="javascript:;" style="color:#ff6700;font-weight:bold;">更多剧集 <span style="font-size: 0.9em;">▼</span></a></li>');
						$playlist.append(moreBtn);

						// 添加最后两集（最新两集）
						if (episodes.length >= 2) {
							$playlist.append($(episodes[episodes.length - 2]).clone()); // 倒数第二集
						}
						$playlist.append($(episodes[episodes.length - 1]).clone()); // 最后一集

						// 点击“更多”按钮的处理
						moreBtn.on('click', function() {
							$playlist.empty();
							episodes.forEach(function(ep) {
								$playlist.append(ep); // 保持原顺序添加所有剧集
							});

							// 添加“收起”按钮
							addLessButton();
						});
					}

					// 定义一个函数来添加收起按钮
					function addLessButton() {
						var lessBtn = $('<li class="less-btn"><a href="javascript:;" style="color:#ff6700;font-weight:bold;">收起剧集 <span style="font-size: 0.9em;">▲</span></a></li>');
						$playlist.append(lessBtn);

						// 点击“收起”按钮的处理
						lessBtn.on('click', function() {
							$playlist.empty();
							episodes.slice(0, visibleCount).forEach(function(ep) {
								$playlist.append(ep); // 只添加前21集
							});

							// 重新添加更多按钮和最新两集
							addMoreButtonAndLatestEpisodes();
						});
					}

					// 添加可见剧集（1-21集）
					episodes.slice(0, visibleCount).forEach(function(ep) {
						$playlist.append(ep); // 直接添加原顺序的前21集
					});

					// 初始化添加更多按钮和最新两集
					addMoreButtonAndLatestEpisodes();
				} else {
					// 如果集数少于等于21集，直接全部显示
					episodes.forEach(function(ep) {
						$playlist.append(ep);
					});
				}
			});

			// 提取剧集数字的辅助函数
			function extractEpisodeNumber(text) {
				var match = text.match(/\d+/);
				return match ? parseInt(match[0], 10) : 0;
			}


		},
		// 保留原来的playerlist函数
		'playerlist': function() {
			var height = $(".player_left").height();
			if ($('.player_prompt').length > 0) {
				var height = height - 50;
			}
			$(".player_playlist").css('max-height', height - 55);
			var mheight = $(".mobile_player_left").height();
			if ($(".player_playlist").height() > mheight) {
				$(".player_playlist").css('max-height', mheight - 55);
			}
		},
		// 手机剧情简介功能
		'plot': function() {
			$(document).ready(function() {
				// 展开时隐藏默认内容
				$('.details-content-all').on('show.bs.collapse', function() {
					$('.details-content-default').hide();
					$('.plot-caret').css('transform', 'rotate(180deg)');
					$('.btn-toggle .text').text('收起详情');
				});

				// 收起时显示默认内容
				$('.details-content-all').on('hide.bs.collapse', function() {
					$('.details-content-default').show();
					$('.plot-caret').css('transform', 'rotate(0deg)');
					$('.btn-toggle .text').text('展开详情');
				});
			});
		}
	},

	// 新增：整合新增的代码
	'misc': {
		'init': function() {
			// 播放记录
			const STORAGE_KEY = 'playRecords';
			const playlogList = document.getElementById('playlog_list');
			const playlogTrigger = document.querySelector('.user_playlog');

			playlogTrigger.addEventListener('mouseenter', function() {
				playlogList.style.display = 'block';
				renderPlayRecords();
			});

			document.getElementById('playlog-close').addEventListener('click', () => {
				playlogList.style.display = 'none';
			});

			document.getElementById('playlog-clear').addEventListener('click', function() {
				if (confirm('确定要清空所有播放记录吗？')) {
					localStorage.removeItem(STORAGE_KEY);
					renderPlayRecords();
				}
			});

			const hitsElement = document.querySelector('.mac_hits.hits');
			if (hitsElement) {
				const record = {
					id: hitsElement.dataset.id,
					name: hitsElement.dataset.name,
					title: hitsElement.dataset.title,
					link: hitsElement.dataset.link,
					date: new Date().toLocaleDateString()
				};
				addPlayRecord(record);
			}

			function addPlayRecord(newRecord) {
				let records = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
				records = records.filter(record => record.id !== newRecord.id);
				records.unshift(newRecord);
				if (records.length > 50) {
					records = records.slice(0, 50);
				}
				localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
			}

			function renderPlayRecords() {
				const ul = playlogList.querySelector('ul');
				ul.innerHTML = '';
				const records = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];

				if (records.length === 0) {
					ul.innerHTML = '<strong>暂无观看历史记录列表</strong>';
					return;
				}

				records.forEach(record => {
					const li = document.createElement('li');
					li.innerHTML = `
                        <a href="${record.link}" class="text-overflow" style="display:block; padding:8px 15px; background-color:#444; color:#09BB07; text-decoration:none;">
                            ${record.name} / ${record.title}
                            <span style="float:right; color:#999; font-size:0.9em;">${record.date}</span>
                        </a>
                    `;
					ul.appendChild(li);
				});
			}

			playlogList.style.display = 'none';

			// 刷新功能
			var refreshBtn = document.getElementById('refreshBtn');
			if (refreshBtn) {
				refreshBtn.addEventListener('click', function() {
					location.reload();
				});
			}

			// 分享功能
			var shareBtn = document.getElementById('shareBtn');
			if (shareBtn) {
				shareBtn.addEventListener('click', function() {
					const tempInput = document.createElement('input');
					tempInput.value = window.location.href;
					document.body.appendChild(tempInput);
					tempInput.select();

					try {
						document.execCommand('copy');
						alert('链接已复制，分享成功！');
					} catch (err) {
						alert('自动复制失败，请手动复制链接');
					} finally {
						document.body.removeChild(tempInput);
					}
				});
			}
		}
	}
};

// 初始化调用
$(document).ready(function() {
	zanpian.image.swiper(); // 初始化幻灯片
	zanpian.image.lazyload(); // 懒加载图片
	zanpian.cms.all(); // 初始化主要加载功能
	zanpian.cms.tab(); // 初始化切换功能
	zanpian.cms.scrolltop(); // 初始化返回顶部功能
	zanpian.detail.playlist(); // 初始化更多剧集功能
	zanpian.detail.playerlist(); // 初始化播放列表高度调整功能
	zanpian.detail.plot(); // 初始化手机剧情简介功能
	zanpian.cms.collapse(); // 初始化展开收起功能
	zanpian.misc.init(); // 初始化新增功能
});