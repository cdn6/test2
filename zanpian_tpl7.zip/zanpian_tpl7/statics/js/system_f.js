var zanpian = {
    // 幻灯片功能
    'image': {
        'swiper': function(){    
            $.ajaxSetup({
                cache: true
            });
            $.getScript("/template/zanpian_tpl7/statics/js/swiper.min.js", function(){    
                var swiper=new Swiper('.box-slide',{pagination:'.swiper-pagination',lazyLoading:true,preventClicks:true,paginationClickable:true,autoplayDisableOnInteraction:false,autoplay:3000,loop:true,nextButton:'.swiper-button-next',prevButton:'.swiper-button-prev',});
                var swiper=new Swiper('.details-slide',{pagination:'.swiper-pagination',autoHeight:true,loop:true,nextButton:'.details-slide-next',prevButton:'.details-slide-pre',paginationType:'fraction',keyboardControl:true,lazyLoading:true,lazyLoadingInPrevNext:true,lazyLoadingInPrevNextAmount:1,lazyLoadingOnTransitionStart:true,});
                var swiper=new Swiper('.news-switch-3',{lazyLoading:true,slidesPerView:3,spaceBetween:0,nextButton:'.swiper-button-next',prevButton:'.swiper-button-prev',breakpoints:{1200:{slidesPerView:3,spaceBetween:0},992:{slidesPerView:2,spaceBetween:0},767:{slidesPerView:1,spaceBetween:0}}});
                var swiper=new Swiper('.news-switch-4',{lazyLoading:true,slidesPerView:4,spaceBetween:0,nextButton:'.swiper-button-next',prevButton:'.swiper-button-prev',breakpoints:{1200:{slidesPerView:4,spaceBetween:0},992:{slidesPerView:3,spaceBetween:0},767:{slidesPerView:2,spaceBetween:0}}});
                var swiper=new Swiper('.news-switch-5',{lazyLoading:true,slidesPerView:5,spaceBetween:0,nextButton:'.swiper-button-next',prevButton:'.swiper-button-prev',breakpoints:{1200:{slidesPerView:4,spaceBetween:0},992:{slidesPerView:3,spaceBetween:0},767:{slidesPerView:2,spaceBetween:0}}});
                var swiper=new Swiper('.vod-swiper-4',{lazyLoading:true,slidesPerView:4,spaceBetween:0,nextButton:'.swiper-button-next',prevButton:'.swiper-button-prev',breakpoints:{1200:{slidesPerView:4,spaceBetween:0},767:{slidesPerView:3,spaceBetween:0}}});
                var swiper=new Swiper('.vod-swiper-5',{lazyLoading:true,slidesPerView:5,spaceBetween:0,nextButton:'.swiper-button-next',prevButton:'.swiper-button-prev',breakpoints:{1200:{slidesPerView:4,spaceBetween:0},767:{slidesPerView:3,spaceBetween:0}}});
                var swiper=new Swiper('.vod-swiper-6',{lazyLoading:true,slidesPerView:6,spaceBetween:0,nextButton:'.swiper-button-next',prevButton:'.swiper-button-prev',breakpoints:{1200:{slidesPerView:5,spaceBetween:0},992:{slidesPerView:4,spaceBetween:0},768:{slidesPerView:3,spaceBetween:0}}});        
            });
        },
        	//延迟加载
	'lazyload': function(){
		$.ajaxSetup({
			cache: true
		});
		$.getScript("/template/zanpian_tpl7/statics/js/jquery.lazyload.min.js", function(response,status){
			$(".loading").lazyload({
				effect : "fadeIn",
				failurelimit: 15
			}); 
		});
	}	
    },

    // 主要加载功能
    'cms': {
        'all': function(url){
            $('body').on("click", "#login,#user_login,#navbar_user_login", function(event){
                $('.zanpian-modal').modal('hide');                                                                      
                if(!zanpian.user.islogin()){
                   event.preventDefault();
                   zanpian.user.loginform();
                   return false;
                }
            });
            $('.navbar-search').click(function(){
                $('.user-search').toggle();
                $('#nav-signed,#example-navbar-collapse').hide();                                                      
            })
            $('.navbar-navmore').click(function(){
                $('.user-search').toggle();
                $('#nav-signed,.user-search').hide();                                                      
            })
 
            //显示更多
            $('body').on("click", ".more-click", function() {
                var self = $(this);
                var box = $(this).attr('data-box');
                var allNum = $(this).attr('data-count');
                var buNum = allNum - $(this).attr('data-limit');
                var sta = $(this).attr('data-sta');
                var hideItem = $('.' + box).find('li[rel="h"]');
                if (sta == undefined || sta == 0) {
                    hideItem.show(200);
                    $(this).find('span').text('收起部分' + buNum);
                    self.attr('data-sta', 1);
                } else {
                    hideItem.hide(200);
                    $(this).find('span').text('查看全部' + allNum);
                    self.attr('data-sta', 0);
                }
            });
            //键盘上一页下一页
            var prevpage = $("#pre").attr("href");
            var nextpage = $("#next").attr("href");
            $("body").keydown(function(event) {
                if (event.keyCode == 37 && prevpage != undefined) location = prevpage;
                if (event.keyCode == 39 && nextpage != undefined) location = nextpage;
            });
            //播放窗口隐藏右侧板块
            $('body').on("click", "#player-shrink", function() {
                $(".player_right").toggle();
                $(".player_left").toggleClass("max");
                $(".player-shrink").toggleClass("icon-left");
            });
            $('body').on("click", "#lyric", function(event){
                $("#"+$(this).data('id')).toggle();
            });        
            $(".player-tool em").click(function() {
                $html = $(this).html();
                try {
                    if ($html == '关灯') {
                        $(this).html('开灯')
                    } else {
                        $(this).html('关灯')
                    }
                } catch (e) {}
                $(".player-open").toggle(300);
                $(".player_left").toggleClass("player-top")
                $(".player_right").toggleClass("player-top")
            });
        },

        // 切换功能
        'tab': function() {
            $("#myTab li a").click(function(e) {
                $(this).tab('show');
            });
        },

        // 返回顶部功能
        'scrolltop': function() {
            var a = $(window);
            $scrollTopLink = $("a.backtop");
            a.scroll(function() {
                500 < $(this).scrollTop() ? $scrollTopLink.css("display", "block") : $scrollTopLink.css("display", "none")
            });
            $scrollTopLink.on("click", function() {
                $("html, body").animate({
                    scrollTop: 0
                }, 400);
                return !1
            })
        },

        // 展开收起功能
        'collapse': function() {
            var w = document.documentElement ? document.documentElement.clientWidth : document.body.clientWidth;
            if (w > 640) {
                $(".list_type").addClass("in");
            }

            $('body').on("click", "[data-toggle=collapse]", function() {
                $this = $(this);
                $($this.attr('data-target')).toggle();
                $($this.attr('data-default')).toggle();
                if ($this.attr('data-html')) {
                    $data_html = $this.html();
                    $this.html($this.attr('data-html'));
                    $this.attr('data-html', $data_html);
                }
                if ($this.attr('data-val')) {
                    $data_val = $this.val();
                    $this.val($this.attr('data-val'));
                    $this.attr('data-val', $data_val);
                }
            });
        }
    },

    // 更多剧集功能
    'detail': {
        'playlist': function() {
            //更多播放地址切换
            $(".player-more .dropdown-menu li").click(function() {
                $("#playTab").find('li').removeClass('active');
                var activeTab = $(this).html();
                var prevTab = $('.player-more').prev('li').html();
                $('.player-more').prev('li').addClass('active').html(activeTab);
                $(this).html(prevTab);
            });
            if ($('.player-more').length > 0) {
                $(".dropdown-menu li.active").each(function() {
                    var activeTab = $(this).html();
                    var prevTab = $('.player-more').prev('li').html();
                    $('.player-more').prev('li').addClass('active').html(activeTab);
                    $(this).html(prevTab).removeClass('active');
                });
            }
            //手机端播放源切换
            $(".mplayer .dropdown-menu li").click(function() {
                var sclass = $(this).find('a').attr('class');
                var stext = $(this).text();
                $("#myTabDrop2 .name").text(stext);
                $("#myTabDrop2").removeClass($("#myTabDrop2").attr('class'));
                $("#myTabDrop2").addClass(sclass);
            });        
            var WidthScreen = true;
            for (var i = 0; i < $(".playlist ul").length; i++) {
                series($(".playlist ul").eq(i), 20, 1);
            }
            function series(div, n1, n2) { //更多剧集方法
                var len = div.find("li").length;
                var n = WidthScreen ? n1 : n2;
                if (len > 24) {
                    for (var i = n2 + 18; i < len - ((n1 / 2) - 2) / 2; i++) {
                        div.find("li").eq(i).addClass("hided");
                    }
                    var t_m = "<li class='more open'><a target='_self' href='javascript:void(0)'>更多剧集</a></li>";
                    div.find("li").eq(n2 + 17).after(t_m);
                    var more = div.find(".more");
                    var _open = false;
                    div.css("height", "auto");
                    more.click(function() {
                        if (_open) {
                            div.find(".hided").hide();
                            $(this).html("<a target='_self' href='javascript:void(0)'>更多剧集</a>");
                            $(this).removeClass("closed");
                            $(this).addClass("open");
                            $(this).insertAfter(div.find("li").eq(n2 + 17));
                            _open = false;
                        } else {
                            div.find(".hided").show();
                            $(this).html("<a target='_self' href='javascript:void(0)'>收起剧集</a>");
                            $(this).removeClass("open");
                            $(this).addClass("closed");
                            $(this).insertAfter(div.find("li:last"));
                            _open = true;
                        }
                    })
                }
            }
        },
        // 新增的播放列表高度调整功能
        'playerlist': function() {
			var height = $(".player_left").height();
			if ($('.player_prompt').length > 0){
					var height = height-50;	
			}
			//$(".player_playlist").height(height - 55);
			$(".player_playlist").css('max-height',height - 55);
			var mheight = $(".mobile_player_left").height();
			if ($(".player_playlist").height() > mheight){
			    //$(".player_playlist").height(mheight - 55);
			    $(".player_playlist").css('max-height',mheight - 55);
			}
        }
    },
};

// 初始化调用
$(document).ready(function(){
    zanpian.image.swiper(); // 初始化幻灯片
    zanpian.image.lazyload();//懒加载图片
    zanpian.cms.all(); // 初始化主要加载功能
    zanpian.cms.tab(); // 初始化切换功能
    zanpian.cms.scrolltop(); // 初始化返回顶部功能
    zanpian.detail.playlist(); // 初始化更多剧集功能
    zanpian.detail.playerlist(); // 新增：初始化播放列表高度调整功能
    zanpian.cms.collapse(); // 初始化展开收起功能
});

//幻灯补充
document.addEventListener("DOMContentLoaded", function() {
    const slides = document.querySelectorAll('.swiper-slide');
    const slideContainer = document.querySelector('.slides');
    if (slides.length === 0 && slideContainer) {
        slideContainer.style.display = 'none';
    }
});

//播放记录
document.addEventListener('DOMContentLoaded', function() {
    const STORAGE_KEY = 'playRecords';
    const playlogList = document.getElementById('playlog_list');
    const playlogTrigger = document.querySelector('.user_playlog');

    playlogTrigger.addEventListener('mouseenter', function() {
        playlogList.style.display = 'block';
        renderPlayRecords();
    });

    document.getElementById('playlog-close').addEventListener('click', () => {
        playlogList.style.display = 'none';
    });

    document.getElementById('playlog-clear').addEventListener('click', function() {
        if (confirm('确定要清空所有播放记录吗？')) {
            localStorage.removeItem(STORAGE_KEY);
            renderPlayRecords();
        }
    });

    const hitsElement = document.querySelector('.mac_hits.hits');
    if (hitsElement) {
        const record = {
            id: hitsElement.dataset.id,
            name: hitsElement.dataset.name,
            title: hitsElement.dataset.title,
            link: hitsElement.dataset.link,
            date: new Date().toLocaleDateString()
        };
        addPlayRecord(record);
    }

    function addPlayRecord(newRecord) {
        let records = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
        records = records.filter(record => record.id !== newRecord.id);
        records.unshift(newRecord);
        if (records.length > 50) {
            records = records.slice(0, 50);
        }
        localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
    }

    function renderPlayRecords() {
        const ul = playlogList.querySelector('ul');
        ul.innerHTML = '';
        const records = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
        
        if (records.length === 0) {
            ul.innerHTML = '<strong>暂无观看历史记录列表</strong>';
            return;
        }

        records.forEach(record => {
            const li = document.createElement('li');
            li.innerHTML = `
                <a href="${record.link}" class="text-overflow" style="display:block; padding:8px 15px; color:#333; text-decoration:none;">
                    ${record.name} / ${record.title}
                    <span style="float:right; color:#999; font-size:0.9em;">${record.date}</span>
                </a>
            `;
            ul.appendChild(li);
        });
    }

    playlogList.style.display = 'none';
});

document.addEventListener('DOMContentLoaded', function() {
    // 刷新功能
    var refreshBtn = document.getElementById('refreshBtn');
    if(refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            location.reload();
        });
    }

    // 分享功能
    var shareBtn = document.getElementById('shareBtn');
    if(shareBtn) {
        shareBtn.addEventListener('click', function() {
            const tempInput = document.createElement('input');
            tempInput.value = window.location.href;
            document.body.appendChild(tempInput);
            tempInput.select();
            
            try {
                document.execCommand('copy');
                alert('链接已复制，分享成功！');
            } catch (err) {
                alert('自动复制失败，请手动复制链接');
            } finally {
                document.body.removeChild(tempInput);
            }
        });
    }
});