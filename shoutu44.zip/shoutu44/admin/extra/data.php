<?php
return array (
  'set' => 
  array (
    'seatext' => '',
    'seatext_is' => '0',
    'topadjs' => '',
    'topadjs_is' => '0',
    'footadjs' => '',
    'footadjs_is' => '0',
    'footcode' => '',
    'footcode_is' => '0',
  ),
  'basic' => 
  array (
    'favicon' => '/template/shoutu44/assets/images/favicon.ico',
    'logo' => '/template/shoutu44/assets/images/logo.png',
    'static' => '',
    'static_is' => '0',
    'substatic' => '',
    'substatic_is' => '0',
    'foottips' => '本站所有视频和图片均来自互联网收集而来，版权归原创者所有，本网站只提供web页面服务，并不提供资源存储，也不参与录制、上传。',
    'foottips_is' => '1',
    'jscode' => '',
    'jscode_is' => '0',
    'paw_name' => '首涂影视',
    'paw_short_name' => '首涂影视',
    'paw_icon512' => '/template/shoutu44/assets/app/icons/android-chrome-512x512.png',
    'paw_icon192' => '/template/shoutu44/assets/app/icons/android-chrome-192x192.png',
    'paw_theme_color' => '#090b21',
    'paw_background_color' => '#090b21',
  ),
  'other' => 
  array (
    'modeno' => '0',
    'rightno' => '0',
    'f12no' => '0',
    'iframeno' => '0',
    'selectno' => '0',
    'pcflase' => '0',
    'rightnotext' => '你知道的太多了！',
    'opgreytime' => '2024-04-21',
    'opgrey' => '0',
  ),
  'index' => 
  array (
    'data' => 
    array (
      0 => 
      array (
        'is' => '1',
        'title' => '最新上映',
        'block' => 'vod_list',
        'type' => '1,2,3,4,5',
        'by' => '',
        'subval' => '',
      ),
      1 => 
      array (
        'is' => '1',
        'title' => '热门电影',
        'block' => 'vod_list2',
        'type' => '1',
        'by' => '',
        'subval' => 'index.php/vod/type/id/1.html',
      ),
      2 => 
      array (
        'is' => '1',
        'title' => '热门电视剧',
        'block' => 'vod_list2',
        'type' => '2',
        'by' => '',
        'subval' => '',
      ),
      5 => 
      array (
        'is' => '1',
        'title' => '广告',
        'block' => 'vod_ad',
        'type' => '1',
        'by' => '',
        'subval' => '',
      ),
      3 => 
      array (
        'is' => '1',
        'title' => '热门综艺',
        'block' => 'vod_list2',
        'type' => '3',
        'by' => '',
        'subval' => '',
      ),
      4 => 
      array (
        'is' => '1',
        'title' => '热门动漫',
        'block' => 'vod_list2',
        'type' => '4',
        'by' => '',
        'subval' => '',
      ),
      5 => 
      array (
        'is' => '1',
        'title' => '热门短剧',
        'block' => 'vod_list2',
        'type' => '5',
        'by' => '',
        'subval' => '',
      ),
    ),
  ),
 // 'ad' => 
 // array (
 //   'data' => 
//    array (
 //     1 => 
 //     array (
 //       'is' => '1',
 //       'title' => '首页1号',
 //       'url' => '#',
//        'img' => 'https://m.ykimg.com/material/0A03/A1/202212/1221/3082837/1671604679858/0D01000063A2AAE50742279232473155.jpg',
  //      'blank' => '0',
 //     ),
//    ),
 // ),
  'seo1' => 
  array (
    'title' => '[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo0' => 
  array (
    'title' => '[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
    'diy' => '',
  ),
  'seo10' => 
  array (
    'title' => '视频首页-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo14' => 
  array (
    'title' => '[vod_name]-在线观看-[vod_area][vod_year][vod_class]片-[site_name]',
    'key' => '[site_keywords],[vod_class]',
    'des' => '[vod_blurb]',
    'diy' => '',
  ),
  'seo15' => 
  array (
    'title' => '[vod_name]-在线观看在线下载-[vod_area][vod_year][vod_class]片-[site_name]',
    'key' => '[site_keywords],[vod_class]',
    'des' => '[vod_blurb]',
  ),
  'seo11' => 
  array (
    'title' => '[type_name]-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo30' => 
  array (
    'title' => '专题首页-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo12' => 
  array (
    'title' => '[type_name]-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo13' => 
  array (
    'title' => '搜索结果-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo31' => 
  array (
    'title' => '[topic_name]-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[topic_blurb]',
  ),
  'seo2' => 
  array (
    'title' => '网站地图-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo4' => 
  array (
    'title' => '留言板-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'nav_head' => 
  array (
    'data' => 
    array (
      0 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '首页',
        'type' => 'web',
        'val' => '/',
        'fval' => '',
        'blank' => '0',
      ),
      1 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '电影',
        'type' => '1',
        'val' => '1',
        'fval' => '',
        'blank' => '0',
      ),
      2 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '电视剧',
        'type' => '1',
        'val' => '2',
        'fval' => '',
        'blank' => '0',
      ),
      3 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '综艺',
        'type' => '1',
        'val' => '3',
        'fval' => '',
        'blank' => '0',
      ),
      4 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '动漫',
        'type' => '1',
        'val' => '4',
        'fval' => '',
        'blank' => '0',
      ),
      5 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '短剧',
        'type' => '1',
        'val' => '5',
        'fval' => '',
        'blank' => '0',
      ),	  
    ),
  ),
  'poster' => 
  array (
    'lopimg' => '/template/shoutu44/assets/images/load.png',
    'subtitle1' => 'vod_remarks',
    'subtitle_is' => '0',
    'subtitle1_is' => '1',
    'subtitle2' => 'vod_douban_score',
    'subtitle2_is' => '1',
    'text1' => 'vod_year',
    'text1_is' => '1',
    'text2' => 'vod_area',
    'text2_is' => '1',
  ),
  'player' => 
  array (
    'ali_is' => '1',
    'playersmallbox_is' => '1',
  ),
  'play' => 
  array (
    'id' => '2',
    'side_is' => '0',
  ),
  'screen' => 
  array (
    'type_is' => '1',
    'class_is' => '1',
    'area_is' => '1',
    'year_is' => '1',
    'lang_is' => '1',
    'letter_is' => '1',
    'by_is' => '1',
  ),
);