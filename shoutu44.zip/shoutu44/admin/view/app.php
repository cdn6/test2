<?php 
	require('./config.php');
    $data = $config['app'];
	$href = '?url=app&array=play&';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>后台管理中心</title>
<?php require('header.php');?>
</head>
	<body>
		<div class="page-container more nav">
			<?php require('top.php');?>
			<ul class="layui-nav">
				<?php config_menu($config) ?>
			</ul>
            <div class="layui-tab-content">
                <div class="play poster">
                    <fieldset class="layui-elem-field">
                        <legend>APP设置</legend>
                        <form class="layui-form" method="post" action="?url=app&array=overall&type=post" enctype="multipart/form-data">
                        <div class="layui-field-box" style="margin-top: 15px;">
                            <div class="layui-form-item">
                                <div class="layui-inline">
                                    <div class="layui-input-inline">
                                        <label class="layui-form-label" style="padding-right: 5px;">全局提示下载</label>
                                    </div>
                                    <div class="layui-input-inline">
                                       <input type="hidden" name="down_is" value="0">
                                    </div>
                                    <div class="layui-input-inline" style="width:190px;">
                                       <input type="checkbox" lay-skin="primary" name="down_is" value="1" title="显示" <?php if($config['overall']['down_is']) { echo "checked"; }?>>
                                    </div>
                                     <div class="layui-input-inline" style="margin-top: 25px;"></div>
                                </div>
                                
                                    <div class="layui-inline">
                                    <div class="layui-input-inline">
                                        <label class="layui-form-label" style="padding-right: 5px;">跳转链接</label>
                                    </div>
                                    <div class="layui-input-inline">
                                        <input type="text" class="layui-input upload-input" value="<?php echo $config['overall']['downlink'];?>" name="downlink">
                                    </div>
                                     <div class="layui-input-inline"></div>
                                    <div class="layui-input-inline" style="margin-top: 25px;"></div>
                                </div>
                                
                                 <div class="layui-inline">
                                    <div class="layui-input-inline">
                                        <label class="layui-form-label" style="padding-right: 5px;">下载提示语</label>
                                    </div>
                                    <div class="layui-input-inline">
                                        <input type="text" class="layui-input upload-input" value="<?php echo $config['overall']['downtips'];?>" name="downtips">
                                    </div>
                                     <div class="layui-input-inline"></div>
                                    <div class="layui-input-inline" style="margin-top: 25px;"></div>
                                </div>
                                
                                
                               
                               <div class="layui-inline">
                                    <div class="layui-input-inline">
                                        <label class="layui-form-label" style="padding-right: 5px;">导航APP</label>
                                    </div>
                                    <div class="layui-input-inline">
                                       <input type="hidden" name="navdown_is" value="0">
                                    </div>
                                    <div class="layui-input-inline" style="width:190px;">
                                       <input type="checkbox" lay-skin="primary" name="navdown_is" value="1" title="显示" <?php if($config['overall']['navdown_is']) { echo "checked"; }?>>
                                    </div>
                                     <div class="layui-input-inline" style="margin-top: 25px;"></div>
                                </div>
                                
                                    <div class="layui-inline">
                                    <div class="layui-input-inline">
                                        <label class="layui-form-label" style="padding-right: 5px;">跳转链接</label>
                                    </div>
                                    <div class="layui-input-inline">
                                        <input type="text" class="layui-input upload-input" value="<?php echo $config['overall']['navdownlink'];?>" name="navdownlink">
                                    </div>
                                     <div class="layui-input-inline"></div>
                                    <div class="layui-input-inline" style="margin-top: 25px;"></div>
                                </div>
                                
                                 <div class="layui-inline">
                                    <div class="layui-input-inline">
                                        <label class="layui-form-label" style="padding-right: 5px;">标题</label>
                                    </div>
                                    <div class="layui-input-inline">
                                        <input type="text" class="layui-input upload-input" value="<?php echo $config['overall']['navdowntxt'];?>" name="navdowntxt">
                                    </div>
                                     <div class="layui-input-inline"></div>
                                    <div class="layui-input-inline" style="margin-top: 25px;"></div>
                                </div>
                               
                               
                               


                            </div>
                        </div>
                        <div class="layui-form-item" style="text-align: center;">
                            <button type="submit" class="layui-btn layui-btn-normal">确认保存</button>
                            <a href="/" target="_back" class="layui-btn layui-btn-primary">打开前台</a>
                        </div>
                        </form>
                    </fieldset>
                </div>
              
		
			</div>
		</div>
		<?php require('footer.php'); ?>
	</body>
</html>

