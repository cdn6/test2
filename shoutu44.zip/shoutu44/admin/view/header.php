<meta name="renderer" content="webkit">
<meta name="referrer" content="origin-when-cross-origin">
<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1"/>
<link rel="shortcut icon" href="static/img/favicon.ico" >
<link href="static/swiper.min.css" rel="stylesheet" type="text/css" />
<link href="static/layui/css/layui.css" rel="stylesheet" type="text/css" />
<link href="static/style.css" rel="stylesheet" type="text/css" />
<script src="static/jquery.min.js"></script>
<script src="static/drag-arrange.js"></script>
<script src="static/layui/layui.js" type="text/javascript" charset="utf-8"></script>
<script src="static/cms.js"></script>
<script src="static/swiper.min.js" type="text/javascript" charset="utf-8"></script>
<?php config_id($config,$info);?>
