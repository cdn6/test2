<div class="tzt-header">
    <div style="float: right;text-align: right; ">
       
    </div>
    <h3>
        <img src="images/logo2.png" />
    </h3>
    <div class="header-menu">
        <a href="javascript:;" data-url="?url=index&manage=backup" data-msg="当前操作将备份您的所有设置，请确保主题目录有可写权限" class="layui-btn layui-btn-sm layui-btn-normal layer-confirm"><svg width="24" height="24" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="6" y="6" width="36" height="36" rx="3" stroke="#333" stroke-width="4" stroke-linejoin="round"/><path d="M6 17H42" stroke="#333" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path d="M17 42V17" stroke="#333" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg> 备份</a>
        
        <a href="javascript:;" data-url="?url=index&manage=resume" data-msg="当前操作将恢复为您备份过的设置，请确保已经操作过备份设置<br>操作不可撤销，确认操作吗？" class="layui-btn layui-btn-sm layui-btn-normal layer-confirm"><svg width="24" height="24" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 8.25564L24.0086 3L42 8.25564V19.0337C42 30.3622 34.7502 40.4194 24.0026 44.0005C13.2521 40.4195 6 30.36 6 19.0287V8.25564Z" fill="none" stroke="#333" stroke-width="4" stroke-linejoin="round"/><path d="M23.9497 14.9497V30.9497" stroke="#333" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path d="M15.9497 22.9497H31.9497" stroke="#333" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg> 恢复</a>

        <a href="javascript:;" data-url="?url=index&manage=resetting" data-msg="当前操作将清空您主题的所有设置，并还原至初始状态<br>操作不可撤销，确认操作吗？" class="layui-btn layui-btn-sm layui-btn-normal layer-confirm"><svg width="24" height="24" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M42 8V24" stroke="#333" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 24L6 40" stroke="#333" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path d="M42 24C42 14.0589 33.9411 6 24 6C18.9145 6 14.3216 8.10896 11.0481 11.5M6 24C6 33.9411 14.0589 42 24 42C28.8556 42 33.2622 40.0774 36.5 36.9519" stroke="#333" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg> 重置</a>

        <a target="_back" href="/" class="layui-btn layui-btn-sm layui-btn-normal"><svg width="24" height="24" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M44 44V20L24 4L4 20L4 44H16V26H32V44H44Z" fill="none" stroke="#333" stroke-width="4" stroke-linejoin="round"/><path d="M24 44V34" stroke="#333" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg> 首页</a>
    </div>

</div>