var stui = {
	'browser': {
		url: document.URL,
		domain: document.domain,
		title: document.title,
		language: (navigator.browserLanguage || navigator.language).toLowerCase(),
		canvas: function() {
			return !!document.createElement("canvas").getContext
		}(),
		useragent: function() {
			var a = navigator.userAgent;
			return {
				mobile: !! a.match(/AppleWebKit.*Mobile.*/),
				ios: !! a.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/),
				android: -1 < a.indexOf("Android") || -1 < a.indexOf("Linux"),
				iPhone: -1 < a.indexOf("iPhone") || -1 < a.indexOf("Mac"),
				iPad: -1 < a.indexOf("iPad"),
				trident: -1 < a.indexOf("Trident"),
				presto: -1 < a.indexOf("Presto"),
				webKit: -1 < a.indexOf("AppleWebKit"),
				gecko: -1 < a.indexOf("Gecko") && -1 == a.indexOf("KHTML"),
				weixin: -1 < a.indexOf("MicroMessenger")
			}
		}()
	},
	'mobile': {
		'popup': function() {
			$popblock = $(".popup");
			$(".open-popup").click(function() {
				$popblock.addClass("popup-visible");
				$("body").append('<div class="mask"></div>');
				$(".close-popup").click(function() {
					$popblock.removeClass("popup-visible");
					$(".mask").remove();
					$("body").removeClass("modal-open")
				});
				$(".mask").click(function() {
					$popblock.removeClass("popup-visible");
					$(this).remove();
					$("body").removeClass("modal-open")
				})
			})
		}
	},
	'images': {
		'lazyload': function() {
			$(".lazyload").lazyload({
					effect: "fadeIn",
					threshold: 500,
					failurelimit: 15,
					skip_invisible: false
				})
		}
	}
};
$(document).ready(function() {
	if(stui.browser.useragent.mobile){
		stui.mobile.popup();
	}
	stui.images.lazyload();

});

function copyPageUrl() {
  // 获取当前页面的URL
  const pageUrl = window.location.href;
  
  // 创建一个临时的textarea元素来辅助复制
  const textarea = document.createElement('textarea');
  textarea.value = pageUrl;
  textarea.style.position = 'fixed';  // 防止页面滚动
  document.body.appendChild(textarea);
  textarea.select();
  
  try {
    // 执行复制命令
    const successful = document.execCommand('copy');
    if (successful) {
      showTooltip('链接已复制到剪贴板!');
    } else {
      showTooltip('复制失败，请手动复制链接');
    }
  } catch (err) {
    console.error('复制失败:', err);
    showTooltip('复制失败，请手动复制链接');
  }
  
  // 移除临时元素
  document.body.removeChild(textarea);
}

function showTooltip(message) {
  // 创建或获取提示元素
  let tooltip = document.querySelector('.copy-tooltip');
  
  if (!tooltip) {
    tooltip = document.createElement('div');
    tooltip.className = 'copy-tooltip';
    document.body.appendChild(tooltip);
  }
  
  // 设置提示内容和样式
  tooltip.textContent = message;
  tooltip.style.position = 'fixed';
  tooltip.style.top = '50%';
  tooltip.style.left = '50%';
  tooltip.style.transform = 'translate(-50%, -50%)';
  tooltip.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
  tooltip.style.color = '#fff';
  tooltip.style.padding = '12px 24px';
  tooltip.style.borderRadius = '6px';
  tooltip.style.zIndex = '9999';
  tooltip.style.fontSize = '16px';
  tooltip.style.animation = 'fadeInOut 2.5s forwards';
  tooltip.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
  
  // 添加淡入淡出动画
  const style = document.createElement('style');
  style.textContent = `
    @keyframes fadeInOut {
      0% { opacity: 0; transform: translate(-50%, -50%) scale(0.9); }
      10% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
      90% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
      100% { opacity: 0; transform: translate(-50%, -50%) scale(0.9); }
    }
  `;
  document.head.appendChild(style);
  
  // 动画结束后移除元素
  tooltip.addEventListener('animationend', () => {
    tooltip.remove();
    style.remove();
  });
}