$(function () {
  $(".header-right .search-button").click(function () {
    $(".search-box").toggleClass("active hidden-xs hidden-sm");
  });
  $(".search-close").click(function () {
    $(".search-box").removeClass("active").addClass("hidden-xs hidden-sm");
  });
  $(".skin-switch a").click(function () {
    if (localStorage.theme == 1) {
      localStorage.theme = 0;
    } else {
      localStorage.theme = 1;
    }
    $("html").attr("data-theme", localStorage.theme);
  });
});
