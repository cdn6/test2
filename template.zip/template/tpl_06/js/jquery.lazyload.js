(function($){
    $.fn.lazyload = function(options) {
        var settings = {
            threshold       : 0,
            failure_limit   : 0,
            event           : "scroll",
            effect         : "show",
            container       : window,
            data_attribute : "original",
            skip_invisible : true
        };

        if (options) {
            if (undefined !== options.failurelimit) {
                options.failure_limit = options.failurelimit;
                delete options.failurelimit;
            }
            $.extend(settings, options);
        }

        var elements = this;
        
        function update() {
            var counter = 0;
            
            elements.each(function() {
                var $this = $(this);
                if (settings.skip_invisible && !$this.is(":visible")) return;
                
                if ($.abovethetop(this, settings) ||
                    $.leftofbegin(this, settings)) {
                    /* Nothing. */
                } else if (!$.belowthefold(this, settings) &&
                           !$.rightoffold(this, settings)) {
                    $this.trigger("appear");
                } else {
                    if (++counter > settings.failure_limit) {
                        return false;
                    }
                }
            });
            
            var still_loading = $.grep(elements, function(element) {
                return !element.loaded;
            });
            
            elements = $(still_loading);
        }

        if (0 === settings.event.indexOf("scroll")) {
            $(settings.container).bind(settings.event, function() {
                return update();
            });
        }

        this.each(function() {
            var self = this;
            self.loaded = false;
            
            $(self).one("appear", function() {
                if (!this.loaded) {
                    $("<img />")
                        .bind("load", function() {
                            $(self)
                                .hide()
                                .attr("src", $(self).attr("data-" + settings.data_attribute))
                                [settings.effect](settings.effectspeed);
                            self.loaded = true;
                        })
                        .attr("src", $(self).attr("data-" + settings.data_attribute));
                }
            });
            
            if (0 !== settings.event.indexOf("scroll")) {
                $(self).bind(settings.event, function() {
                    if (!self.loaded) {
                        $(self).trigger("appear");
                    }
                });
            }
        });

        $(settings.container).trigger(settings.event);
        update();
        return this;
    };

    $.belowthefold = function(element, settings) {
        if (settings.container === undefined || settings.container === window) {
            var fold = $(window).height() + $(window).scrollTop();
        } else {
            var fold = $(settings.container).offset().top + $(settings.container).height();
        }
        return fold <= $(element).offset().top - settings.threshold;
    };

    $.rightoffold = function(element, settings) {
        if (settings.container === undefined || settings.container === window) {
            var fold = $(window).width() + $(window).scrollLeft();
        } else {
            var fold = $(settings.container).offset().left + $(settings.container).width();
        }
        return fold <= $(element).offset().left - settings.threshold;
    };

    $.abovethetop = function(element, settings) {
        if (settings.container === undefined || settings.container === window) {
            var fold = $(window).scrollTop();
        } else {
            var fold = $(settings.container).offset().top;
        }
        return fold >= $(element).offset().top + settings.threshold + $(element).height();
    };

    $.leftofbegin = function(element, settings) {
        if (settings.container === undefined || settings.container === window) {
            var fold = $(window).scrollLeft();
        } else {
            var fold = $(settings.container).offset().left;
        }
        return fold >= $(element).offset().left + settings.threshold + $(element).width();
    };

    $.extend($.expr[":"], {
        "below-the-fold": function(a) { return $.belowthefold(a, {threshold : 0, container: window}); },
        "above-the-fold": function(a) { return !$.belowthefold(a, {threshold : 0, container: window}); },
        "right-of-fold": function(a) { return $.rightoffold(a, {threshold : 0, container: window}); },
        "left-of-fold": function(a) { return !$.rightoffold(a, {threshold : 0, container: window}); }
    });
})(jQuery);