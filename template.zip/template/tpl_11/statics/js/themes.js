$(function() {
    // ============== 全局变量和函数 ==============
    window.isReversed = false; // 倒序状态
    
    // Tab切换
    window.switchSource = function(sid) {
        $('.hd-item').removeClass('on').filter(`[data-sid="${sid}"]`).addClass('on');
        $('.list').hide().filter(`[data-sid="${sid}"]`).show();
    };
    
    // 倒序功能
    window.toggleSort = function() {
        window.isReversed = !window.isReversed;
        $('.sort-btn').text(window.isReversed ? '正序' : '倒序');       
        $('.list').each(function() {
            const $list = $(this);
            const items = $list.find('a').get();           
            if (window.isReversed) {
                items.reverse();
            }
            $list.empty().append(items);
        });
    };
    
    // ============== 事件绑定 ==============
    // 使用事件委托，兼容动态加载
    $(document)
        .on('click', '.hd-item', function() {
            switchSource($(this).attr('data-sid'));
        })
        .on('click', '.sort-btn', toggleSort)
        .on('click', '.tab-tit-box>a', function() {
            const num = $(this).index();
            $(this).addClass('on').siblings('a').removeClass("on");
            $(this).parents(".gm-meta").next(".gm-box").find(".gm-list").eq(num).show().siblings().hide();
            $(window).trigger("scroll");
        })
        .on('click', '.openall-button', function(e) {
            const $this = $(this);
            const $parentList = $this.parents(".gm-list");
            
            if ($this.attr("data-openall") == "1") {
                $this.attr("data-openall", "0")
                    .find("span").text("展开热搜")
                    .siblings(".fa").attr("class", "fa fa-fw fa-angle-double-down");
                
                $parentList.find(".item").slice(6).hide();
                
                const parentTop = $parentList.next().offset().top;
                $('html,body').animate({scrollTop: parentTop - 250}, 500);
            } else {
                $this.attr("data-openall", "1")
                    .find("span").text("收起热搜")
                    .siblings(".fa").attr("class", "fa fa-fw fa-angle-double-up");
                
                $parentList.find(".item").show();
            }
            $(window).trigger("scroll");
        });

    // 导航菜单和搜索框切换
    const domBtnNav = $('#btn-nav');
    const domPopNav = $('#pop-nav');
    const domBtnSearch = $('#btn-search');
    const domPopSearch = $('#pop-search');
    
    if (domBtnNav.length) {
        domBtnNav.on('click', function() {
            domPopNav.toggleClass('on');
        });
        
        domBtnSearch.on('click', function() {
            domPopSearch.toggleClass('on');
        });
        
        $('body').on('click', function(e) {
            if ($(e.target).closest('#btn-nav').length < 1) {
                domPopNav.removeClass('on');
            }
        });
    }

    // 搜索框验证
    $("form").submit(function() {
        const kw = $.trim($(this).find("input").val());
        if (!kw) {
            alert("输入影片名称");
            return false;
        } else if (kw.length < 2) {
            alert("请输入2字以上影片名称");
            return false;
        }
    });

    // ==================== 幻灯片功能 ====================
    const slideWrapper = $('#slideWrapper');
    if (slideWrapper.length && slideWrapper.find('.slide-item').length > 0) {
        const dots = $('.slide-dot');
        const prevBtn = $('.slide-prev');
        const nextBtn = $('.slide-next');
        const slideItems = $('.slide-item');
        const slideCount = slideItems.length;
        let currentIndex = 0;
        let interval;
        
        prevBtn.css('display', 'flex');
        nextBtn.css('display', 'flex');
        
        function initSlider() {
            if (dots.length > 0) {
                dots.eq(0).addClass('active');
            }
            startAutoSlide();
        }
        
        function startAutoSlide() {
            interval = setInterval(() => {
                goToSlide(currentIndex + 1);
            }, 4000);
        }
        
        function goToSlide(index) {
            if (index < 0) {
                index = slideCount - 1;
            } else if (index >= slideCount) {
                index = 0;
            }
            
            currentIndex = index;
            slideWrapper.css('transform', `translateX(-${currentIndex * 20}%)`);
            
            dots.each(function(i) {
                $(this).toggleClass('active', i === currentIndex);
            });
        }
        
        dots.on('click', function() {
            clearInterval(interval);
            goToSlide($(this).index());
            startAutoSlide();
        });
        
        prevBtn.on('click', function() {
            clearInterval(interval);
            goToSlide(currentIndex - 1);
            startAutoSlide();
        });
        
        nextBtn.on('click', function() {
            clearInterval(interval);
            goToSlide(currentIndex + 1);
            startAutoSlide();
        });
        
        slideWrapper.parent().on({
            mouseenter: function() {
                clearInterval(interval);
            },
            mouseleave: function() {
                startAutoSlide();
            }
        });
        
        initSlider();
    } else {
        $('#slideIndicator').hide();
    }

    // ==================== 返回顶部功能 ====================
    const backToTopButton = $('#backToTop');
    
    // 监听滚动事件
    $(window).on('scroll', function() {
        if ($(window).scrollTop() > 500) {
            backToTopButton.addClass('show');
        } else {
            backToTopButton.removeClass('show');
        }
    });
    
    // 点击返回顶部
    backToTopButton.on('click', function() {
        $('html, body').animate({
            scrollTop: 0
        }, 'smooth');
    });

    // ==================== 初始化执行 ====================
    // 图片懒加载
    $('img').lazyload();
    
    // 其他初始化代码...
    $(window).trigger("scroll");
});

// ==================== 分享功能 ====================
function copyPageUrl() {
    // 获取当前页面的URL
    const pageUrl = window.location.href;
    
    // 创建一个临时的textarea元素来辅助复制
    const textarea = document.createElement('textarea');
    textarea.value = pageUrl;
    textarea.style.position = 'fixed';  // 防止页面滚动
    document.body.appendChild(textarea);
    textarea.select();
    
    try {
        // 执行复制命令
        const successful = document.execCommand('copy');
        if (successful) {
            showTooltip('链接已复制到剪贴板!');
        } else {
            showTooltip('复制失败，请手动复制链接');
        }
    } catch (err) {
        console.error('复制失败:', err);
        showTooltip('复制失败，请手动复制链接');
    }
    
    // 移除临时元素
    document.body.removeChild(textarea);
}

function showTooltip(message) {
    // 创建或获取提示元素
    let tooltip = document.querySelector('.copy-tooltip');
    
    if (!tooltip) {
        tooltip = document.createElement('div');
        tooltip.className = 'copy-tooltip';
        document.body.appendChild(tooltip);
    }
    
    // 设置提示内容和样式
    tooltip.textContent = message;
    tooltip.style.position = 'fixed';
    tooltip.style.top = '50%';
    tooltip.style.left = '50%';
    tooltip.style.transform = 'translate(-50%, -50%)';
    tooltip.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
    tooltip.style.color = '#fff';
    tooltip.style.padding = '12px 24px';
    tooltip.style.borderRadius = '6px';
    tooltip.style.zIndex = '9999';
    tooltip.style.fontSize = '16px';
    tooltip.style.animation = 'fadeInOut 2.5s forwards';
    tooltip.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
    
    // 添加淡入淡出动画
    const style = document.createElement('style');
    style.textContent = `
        @keyframes fadeInOut {
            0% { opacity: 0; transform: translate(-50%, -50%) scale(0.9); }
            10% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
            90% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
            100% { opacity: 0; transform: translate(-50%, -50%) scale(0.9); }
        }
    `;
    document.head.appendChild(style);
    
    // 动画结束后移除元素
    tooltip.addEventListener('animationend', () => {
        tooltip.remove();
        style.remove();
    });
}