$(function() {
    // ============== 全局变量和函数 ==============
    window.isReversed = false; // 倒序状态
    
    // Tab切换
    window.switchSource = function(sid) {
        $('.hd-item').removeClass('on').filter(`[data-sid="${sid}"]`).addClass('on');
        $('.list').hide().filter(`[data-sid="${sid}"]`).show();
    };
    
    // 倒序功能
    window.toggleSort = function() {
        window.isReversed = !window.isReversed;
        $('.sort-btn').text(window.isReversed ? '正序' : '倒序');
        
        $('.list:visible').each(function() {
            const items = $(this).find('a').get();
            items.reverse().forEach(item => {
                $(this).append(item);
            });
        });
    };
    
    // ============== 事件绑定 ==============
    // 使用事件委托，兼容动态加载
    $(document)
        .on('click', '.hd-item', function() {
            switchSource($(this).attr('data-sid'));
        })
        .on('click', '.sort-btn', toggleSort);

    // ==================== 初始化函数 ====================
    // 初始化Tab滚动容器宽度
    function initTabScroll() {
        const $hdScroll = $('.hd-scroll');
        if ($hdScroll[0].scrollWidth > $hdScroll[0].clientWidth) {
            $('.hd').addClass('scrollable');
        }
    }

    // ==================== 事件绑定 ====================
    // 使用事件委托绑定动态元素
    $(document)
        .on('click', '.hd-item', function() {
            switchSource($(this).attr('data-sid'));
        })
        .on('click', '.sort-btn', toggleSort)
        .on('click', '.tab-tit-box>a', function() {
            const num = $(this).index();
            $(this).addClass('on').siblings('a').removeClass("on");
            $(this).parents(".gm-meta").next(".gm-box").find(".gm-list").eq(num).show().siblings().hide();
            $(window).trigger("scroll");
        })
        .on('click', '.openall-button', function(e) {
            const $this = $(this);
            const $parentList = $this.parents(".gm-list");
            
            if ($this.attr("data-openall") == "1") {
                $this.attr("data-openall", "0")
                    .find("span").text("展开热搜")
                    .siblings(".fa").attr("class", "fa fa-fw fa-angle-double-down");
                
                $parentList.find(".item").slice(6).hide();
                
                const parentTop = $parentList.next().offset().top;
                $('html,body').animate({scrollTop: parentTop - 250}, 500);
            } else {
                $this.attr("data-openall", "1")
                    .find("span").text("收起热搜")
                    .siblings(".fa").attr("class", "fa fa-fw fa-angle-double-up");
                
                $parentList.find(".item").show();
            }
            $(window).trigger("scroll");
        });

    // 导航菜单和搜索框切换
    const domBtnNav = $('#btn-nav');
    const domPopNav = $('#pop-nav');
    const domBtnSearch = $('#btn-search');
    const domPopSearch = $('#pop-search');
    
    if (domBtnNav.length) {
        domBtnNav.on('click', function() {
            domPopNav.toggleClass('on');
        });
        
        domBtnSearch.on('click', function() {
            domPopSearch.toggleClass('on');
        });
        
        $('body').on('click', function(e) {
            if ($(e.target).closest('#btn-nav').length < 1) {
                domPopNav.removeClass('on');
            }
        });
    }

    // 搜索框验证
    $("form").submit(function() {
        const kw = $.trim($(this).find("input").val());
        if (!kw) {
            alert("输入影片名称");
            return false;
        } else if (kw.length < 2) {
            alert("请输入2字以上影片名称");
            return false;
        }
    });

    // ==================== 初始化执行 ====================
    // 图片懒加载
    $('img').lazyload();
    
    // 初始化Tab滚动检测
    initTabScroll();
    
    // 其他初始化代码...
    $(window).trigger("scroll");
});