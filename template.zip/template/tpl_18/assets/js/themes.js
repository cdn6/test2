/* 全局js */
var eWave = {
  'Encrypt': {
    base64EncodeChars: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
    base64DecodeChars: [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,62,-1,-1,-1,63,52,53,54,55,56,57,58,59,60,61,-1,-1,-1,-1,-1,-1,-1,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,-1,-1,-1,-1,-1,-1,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,-1,-1,-1,-1,-1],
    base64encode: function (str) {
      var out = "", i = 0, len = str.length; var c1, c2, c3;
      while (i < len) {
        c1 = str.charCodeAt(i++) & 0xff;
        if (i == len) { out += this.base64EncodeChars.charAt(c1 >> 2); out += this.base64EncodeChars.charAt((c1 & 0x3) << 4); out += "=="; break; }
        c2 = str.charCodeAt(i++);
        if (i == len) { out += this.base64EncodeChars.charAt(c1 >> 2); out += this.base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4)); out += this.base64EncodeChars.charAt((c2 & 0xF) << 2); out += "="; break; }
        c3 = str.charCodeAt(i++);
        out += this.base64EncodeChars.charAt(c1 >> 2);
        out += this.base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4));
        out += this.base64EncodeChars.charAt(((c2 & 0xF) << 2) | ((c3 & 0xC0) >> 6));
        out += this.base64EncodeChars.charAt(c3 & 0x3F);
      }
      return out;
    },
    base64decode: function (str) {
      var c1, c2, c3, c4; var i = 0, len = str.length, out = "";
      while (i < len) {
        do { c1 = this.base64DecodeChars[str.charCodeAt(i++) & 0xff]; } while (i < len && c1 == -1); if (c1 == -1) break;
        do { c2 = this.base64DecodeChars[str.charCodeAt(i++) & 0xff]; } while (i < len && c2 == -1); if (c2 == -1) break;
        out += String.fromCharCode((c1 << 2) | ((c2 & 0x30) >> 4));
        do { c3 = str.charCodeAt(i++) & 0xff; if (c3 == 61) return out; c3 = this.base64DecodeChars[c3]; } while (i < len && c3 == -1); if (c3 == -1) break;
        out += String.fromCharCode(((c2 & 0xF) << 4) | ((c3 & 0x3C) >> 2));
        do { c4 = str.charCodeAt(i++) & 0xff; if (c4 == 61) return out; c4 = this.base64DecodeChars[c4]; } while (i < len && c4 == -1); if (c4 == -1) break;
        out += String.fromCharCode(((c3 & 0x03) << 6) | c4);
      }
      return out;
    },
    utf16to8: function (str) {
      var out = "", i = 0, len = str.length, c, char2, char3;
      for (; i < len; i++) { c = str.charCodeAt(i); if ((c >= 0x0001) && (c <= 0x007F)) { out += str.charAt(i); } else if (c > 0x07FF) { out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F)); out += String.fromCharCode(0x80 | ((c >> 6) & 0x3F)); out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F)); } else { out += String.fromCharCode(0xC0 | ((c >> 6) & 0x1F)); out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F)); } }
      return out;
    },
    utf8to16: function (str) {
      var out = "", i = 0, len = str.length, c, char2, char3;
      while (i < len) { c = str.charCodeAt(i++); switch (c >> 4) { case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7: out += str.charAt(i - 1); break; case 12: case 13: char2 = str.charCodeAt(i++); out += String.fromCharCode(((c & 0x1F) << 6) | (char2 & 0x3F)); break; case 14: char2 = str.charCodeAt(i++); char3 = str.charCodeAt(i++); out += String.fromCharCode(((c & 0x0F) << 12) | ((char2 & 0x3F) << 6) | ((char3 & 0x3F) << 0)); break; } }
      return out;
    },
    encodeUrl: function (url) {
      return this.base64encode(this.utf16to8(url));
    },
    decodeUrl: function (encoded) {
      return this.utf8to16(this.base64decode(encoded));
    }
  },
  'Copy': {
    'Init': function () {
      $(".ewave-copy-link").each(function () {
        var $that = $(this);
        var links = $that.attr("data-url");
        eWave.Copy.Set(this, links);
      });
      $(".ewave-copy").each(function () {
        var $that = $(this);
        var text = $that.attr("data-text");
        eWave.Copy.Set(this, text);
      });
      $(".ewave-copy-html").each(function () {
        var $that = $(this);
        var html = $that.parent().find(".content").html();
        eWave.Copy.Set(this, html);
      });
    },
    'Set': function (id, content) {
      var clipboard = new ClipboardJS(id, {
        text: function () {
          return content;
        }
      });
      clipboard.on('success', function (e) {
        layer.msg('复制网址成功，去粘贴分享吧！');
      });
      clipboard.on("error", function (e) {
        eWave.Layer.Error('复制失败，请手动复制');
      });
    }
  },
  'Fav': function (u, s) {
    try {
      window.external.addFavorite(u, s);
    } catch (e) {
      try {
        window.sidebar.addPanel(s, u, "");
      } catch (e) {
        eWave.Layer.Error('加入收藏出错，请使用键盘Ctrl+D进行添加');
      }
    }
  },
  'Ajax': function (url, type, dataType, data, sfun, efun, bfun, cfun) {
    type = type || 'get';
    dataType = dataType || 'json';
    data = data || '';
    efun = efun || '';
    bfun = bfun || '';
    cfun = cfun || '';
    $.ajax({
      url: url,
      type: type,
      dataType: dataType,
      data: data,
      timeout: 5000,
      beforeSend: function () {
        if (bfun) bfun();
      },
      error: function (XHR, textStatus, errorThrown) {
        if (efun) efun(XHR, textStatus, errorThrown);
      },
      success: function (data) {
        sfun(data);
      },
      complete: function (XHR, TS) {
        if (cfun) cfun(XHR, TS);
      }
    })
  },
  'Layer': {
    'Error': function (text, time) {
      time = time || '';
      layer.msg(text, {
        time: time ? time : 1500,
        anim: 6,
      });
    },
    'Img': function (title, src, text) {
      layer.open({
        type: 1,
        title: title,
        skin: 'layui-layer-rim',
        content: '<p><img src="' + src + '" width="240" /></p><p class="text-center">' + text + '</p>'
      });
    },
    'Html': function (title, html, end_fun) {
      end_fun = end_fun || '';
      layer.open({
        type: 1,
        closeBtn: 2,
        title: title,
        skin: 'layui-layer-rim',
        content: html,
        success: function (layero, index) {
          if (end_fun) end_fun();
        }
      });
    },
    'Div': function (id) {
      layer.open({
        type: 1,
        title: false,
        skin: 'layui-layer-rim',
        content: $(id)
      });
    },
    'Notice': function (name, title, html, day, wide, high) {
      var noticed = MAC.Cookie.Get(name);
      var html = $(html).html();
      if (!noticed) {
        layer.open({
          type: 1,
          title: title,
          skin: 'layui-layer-rim',
          content: html,
          area: [wide + 'px', high + 'px'],
          cancel: function () {
            MAC.Cookie.Set(name, 1, day);
          }
        });
      }
    }
  },
  'Image': {
    'Init': function () {
      eWave.Image.Lazyload.Show();
      eWave.Image.Verify.Init();
      eWave.Image.Qrcode.Init();
    },
    'Lazyload': {
      'Show': function () {
        $(".lazyload").lazyload({
          threshold: 200,
          failurelimit: 50,
          skip_invisible: false
        });
      },
      'Box': function ($id) {
        $id.find(".lazyload").lazyload({
          threshold: 200,
          failurelimit: 50,
          skip_invisible: false
        });
      }
    },
    'Verify': {
      'Init': function () {
        $("body").on('click', '.ewave-verify-img', function () {
          eWave.Image.Verify.Refresh($(this));
        });
      },
      'Refresh': function (obj) {
        obj.attr('src', maccms.path + '/index.php/verify/index.html?r=' + Math.random());
      }
    },
    'Qrcode': {
      'Init': function () {

      }
    },
  },
  'Swiper': {
    'Init': function () {
      // 首页幻灯初始化（.mySwiper） - 放在最前，避免因无 .ewave-swiper 提前返回
      if ($('.mySwiper').length) {
        try {
          var homeSwiper = new Swiper('.mySwiper', {
            loop: true,
            autoplay: { delay: 5000, disableOnInteraction: false },
            pagination: { el: '.swiper-pagination', clickable: true },
            navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
            slidesPerView: 1,
            spaceBetween: 10,
            on: {
              init: function () {
                $('.mySwiper .lazy').each(function () {
                  var $img = $(this);
                  if ($img.attr('data-original')) { $img.attr('src', $img.attr('data-original')); $img.removeClass('lazy'); }
                });
              },
              slideChange: function () {
                var currentIndex = this.activeIndex;
                var slides = this.slides; if (!slides || !slides.length) return;
                $(slides[currentIndex]).find('.lazy').each(function () { var $img = $(this); if ($img.attr('data-original')) { $img.attr('src', $img.attr('data-original')); $img.removeClass('lazy'); } });
                var prevIndex = currentIndex - 1; if (prevIndex < 0) prevIndex = slides.length - 1;
                $(slides[prevIndex]).find('.lazy').each(function () { var $img = $(this); if ($img.attr('data-original')) { $img.attr('src', $img.attr('data-original')); $img.removeClass('lazy'); } });
                var nextIndex = currentIndex + 1; if (nextIndex >= slides.length) nextIndex = 0;
                $(slides[nextIndex]).find('.lazy').each(function () { var $img = $(this); if ($img.attr('data-original')) { $img.attr('src', $img.attr('data-original')); $img.removeClass('lazy'); } });
              }
            }
          });
        } catch (e) {}
      }
      if ($('.ewave-swiper').length == 0) {
        return false;
      }
      if ($('.ewave-swiper-nav').length) {
        var navSwiper = new Array();
        $('.ewave-swiper-nav').each(function (index) {
          var $that = $(this);
          var $index = index;
          if ($that.find(".swiper-slide").length) {
            navSwiper.push(new Swiper($that.get(0), {
              direction: $that.attr("data-direction") == 'vertical' ? "vertical" : "horizontal",
              freeMode: true,
              slidesPerView: 'auto',
              roundLengths: true,
              slideToClickedSlide: $that.attr("data-slidetoclickedslide") == 'true' ? true : false,
              mousewheel: $that.attr("data-mousewheel") == 'true' ? {
                releaseOnEdges: true,
              } : false,
              lazy: {
                loadPrevNext: true,
                loadPrevNextAmount: 8,
              },
              navigation: {
                nextEl: $that.attr("data-next") || $that.find('.swiper-button-next').get(0),
                prevEl: $that.attr("data-prev") || $that.find('.swiper-button-prev').get(0),
              },
              on: {
                'init': function () {
                  if (this.$el.find(".active").length) {
                    this.slideTo(this.$el.find(".active").index() - 2);
                  }
                },
                'slideChangeTransitionEnd': function () {
                  if (this.$el.find(".active").length && $that.attr("data-slidetoclickedslide") != 'true') {
                    this.translateTo(this.translate - $(this.slides).eq(this.$el.find(".active").index() - 2).outerWidth(true) / 2, 300, this.off('slideChangeTransitionEnd'), true);
                  }
                }
              }
            }));
          }
        });
        eWave.Swiper.Change(navSwiper);
      }
      if ($('.ewave-swiper-image').length) {
        var imageSwiper = new Array();
        $('.ewave-swiper-image').each(function () {
          var $that = $(this);
          if ($that.find(".swiper-slide").length) {
            imageSwiper.push(new Swiper($that.get(0), {
              initialSlide: $that.find(".active").index(),
              lazy: {
                elementClass: $that.attr("data-lazy-class") || 'swiper-lazy',
                loadPrevNext: true,
                loadPrevNextAmount: 8,
              },
              loop: $that.attr("data-loop") == 'false' ? false : true,
              centeredSlides: $that.attr("data-center") == 'false' ? false : true,
              centeredSlidesBounds: true,
              autoplay: $that.attr("data-autoplay") == 'false' ? false : {
                disableOnInteraction: false,
                pauseOnMouseEnter: true,
              },
              effect: $that.attr("data-effect") || 'slide',
              fadeEffect: {
                crossFade: true,
              },
              slidesPerView: 'auto',
              pagination: {
                el: $that.attr("data-pagination") || $that.find('.swiper-pagination').get(0),
                clickable: true,
                bulletClass: $that.attr("data-pagination-class") || 'swiper-pagination-bullet',
                bulletActiveClass: $that.attr("data-pagination-active-class") || 'swiper-pagination-bullet-active',
                renderBullet: function (index, className) {
                  if ($that.find(".swiper-pagination-html").length) {
                    return '<span class="' + className + '">' + $(this.slides).eq(index).find(".swiper-pagination-html").html() + '</span>';
                  } else {
                    return '<span class="' + className + '"></span>';
                  }
                },
              },
              navigation: {
                nextEl: $that.attr("data-next") || $that.find('.swiper-button-next').get(0),
                prevEl: $that.attr("data-prev") || $that.find('.swiper-button-prev').get(0),
              },
            }));
          }
        });
      }
      // 首页幻灯初始化（.mySwiper）
      if ($('.mySwiper').length) {
        try {
          var homeSwiper = new Swiper('.mySwiper', {
            loop: true,
            autoplay: {
              delay: 5000,
              disableOnInteraction: false,
            },
            pagination: {
              el: '.swiper-pagination',
              clickable: true,
            },
            navigation: {
              nextEl: '.swiper-button-next',
              prevEl: '.swiper-button-prev',
            },
            slidesPerView: 1,
            spaceBetween: 10,
            on: {
              init: function () {
                $('.mySwiper .lazy').each(function () {
                  var $img = $(this);
                  if ($img.attr('data-original')) {
                    $img.attr('src', $img.attr('data-original'));
                    $img.removeClass('lazy');
                  }
                });
              },
              slideChange: function () {
                var currentIndex = this.activeIndex;
                var slides = this.slides;
                if (!slides || !slides.length) return;
                $(slides[currentIndex]).find('.lazy').each(function () {
                  var $img = $(this);
                  if ($img.attr('data-original')) {
                    $img.attr('src', $img.attr('data-original'));
                    $img.removeClass('lazy');
                  }
                });
                var prevIndex = currentIndex - 1;
                if (prevIndex < 0) prevIndex = slides.length - 1;
                $(slides[prevIndex]).find('.lazy').each(function () {
                  var $img = $(this);
                  if ($img.attr('data-original')) {
                    $img.attr('src', $img.attr('data-original'));
                    $img.removeClass('lazy');
                  }
                });
                var nextIndex = currentIndex + 1;
                if (nextIndex >= slides.length) nextIndex = 0;
                $(slides[nextIndex]).find('.lazy').each(function () {
                  var $img = $(this);
                  if ($img.attr('data-original')) {
                    $img.attr('src', $img.attr('data-original'));
                    $img.removeClass('lazy');
                  }
                });
              }
            }
          });
        } catch (e) {
          // 如果未加载 Swiper 则忽略
        }
      }
    },
    'Change': function (obj) {

    }
  },
  'Playlist': {
    'InitSort': function () {
      // 详情页/播放页 剧集排序按钮
      var btn = document.querySelector('.playlist-sort-toggle');
      if (!btn) return;
      function reverseList(ul) {
        var items = Array.prototype.slice.call(ul.children);
        items.reverse().forEach(function (li) { ul.appendChild(li); });
      }
      function setOrder(order) {
        var lists = document.querySelectorAll('.playlist-box .ewave-tab-content');
        lists.forEach(function (ul) { reverseList(ul); });
        btn.setAttribute('data-order', order);
        var iconClass = order === 'asc' ? 'fa-sort-amount-down' : 'fa-sort-amount-up';
        var label = order === 'asc' ? '倒序' : '正序';
        btn.innerHTML = '<i class="fa ' + iconClass + '"></i>&nbsp;' + label;
      }
      btn.addEventListener('click', function () {
        var current = btn.getAttribute('data-order') || 'asc';
        var next = current === 'asc' ? 'desc' : 'asc';
        setOrder(next);
      });
    }
  },
  'Star': {
    'Static': 0, //判断页面是否为静态
    'Obj': '.ewave-star',
    'Init': function () {
      if ($(eWave.Star.Obj).length == 0) {
        return;
      }
      if (eWave.Star.Static == 0) {
        eWave.Star.View();
      } else {
        eWave.Star.Get();
      }
    },
    'Get': function () {
      eWave.Ajax(maccms.path + '/index.php/ajax/score?mid=' + $(eWave.Star.Obj).attr('data-mid') + '&id=' + $(eWave.Star.Obj).attr('data-id'), 'get', 'json', '', function (e) {
        $(eWave.Star.Obj).attr({
          'score': e.data.score,
          'data-star': Math.ceil(e.data.score / 2),
          'data-score-num': e.data.score_num
        });
        $(".ewave-star-num").text(e.data.score);
        $(".ewave-star-count").text(e.data.score_num);
        $(".ewave-star-circle").css({
          'transform': 'rotate(' + 360 * e.data.score / 10 + 'deg)'
        });
        eWave.Star.View();
      });
    },
    'View': function () {
      $(eWave.Star.Obj).raty({
        starType: 'li',
        number: 5,
        numberMax: 5,
        space: false,
        half: false,
        halfShow: true,
        score: function () {
          $(".ewave-star-num").text($(eWave.Star.Obj).attr('score'));
          $(".ewave-star-circle").css({
            'transform': 'rotate(' + 360 * $(eWave.Star.Obj).attr('score') / 10 + 'deg)'
          });
          return $(eWave.Star.Obj).attr('data-star');
        },
        hints: ['很差', '较差', '还行', '推荐', '力荐'],
        starHalf: 'ewave-star-item fa fa-star-half-alt',
        starOff: 'ewave-star-item far fa-star',
        starOn: 'ewave-star-item fa fa-star',
        target: $(".ewave-star-text"),
        targetKeep: $(eWave.Star.Obj).attr('data-score-num') > 0 ? true : false,
        targetText: '暂无',
        click: function (score, evt) {
          eWave.Ajax(maccms.path + '/index.php/ajax/score?mid=' + $(eWave.Star.Obj).attr('data-mid') + '&id=' + $(eWave.Star.Obj).attr('data-id') + '&score=' + (score * 2), 'get', 'json', '', function (r) {
            if (r.code == 1) {
              $(eWave.Star.Obj).attr({
                'score': r.data.score,
                'data-star': Math.ceil(r.data.score / 2),
                'data-score-num': r.data.score_num
              });
              $(".ewave-star-num").text(r.data.score);
              $(".ewave-star-count").text(r.data.score_num);
              $(".ewave-star-circle").css({
                'transform': 'rotate(' + 360 * r.data.score / 10 + 'deg)'
              });
              $(eWave.Star.Obj).raty('set', {
                'score': Math.ceil(r.data.score / 2),
                'targetKeep': $(eWave.Star.Obj).attr('data-score-num') > 0 ? true : false,
              });
              layer.msg('评分成功');
            } else {
              $(eWave.Star.Obj).raty('score', $(eWave.Star.Obj).attr('data-star'));
              layer.msg(r.msg);
            }
          }, function () {
            $(eWave.Star.Obj).raty('score', $(eWave.Star.Obj).attr('data-star'));
            layer.msg('网络异常');
          });
        }
      });
    }
  },
  'Sort': {
    'Init': function () {
      $("body").on("click", ".ewave-sort", function (e) {
        e.preventDefault();
        var $that = $(this);
        var $target = $($that.attr("data-target"));
        $that.find(".fa").toggleClass("fa-sort-amount-asc fa-sort-amount-desc");
        $target.html($target.children().get().reverse());
      });
    },
  },
  'Tab': {
    'Init': function () {
      $("body").on("click", ".ewave-tab", function () {
        var $that = $(this);
        if (!$that.hasClass('active')) {
          $that.addClass('active').siblings(".ewave-tab").removeClass('active');
          $($that.attr("data-target")).fadeIn("fast").siblings(".ewave-tab-content").hide();
          eWave.Image.Lazyload.Box($($that.attr("data-target")));
        }
      });
    },
  },
  'OffCanvas': {
    'Init': function () {
      $("body").on("click", ".ewave-offcanvas", function () {
        var $that = $(this);
        $($that.attr("data-target")).toggleClass("active");
        $(".ewave-offcanvas-modal").toggleClass("active");
        eWave.Image.Lazyload.Box($($that.attr("data-target")));
      });
      $("body").on("click", ".ewave-offcanvas-modal", function () {
        var $that = $(this);
        $(".ewave-offcanvas-content").removeClass("active");
      });
      $("body").on("click", function (e) {
        if ($(e.target).closest(".ewave-offcanvas,.ewave-offcanvas-content").length == 0) {
          $(".ewave-offcanvas-content,.ewave-offcanvas-modal").removeClass("active");
        }
      });
    },
  },
  
  'Search': {
    'Init': function () {
      if (ewave_config.autocomplete == 1) {
        MAC.Suggest.Init('.ewave-wd', 1, '');
        if ($('.mac_wd').length) {
          MAC.Suggest.Init('.mac_wd', 1, '');
        }
      }
      $(".ewave-search-dropdown .ewave-dropdown-box li").click(function () {
        $(".ewave-search-dropdown-text").text($(this).text());
        $(this).parents("form").eq(0).attr("action", $(this).attr("data-action"));
      });
      // 兼容原有 .mac_search 点击触发搜索
      $('body').on('click', '.mac_search', function () {
        var $that = $(this);
        var url = $that.attr('data-href') ? $that.attr('data-href') : (maccms.path + '/index.php/vod/search.html');
        var wd = '';
        if ($('#wd').length) {
          wd = $('#wd').val();
        } else if ($('.mac_wd').length) {
          wd = $('.mac_wd').val();
        }
        location.href = url + '?wd=' + encodeURIComponent(wd || '');
      });

    },
  },
  'UI': {
    'Init': function () {
      eWave.UI.ShrinkBox();
      eWave.UI.MenuCleanup();
      eWave.UI.SearchFormValidate();
      eWave.UI.PrevNextNotice();
    },
    'PrevNextNotice': function () {
      // 使用命名空间只绑定一次，避免重复绑定
      $(document).off('click.ui-prevnext', '.js-prev, .js-next');
      $(document).on('click.ui-prevnext', '.js-prev, .js-next', function (e) {
        var available = $(this).attr('data-available');
        if (available == '0') {
          e.preventDefault();
          if ($(this).hasClass('js-prev')) {
            layer.msg('已经是第一集了');
          } else if ($(this).hasClass('js-next')) {
            layer.msg('没有下一集了');
          }
        }
      });
    },
    'ShrinkBox': function () {
      if ($('.shrink-box').height() <= 75) {
        $('.shrink-box').removeClass('shrinked');
      } else {
        $('.shrink-box').addClass('shrinked');
      }
      $('.shrink-toggle').click(function () {
        $('.shrink-box').removeClass('shrinked');
      });
    },
    'MenuCleanup': function () {
      var menuItems = document.querySelectorAll('.menu-item-has-children[data-type-id="5"]');
      menuItems.forEach(function (menuItem) {
        var subMenu = menuItem.querySelector('.sub-menu');
        if (!subMenu) return;
        var subMenuItems = subMenu.querySelectorAll('li');
        if (subMenuItems.length === 0) {
          menuItem.classList.remove('menu-item-has-children');
          subMenu.remove();
        }
      });
    },
    'SearchFormValidate': function () {
      var searchForm = document.getElementById('searchform');
      var searchInput = document.getElementById('keysss');
      if (searchForm && searchInput) {
        searchForm.addEventListener('submit', function (e) {
          var searchValue = searchInput.value.trim();
          if (searchValue === '') {
            e.preventDefault();
            layer.msg('请输入搜索片名关键词', { time: 2000 });
            searchInput.focus();
            return false;
          }
        });
      }
    }
  },
  'Adaptive': {
    'Init': function () {
      try {
        if (maccms.mob_status == '1' && maccms.url != maccms.wapurl) {
          if (document.domain == maccms.url && /Mobile/.test(navigator.userAgent)) {
            location.href = location.href.replace(maccms.url, maccms.wapurl);
          } else if (document.domain == maccms.wapurl && !/Mobile/.test(navigator.userAgent)) {
            location.href = location.href.replace(maccms.wapurl, maccms.url);
          }
        }
      } catch (e) {}
    }
  },
  'Verify': {
    'Init': function () {
      eWave.Verify.Focus();
      eWave.Verify.Click();
    },
    'Focus': function () {
      $('body').on('focus', '.mac_verify', function () {
        $(this).removeClass('mac_verify').after(eWave.Verify.Show());
        $(this).unbind();
      });
    },
    'Click': function () {
      $('body').on('click', 'img.mac_verify_img', function () {
        $(this).attr('src', maccms.path + '/index.php/verify/index.html?r=' + Math.random());
      });
    },
    'Refresh': function () {
      $('.mac_verify_img').attr('src', maccms.path + '/index.php/verify/index.html?r=' + Math.random());
    },
    'Show': function () {
      return '<img class="mac_verify_img" src="' + maccms.path + '/index.php/verify/index.html?"  title="看不清楚? 换一张！">';
    }
  },
  'Hits': {
    'Init': function () {
      if ($('.mac_hits').length == 0) {
        return;
      }
      var $that = $(".mac_hits");
      eWave.Ajax(maccms.path + '/index.php/ajax/hits?mid=' + $that.attr("data-mid") + '&id=' + $that.attr("data-id") + '&type=update', 'get', 'json', '', function (r) {
        if (r.code == 1) {
          $(".mac_hits").each(function (i) {
            var $type = $(".mac_hits").eq(i).attr('data-type');
            if ($type != 'insert') {
              $('.' + $type).html(eval('(r.data.' + $type + ')'));
            }
          });
        }
      });
    }
  },
  'Timming': {
    'Init': function () {
      if ($('.mac_timming').length == 0) {
        return;
      }
      var infile = $('.mac_timming').attr('data-file');
      if (infile == undefined || infile == '') {
        infile = 'api.php';
      }
      var t = (new Image());
      t.src = maccms.path + '/' + infile + '/timming/index?t=' + Math.random();
    }
  } 
}

/* 初始化 */
$(function () {
  eWave.Image.Init();
  eWave.Copy.Init();
  eWave.Star.Init();
  eWave.Swiper.Init();
  eWave.Adaptive.Init();
  eWave.Verify.Init();
  eWave.Hits.Init();
  eWave.Timming.Init();
  eWave.Sort.Init();
  eWave.Tab.Init();
  eWave.OffCanvas.Init();
  eWave.Search.Init();
  eWave.UI.Init();
  eWave.Playlist.InitSort();
});