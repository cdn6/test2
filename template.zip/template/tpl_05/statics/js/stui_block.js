var stui = {
	'browser': {//浏览器
		url: document.URL,
		domain: document.domain,
		title: document.title,
		language: (navigator.browserLanguage || navigator.language).toLowerCase(),
		canvas: function() {
			return !!document.createElement("canvas").getContext
		}(),
		useragent: function() {
			var a = navigator.userAgent;
			return {
				mobile: !! a.match(/AppleWebKit.*Mobile.*/),
				ios: !! a.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/),
				android: -1 < a.indexOf("Android") || -1 < a.indexOf("Linux"),
				iPhone: -1 < a.indexOf("iPhone") || -1 < a.indexOf("Mac"),
				iPad: -1 < a.indexOf("iPad"),
				trident: -1 < a.indexOf("Trident"),
				presto: -1 < a.indexOf("Presto"),
				webKit: -1 < a.indexOf("AppleWebKit"),
				gecko: -1 < a.indexOf("Gecko") && -1 == a.indexOf("KHTML"),
				weixin: -1 < a.indexOf("MicroMessenger")
			}
		}()
	},
	'images': {//图片处理
		'lazyload': function() {
			$(".lazyload").lazyload({
				effect: "fadeIn",
				threshold: 200,
				failurelimit: 15,
				skip_invisible: false
			})
		},
'qrcode': function() {
    $("img.qrcode")
        .attr("src", "/index.php/qrcode/index.html?url=" + encodeURIComponent(stui.browser.url))
        .css({ width: "180px", height: "180px" }); // 强制调整显示大小
}
	},
	'common': {//公共基础
		'tab': function() {
			$(".tab li").on('click',function(){
			    $(".tab li.active").removeClass('active')
			    $(this).addClass('active')
			    var index = $(this).index()
				$(".tab-content .item").eq(index).addClass('active').siblings().removeClass('active');
	  		})
		  	$(".down-tab li").on('click',function(){
			    $(".down-tab li.active").removeClass('active')
			    $(this).addClass('active')
			    var index = $(this).index()
			    $(this).parent().parent().find("h3").html($(".down-tab li.active").html())
				$(".down-content .down-item").eq(index).addClass('active').siblings().removeClass('active');
				$(".down-tab").hide()			
	  		})
		  	$(".play-tab li").on('click',function(){
			    $(".play-tab li.active").removeClass('active')
			    $(this).addClass('active')
			    var index = $(this).index()
			    $(this).parent().parent().find("h3").html($(".play-tab li.active").html())
				$(".play-content .play-item").eq(index).addClass('active').siblings().removeClass('active');
				$(".play-tab").hide()			
	  		})
		  	$(".play-switch").on('click',function(){
		  		$(".play-tab").toggle()
		  	})
		  	$(".down-switch").on('click',function(){
		  		$(".down-tab").toggle()
		  	})
		},	
		'history': function() {
			if($.cookie("recente")){
			    var json=eval("("+$.cookie("recente")+")");
			    var list="";
			    for(i=0;i<json.length;i++){
			        list = list + "<li class='top-line'><a href='"+json[i].vod_url+"' title='"+json[i].vod_name+"'><span class='pull-right text-red'>"+json[i].vod_part+"</span>"+json[i].vod_name+"</a></li>";
			    }
			    $("#stui_history").append(list);
			}
			else
	            $("#stui_history").append("<p style='padding: 80px 0; text-align: center'>您还没有看过影片哦</p>");
		   
		    $(".historyclean").on("click",function(){
		    	$.cookie("recente",null,{expires:-1,path: '/'});
		    })		    
		},
		'collapse': function() {
			// 详情展开/收起功能
			$('.detail-more').click(function() {
				var $container = $(this).closest('.desc');
				var $sketch = $container.find('.detail-sketch');
				var $content = $container.find('.detail-content');
				var $more = $(this);
				
				if ($content.is(':visible')) {
					$content.hide();
					$sketch.show();
					$more.html('详情 <i class="icon iconfont icon-moreunfold"></i>');
				} else {
					$sketch.hide();
					$content.show();
					$more.html('收起 <i class="icon iconfont icon-moreunfold" style="transform: rotate(180deg);"></i>');
				}
			});
		},
		'playlist': function() {
			// 播放列表标签切换功能
			$('.playlist-tab').click(function() {
				var tabIndex = $(this).data('tab');
				
				// 移除所有活动状态
				$('.playlist-tab').removeClass('active');
				$('.playlist-item').removeClass('active');
				
				// 添加当前活动状态
				$(this).addClass('active');
				$('.playlist-item[data-content="' + tabIndex + '"]').addClass('active');
			});
		},
		'more': function() {
			$(".menu-switch").on('click',function(){
		  		var display = PlaySide.css('display');
		  		if(display == 'block'){
		  			PlaySide.hide(); 
		  			PlayLeft.css("width","100%");
		  			$(this).find("span").html("打开菜单")
				}else{
					PlaySide.show();  
					PlayLeft.css("width","75%");
					$(this).find("span").html("关闭菜单")
				}
			})
		  	
		  	$(".open-desc").on('click',function(){
		  		var $this = $(this);
		  		var $dataMore = $(".data-more");
		  		
		  		if($dataMore.is(':visible')){
		  			// 收起
		  			$dataMore.slideUp("slow");
		  			$this.html('详情 <i class="iconfont icon-moreunfold"></i>');
		  		} else {
		  			// 展开
		  			$dataMore.slideDown("slow");
		  			$this.html('收起 <i class="iconfont icon-less"></i>');
		  		}
		  	})
		  	
		  	var date = new Date;
			var h = date.getHours();  //时
			var minute = date.getMinutes()  //分
			if(h<10){
				h = "0"+h;
			}
			if(minute<10){
				minute = "0"+minute;
			}
			$(".date").html('<span>'+h+":"+minute+"</span>");
		},
	}	
};
$(document).ready(function() {	
	stui.images.lazyload();
	stui.images.qrcode();
	stui.common.tab();
	stui.common.history();
	stui.common.collapse();
	stui.common.playlist();
	stui.common.more();
});
