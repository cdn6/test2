$(document).ready(function () {
  if (MAC.UserAgent.mobile) {
    if ($(".ff-gallery").length>0) {
      $.ajaxSetup({
        cache: true
      });
      $("<link>").attr({
        rel: "stylesheet",
        type: "text/css",
        href: "https://cdnjs.cloudflare.com/ajax/libs/flickity/1.1.1/flickity.min.css"
      }).appendTo("head");
      $.getScript("https://cdnjs.cloudflare.com/ajax/libs/flickity/1.1.1/flickity.pkgd.min.js", function (response, status) {
        $('.ff-gallery').each(function () {
          $(this).flickity({
            cellAlign: 'left',
            freeScroll: true,
            contain: true,
            prevNextButtons: false,
            pageDots: false,
            initialIndex: $(this).find(".btn-success").index()
          });
        });
      });
    }
  }
  $("[data-toggle='popover']").popover({
    html: true
  });
  $("[data-toggle='popover']").on('show.bs.popover', function () {
    $("[data-toggle='popover']").attr('data-content', '<img src="'+maccms.path_tpl+'img/qrcode.png"/>');
  });
  $("img.ff-img").lazyload({
    effect: "fadeIn",
    failurelimit: 15
      //threshold : 400
      //skip_invisible : false
      //container: $(".carousel-inner"),
  });
});