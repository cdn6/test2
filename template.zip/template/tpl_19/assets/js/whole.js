String.prototype.replaceAll = function(s1, s2) { return this.replace(new RegExp(s1, "gm"), s2); }
String.prototype.trim = function() { return this.replace(/(^\s*)|(\s*$)/g, ""); }
var base64EncodeChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
var base64DecodeChars = new Array(-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1);
function base64encode(str) {
	var out, i, len;
	var c1, c2, c3;
	len = str.length;
	i = 0;
	out = "";
	while (i < len) {
		c1 = str.charCodeAt(i++) & 0xff;
		if (i == len) {
			out += base64EncodeChars.charAt(c1 >> 2);
			out += base64EncodeChars.charAt((c1 & 0x3) << 4);
			out += "==";
			break
		}
		c2 = str.charCodeAt(i++);
		if (i == len) {
			out += base64EncodeChars.charAt(c1 >> 2);
			out += base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4));
			out += base64EncodeChars.charAt((c2 & 0xF) << 2);
			out += "=";
			break
		}
		c3 = str.charCodeAt(i++);
		out += base64EncodeChars.charAt(c1 >> 2);
		out += base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4));
		out += base64EncodeChars.charAt(((c2 & 0xF) << 2) | ((c3 & 0xC0) >> 6));
		out += base64EncodeChars.charAt(c3 & 0x3F)
	}
	return out
}
function base64decode(str) {
	var c1, c2, c3, c4;
	var i, len, out;
	len = str.length;
	i = 0;
	out = "";
	while (i < len) {
		do c1 = base64DecodeChars[str.charCodeAt(i++) & 0xff]
		while (i < len && c1 == -1);
		if (c1 == -1) break;
		do c2 = base64DecodeChars[str.charCodeAt(i++) & 0xff]
		while (i < len && c2 == -1);
		if (c2 == -1) break;
		out += String.fromCharCode((c1 << 2) | ((c2 & 0x30) >> 4));
		do {
			c3 = str.charCodeAt(i++) & 0xff;
			if (c3 == 61) return out;
			c3 = base64DecodeChars[c3]
		}
		while (i < len && c3 == -1);
		if (c3 == -1) break;
		out += String.fromCharCode(((c2 & 0XF) << 4) | ((c3 & 0x3C) >> 2));
		do {
			c4 = str.charCodeAt(i++) & 0xff;
			if (c4 == 61) return out;
			c4 = base64DecodeChars[c4]
		}
		while (i < len && c4 == -1);
		if (c4 == -1) break;
		out += String.fromCharCode(((c3 & 0x03) << 6) | c4)
	}
	return out
}
function utf16to8(str) {
	var out, i, len, c;
	out = "";
	len = str.length;
	for (i = 0; i < len; i++) {
		c = str.charCodeAt(i);
		if ((c >= 0x0001) && (c <= 0x007F)) {
			out += str.charAt(i)
		} else if (c > 0x07FF) {
			out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F));
			out += String.fromCharCode(0x80 | ((c >> 6) & 0x3F));
			out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F))
		} else {
			out += String.fromCharCode(0xC0 | ((c >> 6) & 0x1F));
			out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F))
		}
	}
	return out
}
function utf8to16(str) {
	var out, i, len, c;
	var char2, char3;
	out = "";
	len = str.length;
	i = 0;
	while (i < len) {
		c = str.charCodeAt(i++);
		switch (c >> 4) {
		case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7:
			out += str.charAt(i - 1);
			break;
		case 12: case 13:
			char2 = str.charCodeAt(i++);
			out += String.fromCharCode(((c & 0x1F) << 6) | (char2 & 0x3F));
			break;
		case 14:
			char2 = str.charCodeAt(i++);
			char3 = str.charCodeAt(i++);
			out += String.fromCharCode(((c & 0x0F) << 12) | ((char2 & 0x3F) << 6) | ((char3 & 0x3F) << 0));
			break
		}
	}
	return out
}

var EC = {
	'Api': '/api.php/provide/',
	'Url': document.URL,
	'UserAgent': function() {
		var ua = navigator.userAgent;
		return {
			'mobile': !!ua.match(/AppleWebKit.*Mobile.*/),
			'ios': !!ua.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/),
			'android': ua.indexOf('Android') > -1 || ua.indexOf('Linux') > -1,
			'iPhone': ua.indexOf('iPhone') > -1 || ua.indexOf('Mac') > -1,
			'iPad': ua.indexOf('iPad') > -1,
			'trident': ua.indexOf('Trident') > -1,
			'presto': ua.indexOf('Presto') > -1,
			'webKit': ua.indexOf('AppleWebKit') > -1,
			'gecko': ua.indexOf('Gecko') > -1 && ua.indexOf('KHTML') == -1,
			'weixin': ua.indexOf('MicroMessenger') > -1
		};
	}(),
	'Cookie': {
		'Set': function(name, value, days) {
			var exp = new Date();
			exp.setTime(exp.getTime() + days * 24 * 60 * 60 * 1000);
			var arr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
			document.cookie = name + "=" + encodeURIComponent(value) + ";path=/;expires=" + exp.toUTCString();
		},
		'Get': function(name) {
			var arr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
			if (arr != null) {
				return decodeURIComponent(arr[2]);
				return null;
			}
		},
		'Del': function(name) {
			var exp = new Date();
			exp.setTime(exp.getTime() - 1);
			var cval = this.Get(name);
			if (cval != null) {
				document.cookie = name + "=" + encodeURIComponent(cval) + ";path=/;expires=" + exp
			.toUTCString();
			}
		}
	},
	'Parameter': function() {
		var url = location.search;
		var url = decodeURI(url);
		var theRequest = new Object();
		if (url.indexOf("?") != -1) {
			var str = url.substr(1);
			strs = str.split("&");
			for (var i = 0; i < strs.length; i++) {
				theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
			}
		}
		return theRequest;
	},
	'Ajax': function(url, type, dataType, data, sfun, efun, cfun) {
		type = type || 'get';
		dataType = dataType || 'json';
		data = data || '';
		efun = efun || '';
		cfun = cfun || '';

		$.ajax({
			url: url,
			type: type,
			dataType: dataType,
			data: data,
			timeout: 5000,
			beforeSend: function(XHR) {

			},
			error: function(XHR, textStatus, errorThrown) {
				if (efun) efun(XHR, textStatus, errorThrown);
			},
			success: function(data) {
				sfun(data);
			},
			complete: function(XHR, TS) {
				if (cfun) cfun(XHR, TS);
			}
		})
	},
	'All': {
		'Flashback': function() {
			$("#zxdaoxu").each(function() {
				$(this).on("click", function(e) {
					e.preventDefault();
					$(this).parent().parent().parent().find(".daoxu").each(function() {
						var playlist = $(this).find("li");
						for (let i = 0, j = playlist.length - 1; i < j;) {
							var l = playlist.eq(i).clone(true);
							var r = playlist.eq(j).replaceWith(l);
							playlist.eq(i).replaceWith(r);
							++i;
							--j;
						}
					});
				});
			});
		},
		'Tag': function() {
			$("#tag a").click(function() {
				$(this).addClass("active").siblings().removeClass("active");
				index = $("#tag a").index(this);
				let q = $("#tagContent #playsx").eq(index);
				q.fadeIn(800).siblings().hide();
				q.addClass("daoxu").siblings().removeClass("daoxu");
			});
		},
		'slide': function() {
			var mySwiper1 = new Swiper('.swiper-container1', {
				paginationClickable: true,
				slidesPerView: 'auto',
			});
		},
		'Details': function() {
			var el = $('.detailsTxt')[0]
			if (el) {
				var style = window.getComputedStyle(el)
				var height = style.height.replace('px', '')
				var lineHeight = style.lineHeight.replace('px', '')
				if (parseInt(height / lineHeight) > 1) {
					$('.ectogg').html('展开<i class="iconfont icon-zhankaixiajiantou-"></i>');
				}
			}
			$('.ectogg').click(function() {
				if ($(this).children('.iconfont').hasClass("icon-zhankaixiajiantou-")) {
					$(this).removeClass('away');
					$('.detailsTxt').css("max-height", "none");
					$(this).html('收起<i class="iconfont icon-shouqi"></i>');
				} else {
					$(this).addClass('away');
					$('.detailsTxt').css("max-height", "40px");
					$(this).html('展开<i class="iconfont icon-zhankaixiajiantou-"></i>');
				}
			})
		},
		'Top': function() {
			$('.fixed-nav .icon-fenxiang').tipso({
				useTitle: false,
				delay: 2,
				background: '#333',
				width: 100
			});
			$('.fixed-nav .icon-fankuixuanzhong').tipso({
				useTitle: false,
				delay: 2,
				background: '#333',
				position: 'right',
				width: 100
			});
			$('.ecTop').click(function() {
				let mi = $(this).attr('data-id');
				if (mi > 0) {
					$("html,body").animate({
						scrollTop: $("#listId" + mi).offset().top - 100
					}, 1000);
				} else {
					$("html,body").animate({
						scrollTop: $("body").offset().top
					}, 1000);
				}
			})
			$(".ec-lrmenukey").on('click', function(e) {
				$('.ec-lrmenu').toggleClass('ec-lrshow');
			});
			$(".history").on("click", ".icon-shanchu", function() {
				EC.Cookie.Del("ec_history");
				EC.All.message('操作提示', '搜索记录删除成功');
				$('.history').html(
					'<div class="movie-list-header"><span>搜索历史</span><a href="javascript:"  class="iconfont  icon-shanchu"></a></div><a href="javascript:" class="movie-list-subject">没有记录</a></div>'
					)
			});
			if ($(".ShareButton").length) {
				$(".ShareButton").click(function() {
					let urlToCopy = $(this).data('url');
					let tempTextarea = document.createElement("textarea");
					tempTextarea.value = urlToCopy;
					tempTextarea.style.position = "fixed";
					tempTextarea.style.left = "-9999px";
					document.body.appendChild(tempTextarea);
					tempTextarea.select();
					document.execCommand("copy");
					document.body.removeChild(tempTextarea);
					EC.All.message('操作提示', '复制成功~~');

				})
			}
			$(".history_box").on("click", ".historyClear", function() {
				EC.Vod.Clear();
			});
		},
		'Swiper': function() {
			var swiper1 = new Swiper('.swiper-container', {
				loop: true,
				effect: 'fade',
				pagination: {
					el: '.swiper-pagination',
				},
				autoplay: true,
			});
		},
		'Tablink': function() {
			$('.panel .tab-link').click(function() {
				var tabId = $(this).data('tab');
				var currentPanel = $(this).closest('.panel');
				currentPanel.find('.tab-link').removeClass('active');
				$(this).addClass('active');
				currentPanel.find('.tab-content').removeClass('active');
				currentPanel.find('#' + tabId).addClass('active');
			})
			var playlist = $(".plays-more");
			playlist.each(function(i) {
				if ($(this).find("li").length > 7) {
					$(this).find("li").eq(6).after(
						"<li class='more'><a class='btn' href='javascript:;'>展开更多</a></li>");
					var more = $(this).find("li.more");
					var prev = more.index();
					more.show();
					for (i = prev + 1; i < $(this).find("li").length; ++i)
						$(this).find("li").eq(i).hide();
				}
			})
			$("li.more").on("click", function() {
				var more = $(this).parent("ul").find("li.more");
				var newlist = $(this).parent("ul").find("li");
				var prev = more.index();
				for (i = 0; i < newlist.length; ++i)
					newlist.eq(i).show();
				more.hide();
			})
		},
		'Navigation': function() {
			$('#react-burger-menu-btn').click(function() {
				$('.bm-overlay').parent().show();
				$(".header").parent().addClass("deviation");
				$('.bm-menu-wrap').addClass("bm-list-right");
			})
			$(".icon-guanbi").click(function() {
				$(".header").parent().removeClass("deviation");
				$('.bm-menu-wrap').removeClass("bm-list-right");
				$('.bm-overlay').parent().hide();
			})
			$(".bm-overlay").click(function() {
				$(".header").parent().removeClass("deviation");
				$('.bm-menu-wrap').removeClass("bm-list-right");
				$('.bm-overlay').parent().hide();
			})
		},
		'Lazy': function(e) {
			$(e).lazyload({
				effect: "fadeIn",
				threshold: 200,
				failurelimit: 50,
				skip_invisible: false,
			});
		},
		'message': function(title, message) {
			iziToast.show({
				class: 'test',
				messageColor: '#fff',
				color: '#4c4c4c',
				message: message,
				position: 'topCenter',
				progressBarColor: '#22ce6b',
				layout: 1,
				onClose: function() {
					console.info('onClose');
				},
			});
		}
	},
	'History': {
		'BoxShow': 0,
		'Limit': 8,
		'Days': 7,
		'Json': '',
		'Init': function() {
			$(".search-field").click(function() {
				$('.suggestions').slideDown()
			})
			$(".search-box").keydown(function() {
				$(".suggestions").slideUp()
			});
			$(".header-box").mouseleave(function() {
				$(".suggestions").slideUp()
			})
			$('.search-button').click(function(e) {
				e.preventDefault();
				let val = $('.search-field').val().trim();
				let url = $('#search').attr('action');
				if (val.length > 0) {
					EC.History.Set(val, url);
					$('#search').attr('action', url + '?wd=' + encodeURIComponent(val));
					$('#search').submit();
				} else {
					EC.All.message('搜索提示', '请输入搜索关键词');
				}
			});
			
			// 监听回车键搜索
			$('.search-field').keypress(function(e) {
				if (e.which === 13) {
					e.preventDefault();
					let val = $(this).val().trim();
					let url = $('#search').attr('action');
					if (val.length > 0) {
						EC.History.Set(val, url);
						$('#search').attr('action', url + '?wd=' + encodeURIComponent(val));
						$('#search').submit();
					} else {
						EC.All.message('搜索提示', '请输入搜索关键词');
					}
				}
			});
			
			$('#search').submit(function(e) {
				let val = $('.search-field').val().trim();
				if (val.length === 0) {
					e.preventDefault();
					EC.All.message('搜索提示', '请输入搜索关键词');
					return false;
				}
			});

			var jsondata = [];
			if (this.Json) {
				jsondata = this.Json;
			} else {
				var jsonstr = EC.Cookie.Get('ec_history');
				if (jsonstr != undefined) {
					jsondata = eval(jsonstr);
				}
			}
			let html =
				'<div class="movie-list-header"><span>搜索历史</span><a href="javascript:" class="iconfont  icon-shanchu"></a></div>';
			if (jsondata.length > 0) {
				for (let i = 0; i < jsondata.length; i++) {
					html += '<a href="' + jsondata[i].url + '?wd=' + jsondata[i].name +
						'" class="movie-list-subject search">' + jsondata[i].name + '</a>';
				}
			} else {
				html += '<a class="movie-list-subject search" href="javascript:">没有记录</a>';
			}
			html += '</div>';
			$('.history').prepend(html);
		},
		'Set': function(name, url) {
			var jsondata = EC.Cookie.Get('ec_history');
			if (jsondata != undefined) {
				this.Json = eval(jsondata);
				for (let i = 0; i < this.Json.length; i++) {
					if (this.Json[i].name == name) {
						return false;
					}
				}
				jsonstr = '{log:[{"name":"' + name + '","url":"' + url + '"},';
				for (let i = 0; i < this.Json.length; i++) {
					if (i <= this.Limit && this.Json[i]) {
						let ecRepeat = this.Json[i].name;
						if (ecRepeat === name) {} else {
							jsonstr += '{"name":"' + this.Json[i].name + '","url":"' + this.Json[i].url + '"},';
						}
					} else {
						break;
					}
				}
				jsonstr = jsonstr.substring(0, jsonstr.lastIndexOf(','));
				jsonstr += "]}";
			} else {
				jsonstr = '{log:[{"name":"' + name + '","url":"' + url + '"}]}';
			}
			this.Json = eval(jsonstr);
			EC.Cookie.Set('ec_history', jsonstr, this.Days);
		},
	},
	'Vod': {
		'BoxShow': 0,
		'Limit': 8,
		'Days': 7,
		'Json': '',
		'Init': function() {
			if ($('.history_box').length == 0) {
				return;
			}
			$('.history-box').hover(function() {
				$('.history_box').show();
			}, function() {
				$('.history_box').hide();
			});
			var jsondata = [];
			if (this.Json) {
				jsondata = this.Json;
			} else {
				var jsonstr = EC.Cookie.Get('mac_history');
				if (jsonstr != undefined) {
					jsondata = eval(jsonstr);
				}
			}
			let html =
				'<a href="javascript:" class="historyClear iconfont  icon-shanchu"></a><ul class="record" style="padding:20px 0">';
			if (jsondata.length > 0) {
				for ($i = 0; $i < jsondata.length; $i++) {
					html += '<li><a href="' + jsondata[$i].link + '" target="_blank" class="txtHide">' +
						jsondata[$i].name + '</a><span class="right">' + jsondata[$i].mid + '</span></li>';
				}
			} else {
				html +=
					'<div class="nodata"><p><img src="/template/tpl_19/assets/images/no.png"></p><p class="top">您还没有观看任何视频</p></div>';
			}
			html += '</ul>';
			$('.history_box').prepend(html);

			if ($(".mac_history_set").attr('data-name')) {
				let $that = $(".mac_history_set");
				EC.Vod.Set($that.attr('data-name'), $that.attr('data-link'), $that.attr('data-mid'));
			}
		},
		'Set': function(name, link, mid) {
			if (!link) {
				link = document.URL;
			}
			var jsondata = EC.Cookie.Get('mac_history');
			if (jsondata != undefined) {
				this.Json = eval(jsondata);

				for ($i = 0; $i < this.Json.length; $i++) {
					if (this.Json[$i].link == link) {
						return false;
					}
				}
				jsonstr = '{log:[{"name":"' + name + '","link":"' + link + '","mid":"' + mid + '"},';
				for ($i = 0; $i < this.Json.length; $i++) {
					if ($i <= this.Limit && this.Json[$i]) {
						let ecRepeat = this.Json[$i].name;
						if (ecRepeat === name) {} else {
							jsonstr += '{"name":"' + this.Json[$i].name + '","link":"' + this.Json[$i].link +
								'","mid":"' + this.Json[$i].mid + '"},';
						}
					} else {
						break;
					}
				}
				jsonstr = jsonstr.substring(0, jsonstr.lastIndexOf(','));
				jsonstr += "]}";
			} else {
				jsonstr = '{log:[{"name":"' + name + '","link":"' + link + '","mid":"' + mid + '"}]}';
			}
			this.Json = eval(jsonstr);
			EC.Cookie.Set('mac_history', jsonstr, this.Days);
		},
		'Clear': function() {
			EC.Cookie.Del('mac_history');
			$('.history_box').html(
				'<div class="nodata"><p><img src="/template/cupfox/assets/images/no.png"></p><p>播放记录已清空</p></div>'
				);
		},
	},
	'Style': {
		'Init': function() {
			let $theme = EC.Cookie.Get('theme');
			if ($theme) {
				$('body').attr('shoutu-theme', $theme);
			} else {
				$theme = document.body.getAttribute('shoutu-theme')
			}
			if ($theme == 'dark') {
				$('.skin').removeClass('icon-yueliang').addClass('icon-bairi');
			} else {
				$('.skin').removeClass('icon-bairi').addClass('icon-yueliang');
			}
		},
		'Set': function() {
			let $theme = $('body').attr('shoutu-theme');
			setTimeout(function() {
				if ($theme == 'dark') {
					$('body').attr('shoutu-theme', 'white');
					EC.Cookie.Set('theme', 'white', 365);
					$('.skin').removeClass('icon-bairi').addClass('icon-yueliang');
				} else {
					$('body').attr('shoutu-theme', 'dark');
					$('.skin').removeClass('icon-yueliang').addClass('icon-bairi');
					EC.Cookie.Set('theme', 'dark', 365);
				}
			});
		}
	},
	'AddEm': function(obj, i) {
		var oldtext = $(obj).val();
		$(obj).val(oldtext + '[em:' + i + ']');
	},
	'Remaining': function(obj, len, show) {
		var count = len - $(obj).val().length;
		if (count < 0) {
			count = 0;
			$(obj).val($(obj).val().substr(0, 200));
		}
		$(show).text(count);
	},
	'Adaptive': function() {
		if (typeof maccms !== 'undefined' && maccms.mob_status == '1' && maccms.url != maccms.wapurl) {
			if (document.domain == maccms.url && EC.UserAgent.mobile) {
				location.href = location.href.replace(maccms.url, maccms.wapurl);
			} else if (document.domain == maccms.wapurl && !EC.UserAgent.mobile) {
				location.href = location.href.replace(maccms.wapurl, maccms.url);
			}
		}
	},
	'Hits': {
		'Init': function() {
			if ($('.mac_hits').length == 0) {
				return;
			}
			var $that = $(".mac_hits");
			EC.Ajax(maccms.path + '/index.php/ajax/hits?mid=' + $that.attr("data-mid") + '&id=' + $that.attr("data-id") + '&type=update', 'get', 'json', '', function(r) {
				if (r.code == 1) {
					$(".mac_hits").each(function(i) {
						$type = $(".mac_hits").eq(i).attr('data-type');
						if ($type != 'insert') {
							$('.' + $type).html(eval('(r.data.' + $type + ')'));
						}
					});
				}
			});
		}
	}
}
$(function() {
	//自动跳转手机和pc网页地址
	EC.Adaptive();
	//点击数量初始化
	EC.Hits.Init();
	//返回顶部初始化
	EC.All.Top();
	//幻灯片初始化
	EC.All.Swiper();
	EC.All.Tablink();
	//测导航初始化
	EC.All.Navigation();
	//搜索初始化
	EC.History.Init();
	//历史记录初始化
	EC.Vod.Init();
	//懒加载
	EC.All.Lazy('.Lazy');
	//首页列表切换初始化
	//风格切换初始化
	EC.Style.Init();
	//倒叙切换
	EC.All.Flashback();
	//选集切换
	EC.All.Tag();
	//选集选集
	EC.All.slide();
	//详情信息展开收起
	EC.All.Details();
});

function mac_style() {
	EC.Style.Set();
}