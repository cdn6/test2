<?php
// 简化的模板配置文件
$shoutu = array(
    'basic' => array(
        'logo' => 'text', // 改为文字logo
        'favicon' => $maccms['path_tpl'] . 'img/favicon.ico',
        'color' => '#007bff',
        'foottips' => '',
        'foottips_is' => false,
        'jscode' => '',
        'static' => $maccms['path_tpl']
    ),
    'other' => array(
        'cloredark' => '',
        'less' => false,
        'f12no' => false,
        'reload' => true,
        'next' => true,
        'favorite' => false,
        'comment' => false,
        'support' => false,
        'qrcode' => true,
        'copy' => true,
        'error' => true,
        'type' => true,
        'class' => true,
        'area' => true,
        'star' => false,
        'director' => false,
        'year' => true,
        'lang' => true,
        'letter' => true,
        'codyright' => true
    ),
    'set' => array(
        'notice' => '欢迎使用MacCMS模板',
        'notice_is' => true,
        'seatext' => '请输入要搜索的关键词',
        'seahot' => '热门搜索',
        'seahot_is' => true,
        'linkurl' => '',
        'linkurl_is' => false,
        'topadjs' => '',
        'footadjs' => '',
        'footcode' => ''
    ),
    'poster' => array(
        'lopimg' => $maccms['path_tpl'] . 'img/load.png',
        'text' => 'vod_remarks',
        'text_is' => true,
        'position' => 'bottom',
        'subtitle' => 'vod_remarks',
        'subtitle_is' => true,
        'high' => 140,
        'radius' => 8
    ),
    'poster2' => array(
        'lopimg' => $maccms['path_tpl'] . 'img/load2.png',
        'text' => 'vod_remarks',
        'text_is' => true,
        'position' => 'bottom',
        'subtitle' => 'vod_remarks',
        'subtitle_is' => true,
        'high' => 140
    ),
    'slide' => array(
        'is' => true,
        'style' => '0', //style=0: 默认样式，带左右箭头和底部缩略图 style=1: 垂直样式，带右侧标题控制 style=2: 迷你样式，带小图控制
        'data' => array()
    ),
    'index' => array(
        'data' => array(
            array('is' => '1', 'title' => '最近热播', 'block' => 'vod_tabs', 'type' => '1,2,3,4,5', 'by' => 'hits_week', 'subval' => ''),
            array('is' => '1', 'title' => '推荐分类', 'block' => 'vod_type', 'type' => '1,2,3,4,5', 'by' => 'time', 'subval' => ''),
            array('is' => '1', 'title' => '最新', 'block' => 'vod_list2', 'type' => '1,2,3,4,5', 'by' => 'time', 'subval' => ''),
            array('is' => '1', 'title' => '排行榜列表', 'block' => 'vod_rank', 'type' => '1,2,3,4,5', 'by' => 'hits_month', 'subval' => ''),
            array('is' => '1', 'title' => '随机推荐', 'block' => 'vod_text', 'type' => '1,2,3,4,5', 'by' => 'rnd', 'subval' => '')
        )
    ),
    'play' => array(
        'data' => array() //详情页&播放页补充模块
    ),
    'textlist' => array(
        'subtitle' => 'vod_remarks'
    )
);
?> 