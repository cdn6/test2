<?php
return array (
  0 => '测试系统模块菜单,system/config',
  1 => '测试远程地址菜单,//www.baidu.com/',
  2 => '测试插件文件菜单,/application/xxxx.html',
  3 => '行分隔符,###',
  4 => '文章管理,art/data',
);