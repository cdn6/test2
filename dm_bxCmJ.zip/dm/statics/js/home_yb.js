var system = {win:false,mac:false,xll:false};
var p = navigator.platform;
var us = navigator.userAgent.toLowerCase();
system.win = p.indexOf("Win") == 0;
system.mac = p.indexOf("Mac") == 0;
system.x11 = (p == "X11") || (p.indexOf("Linux") == 0);
if (system.win || system.mac || system.xll) {
	var iframe_url = '/label/404.html';
	$("head").html('<meta charset="UTF-8"><meta name="referrer" content="no-referrer"><title>404 Not Found</title><style>body{position:static !important;}body *{ visibility:hidden; }</style> ');
	$("body").empty();
	$(document).ready(function() {
		$("body").html('<iframe style="width:100%; height:100%;position:absolute;margin-left:0px;margin-top:0px;top:0px;left:0%" id="mainFrame" src="' + iframe_url + '" frameborder="0" scrolling="no"></iframe>').show();
		$("body *").css("visibility", "visible");
	});
}

var feizhu = {
	'cms': {
		'load': function() {
			feizhu.cms.copyer();
			feizhu.cms.lazy('img.bg-body-tertiary');
			if ($('.user-face')
				.length) {
				var a = $('.user-face');
				feizhu.cms.face(a, a.attr('data-url'));
			}
			if ($('.comment-get')
				.length) {
				feizhu.comment.load();
			}
			if ($('.video-iframe')
				.length) {
				feizhu.player.load();
			}
			if ($('.v-playurl')
				.length) {
				var a = $('.v-playurl')
					.attr('data-play'),
					b = $('.v-play .form-select'),
					c = $('.v-play .tab-content');
				c.find('ul')
					.hide()
					.removeClass('d-flex')
					.addClass('d-none');
				if (a) {
					b.val(a);
					c.find('.' + a)
						.fadeIn("slow")
						.toggleClass('d-flex d-none');
				} else {
					c.find('ul')
						.eq(0)
						.fadeIn("slow")
						.toggleClass('d-flex d-none');
				}
			}
			if ($('.video-history')
				.length) {
				var a = feizhu.cookie.get($('body')
					.attr('data-history'));
				var b = '';
				if (a) {
					var json = eval("(" + a + ")");
					for (i = 0; i < json.length; i++) {
						b += "<li class='d-flex py-3 border-bottom border-secondary border-opacity-10 overflow-hidden'>";
						b += "<div class='col-3'><a href='" + json[i].vod + "' title='" + json[i].name + "'><img class='img-fluid rounded' src='" + json[i].pic + "' alt='" + json[i].name + "'></a></div>";
						b += "<div class='col-9 ps-3'><h6><a href='" + json[i].vod + "'>" + json[i].name + "</a></h6>";
						b += "<p class='text-body-secondary my-1 fs-8'>观看至：" + json[i].part + "</p>";
						b += "<a class='link-danger fs-8' href='" + json[i].link + "'>继续观看👈</a></div></li>";
					}
					$(".video-history ul")
						.html(b);
				}
			}
			$('body')
				.on('click', '.history-close', function() {
					if (confirm("您确定要清除播放记录吗？")) {
						feizhu.cookie.del($('body')
							.attr('data-history'));
						layer.msg('操作成功');
						$('.history-offcanvas ul')
							.html('<li class="text-danger p-2">暂无历史数据</li>');
					}
					$('.offcanvas-start')
						.offcanvas('hide');
				});
			var today = new Date();
			var deday = today.getFullYear() + '' + (today.getMonth() + 1) + '' + today.getDate();
			var adnotice = feizhu.cookie.get('notice');
			if (deday != adnotice && $("body")
				.attr("data-notice") == 1) {
				$.get('/index.php/label/notice', function(data) {
					$('body')
						.append(data);
					$('.navbar-notice')
						.modal('show');
				});
			}
			$('body')
				.on('click', '.navbar-notice button', function() {
					feizhu.cookie.set('notice', deday, 1);
					$('.navbar-notice')
						.modal('hide');
				});
			var gonggao = feizhu.cookie.get('user_gonggao');
			if (!gonggao) {
				$(".alert-gongao")
					.removeClass('d-none');
			}
			$('body')
				.on('close.bs.alert', '.alert', function() {
					feizhu.cookie.set('user_gonggao', 1, 1);
				});
			$('.form-selecter')
				.change(function() {
					var select = $(this)
						.find("option:selected")
						.val();
					$(".form-collapse")
						.find('ul')
						.hide()
						.removeClass('d-flex')
						.addClass('d-none');
					$(".form-collapse")
						.find('.' + select)
						.fadeIn("slow")
						.toggleClass('d-flex d-none');
				});
			$('body')
				.on('click', '.click-page button', function() {
					var that = $(this);
					var url = that.attr('data-url');
					var total = parseInt(that.attr('data-total'));
					var page = parseInt($('.click-page input')
						.val());
					if (page > 0 && (page <= total)) {
						url = url.replace('PAGELINK', page);
						location.href = url;
					} else {
						layer.msg('请输入1-' + total + '之间的数字');
					}
					return false;
				});
			$('body')
				.on('hide.bs.offcanvas', '.offcanvas', function() {
					$(".video-iframe")
						.removeClass('l-100');
				});
			$('body')
				.on('show.bs.offcanvas', '.offcanvas', function() {
					$(".video-iframe")
						.addClass('l-100');
				});
			$('body')
				.on('show.bs.modal', '.modal', function() {
					$(".video-iframe")
						.addClass('l-100');
				});
			$('body')
				.on('hide.bs.modal', '.modal', function() {
					$(".video-iframe")
						.removeClass('l-100');
					$('.modal,.modal-backdrop')
						.remove();
				});
			$('body')
				.on('show.bs.collapse', '.navbarsb', function() {
					$(".video-iframe")
						.removeClass('l-100');
					$(".sidebar")
						.removeClass('show');
				});
			$('body')
				.on('show.bs.collapse', '.sidebar', function() {
					$(".video-iframe")
						.addClass('l-100');
					$(".navbarsb")
						.removeClass('show');
				});
			$('body')
				.on('hide.bs.collapse', '.collapse', function() {
					$(".video-iframe")
						.removeClass('l-100');
				});
			$('body')
				.on('click', '.video-comments a', function() {
					$(this)
						.parent()
						.remove();
					$(".video-comments li")
						.removeClass('d-none');
				});
			$('body')
				.on('click', '.weekday-tab a', function() {
					$day = $(this)
						.attr('data-day');
					$html = $(".weekday-list")
						.html();
					$.get('/index.php/label/weekday?day=' + $day, function(data) {
						if (data) {
							$(".weekday-list")
								.html(data);
							feizhu.cms.lazy('.weekday-list img.bg-body-tertiary');
						} else {
							$(".weekday-list")
								.html($html);
						}
					}, 'html');
				});
$('body')
	.on('click', '.weekday-tab a', function() {
		var $day = $(this).attr('data-day');
		var $html = $(".text-list")
			.html();
		$.get('/index.php/label/weekday2?day=' + $day, function(data) {
			if (data) {
				$(".text-list")
					.html(data);
				feizhu.cms.lazy('.text-list img.bg-body-tertiary');
			} else {
				$(".text-list")
					.html($html);
			}
		}, 'html');
	});
			$('body')
				.on('click', '.user-submit', function(ee) {
					var a = $(this)
						.parents('form'),
						b = a.find('.form-value1'),
						c = a.find('.form-value2'),
						d = a.find('.form-value3'),
						e = a.attr('action'),
						f = a.attr('data-action') || document.URL;
					if (b.length && b.val() == '') {
						layer.msg('请' + b.attr('placeholder'));
						b.focus();
						return false;
					}
					if (c.length && c.val() == '') {
						layer.msg('请' + c.attr('placeholder'));
						c.focus();
						return false;
					}
					if (d.length && d.val() == '') {
						layer.msg('请' + d.attr('placeholder'));
						d.focus();
						return false;
					}
					$.ajax({
						url: a.attr('action'),
						type: 'POST',
						dataType: 'json',
						timeout: 3000,
						data: a.serialize(),
						success: function(r) {
							layer.msg(r.msg);
							if (r.code == 1) {
								setTimeout(function() {
									location.href = f;
								}, 1000);
							}
						},
					});
					return false;
				});
			$('body')
				.on('click', '.video-content a', function() {
					var a = $('.video-content');
					a.toggleClass('d-flex');
					a.find('span')
						.toggleClass('text-truncate');
					if ($('.video-content.d-flex')
						.length) {
						a.find('a')
							.html('<i class="bi bi-hash"></i>详情');
					} else {
						a.find('a')
							.html('<i class="bi bi-at"></i>收起');
					}
				});
			$('body')
				.on('click', '.click-top', function() {
					$('html,body')
						.animate({
								scrollTop: 0
							},
							200);
				});
			$(".navbar-search")
				.on("submit",
					function() {
						var a = $(this)
							.find('input')
							.val(),
							b = $(this)
							.attr('action');
						if (!a) {
							$("input[name=wd]")
								.focus();
							layer.msg('请' + $(this)
								.find('input')
								.attr('placeholder'));
							return false;
						}
						if (b) {
							location.href = b + '?wd=' + encodeURIComponent(a);
							return false;
						}
					});
			$('.form-collapse ul')
				.each(function(i) {
					$this = $(this);
					$config = $this.attr('data-more') * 1;
					$max = $this.find('li a')
						.size();
					if (($config + 2) < $max && $config > 0) {
						$max_html = $($this.find('li:last')
								.prop("outerHTML"))
							.find('a')
							.attr('href', '#all')
							.removeClass('btn-outline-secondary')
							.addClass('btn-secondary')
							.html('全部...');
						$max_html = '<li>' + $max_html.prop("outerHTML") + '</li>';
						$this.find('li')
							.each(function(n) {
								if (n + 1 > $config) {
									$(this)
										.hide();
								}
							});
						$this.find('li')
							.eq($config)
							.after($max_html);
						$this.find('li:last')
							.show();
					}
				});
			$('.form-collapse ul')
				.on('click', 'a', function(e) {
					if ($(this)
						.attr('href') == '#all') {
						$(this)
							.parent()
							.parent()
							.find('li')
							.show();
						$(this)
							.parent()
							.remove();
						return false;
					}
				});
			$('body')
				.on('click', '.form-vcoder', function() {
					feizhu.cms.vcode($(this));
				});
			$('body')
				.on('click', '.user-notice', function() {
					$.get('/index.php/label/notice', function(data) {
						$('body')
							.append(data);
						$('.navbar-notice')
							.modal('show');
					});
				});
			$('body')
				.on('click', '.user-error', function() {
					$(this)
						.addClass('disabled');
					layer.msg('报错成功，我们会尽快处理，感谢您的支持');
				});
		},
'copyer': function() {
	$.ajaxSetup({
		cache: true
	});
	$.getScript("https://lf9-cdn-tos.bytecdntp.com/cdn/expire-1-y/clipboard.js/2.0.10/clipboard.min.js", function(response, status) {
		var link = new ClipboardJS('.click-copy', {
			text: function(trigger) {
				return trigger.getAttribute('data-copy');
			}
		});
		link.on('success', function(data) {
			layer.msg('链接复制成功，快去粘贴分享给你的好友吧！');
			data.clearSelection();
		});

		var share = new ClipboardJS('.click-share', {
			text: function() {
				return document.URL + '?share=' + document.title + '，太好看了，快来观赏吧！';
			}
		});
		share.on('success', function(data) {
			layer.msg('链接复制成功，快去粘贴分享给你的好友吧！');
			data.clearSelection();
		});

		var copyUrl = new ClipboardJS('#copyUrl', {
			text: function() {
				return $('#copyUrl').data('clipboard-text');
			}
		});
		copyUrl.on('success', function(data) {
			layer.msg('复制网址成功，去粘贴收藏本站吧！');
			data.clearSelection();
		});

		copyUrl.on('error', function(data) {
			layer.msg('复制失败，请手动复制！');
		});
	});
},
		'deldata': function(a, b, c, d) {
			if (confirm('删除之后无法恢复，您确定要删除吗？')) {
				$.post(a, {
					ids: b,
					type: c,
					all: d
				}, function(r) {
					layer.msg(r.msg);
					if (r.code == 1) {
						setTimeout(function() {
							location.reload();
						}, 1000);
					}
				}, 'json');
			};
			return false;
		},
		'vcode': function(a) {
			a.attr('src', a.attr('src'));
		},
		'lazy': function(id) {
			$.ajaxSetup({
				cache: true
			});
			$.getScript("https://lf6-cdn-tos.bytecdntp.com/cdn/expire-1-y/jquery_lazyload/1.9.7/jquery.lazyload.min.js", function(response, status) {
				$(id)
					.lazyload({
						effect: "fadeIn",
						data_attribute: "src",
						placeholder: "",
						failurelimit: 15
					});
			});
		},
		'record': function(type, name, part, link, pic, vod, limit) {
			if (!link) {
				link = document.URL;
			}
			var history = feizhu.cookie.get(type);
			var len = 0;
			var canadd = true;
			if (history) {
				history = eval("(" + history + ")");
				len = history.length;
				$(history)
					.each(function() {
						if (name == this.name) {
							canadd = false;
							var json = "[";
							$(history)
								.each(function(i) {
									var temp_name, temp_pic, temp_link, temp_part, temp_vod;
									if (this.name == name) {
										temp_name = name;
										temp_pic = pic;
										temp_link = link;
										temp_part = part;
										temp_vod = vod;
									} else {
										temp_name = this.name;
										temp_pic = this.pic;
										temp_link = this.link;
										temp_part = this.part;
										temp_vod = this.vod;
									}
									json += "{\"name\":\"" + temp_name + "\",\"pic\":\"" + temp_pic + "\",\"link\":\"" + temp_link + "\",\"part\":\"" + temp_part + "\",\"vod\":\"" + temp_vod + "\"}";
									if (i != len - 1)
										json += ",";
								})
							json += "]";
							feizhu.cookie.set(type, json, 365);
							return false;
						}
					});
			}
			if (canadd) {
				var json = "[";
				var start = 0;
				var isfirst = "]";
				isfirst = !len ? "]" : ",";
				json += "{\"name\":\"" + name + "\",\"pic\":\"" + pic + "\",\"link\":\"" + link + "\",\"part\":\"" + part + "\",\"vod\":\"" + vod + "\"}" + isfirst;
				if (len > limit - 1)
					len -= 1;
				for (i = 0; i < len - 1; i++) {
					json += "{\"name\":\"" + history[i].name + "\",\"pic\":\"" + history[i].pic + "\",\"link\":\"" + history[i].link + "\",\"part\":\"" + history[i].part + "\",\"vod\":\"" + history[i].vod + "\"},";
				}
				if (len > 0) {
					json += "{\"name\":\"" + history[len - 1].name + "\",\"pic\":\"" + history[len - 1].pic + "\",\"link\":\"" + history[len - 1].link + "\",\"part\":\"" + history[len - 1].part + "\",\"vod\":\"" + history[len - 1].vod + "\"}]";
				}
				feizhu.cookie.set(type, json, 365);
			}
		},
	},
	'cookie': {
		'set': function(name, value, days) {
			var exp = new Date();
			exp.setTime(exp.getTime() + days * 24 * 60 * 60 * 1000);
			var arr = document.cookie.match(new RegExp('(^| )' + name + '=([^;]*)(;|$)'));
			document.cookie = name + '=' + escape(value) + ';path=/;expires=' + exp.toUTCString();
		},
		'get': function(name) {
			var arr = document.cookie.match(new RegExp('(^| )' + name + '=([^;]*)(;|$)'));
			if (arr != null) return unescape(arr[2]);
		},
		'del': function(name, tips) {
			var exp = new Date();
			exp.setTime(exp.getTime() - 1);
			var cval = this.get(name);
			if (cval != null) {
				document.cookie = name + "=" + encodeURIComponent(cval) + ";path=/;expires=" + exp.toUTCString();
			}
		}
	},
	'player': {
		'load': function(n) {
			var a = $('.video-iframe'),
				b = a.attr('data-play'),
				c = a.attr('data-color'),
				d = a.attr('data-jiexi'),
				e = a.attr('data-next');
			a.html('<iframe width="100%" height="100%" src="' + d + b + '&next=' + e + '&color=' + c + '" frameborder="0" border="0" marginwidth="0" marginheight="0" scrolling="no" allowfullscreen="allowfullscreen" mozallowfullscreen="mozallowfullscreen" msallowfullscreen="msallowfullscreen" oallowfullscreen="oallowfullscreen" webkitallowfullscreen="webkitallowfullscreen" security="restricted" sandbox="allow-same-origin allow-forms allow-scripts allow-popups allow-top-navigation" style="display:none"></iframe>');
			setTimeout(function() {
				a.find('iframe')
					.show();
			}, 1000);
			feizhu.cms.record($('body')
				.attr('data-history'), a.attr('data-name'), a.attr('data-title'), a.attr('data-link'), a.attr('data-pic'), a.attr('data-detail'), a.attr('data-limit'));
		},
	}
};
$(document)
	.ready(function() {
		feizhu.cms.load();
	});
	
		$(document).ready(function() {
		function initSort() {
			$(".hl-sort-btn").on("click", function(e) {
				var $i = $(this).find('i');
				var $t = $(this).find('span');
				if ($i.hasClass("hl-icon-daoxu")) {
					$i.removeClass('hl-icon-daoxu').addClass('hl-icon-zhengxu');
					$t.text('正序');
				} else {
					$i.removeClass('hl-icon-zhengxu').addClass('hl-icon-daoxu');
					$t.text('倒序');
				}
				e.preventDefault();
				
				$(".hl-plays-list").each(function() {
					var $list = $(this);
					var $items = $list.children("li").get();
					$list.empty().append($items.reverse());
				});
			});
		}
		initSort();
	});

window.onkeydown = function(event) {
	if (event.keyCode === 123 || event.altKey || event.shiftKey || event.ctrlKey) {
		event.preventDefault(); 
	}
};
window.oncontextmenu = function(event) {
	event.preventDefault();
};

document.addEventListener("DOMContentLoaded", function() {
	const tabs = document.querySelectorAll('.weekday-bd-tab .nav-link');
	const todayIndex = new Date().getDay();
	const adjustedIndex = (todayIndex + 6) % 7;
	const allContents = document.querySelectorAll('.day-content');
	allContents.forEach((content, index) => {
		if (index === adjustedIndex) {
			content.classList.remove('d-none');
			tabs[index].classList.add('active');
		} else {
			content.classList.add('d-none');
		}
	});
	tabs.forEach(tab => {
		tab.addEventListener('click', function() {
			tabs.forEach(t => {
				t.classList.remove('active');
			});
			const dayClicked = this.dataset.day;
			const dayIndex = '一二三四五六日'.indexOf(dayClicked) + 1;
			allContents.forEach(content => {
				content.classList.add('d-none');
			});
			const dayToShow = 'day-' + dayIndex;
			const dayContent = document.querySelector('.' + dayToShow);
			if (dayContent) {
				dayContent.classList.remove('d-none');
			}
			this.classList.add('active');
		});
	});
});

var MAC = {
	'Url': document.URL,
	'Title': document.title,
	'UserAgent' : function(){
		var ua = navigator.userAgent;
		return {
			'mobile': !!ua.match(/AppleWebKit.*Mobile.*/),
			'ios': !!ua.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/),
			'android': ua.indexOf('Android') > -1 || ua.indexOf('Linux') > -1,
			'iPhone': ua.indexOf('iPhone') > -1 || ua.indexOf('Mac') > -1,
			'iPad': ua.indexOf('iPad') > -1,
			'trident': ua.indexOf('Trident') > -1,
			'presto': ua.indexOf('Presto') > -1,
			'webKit': ua.indexOf('AppleWebKit') > -1,
			'gecko': ua.indexOf('Gecko') > -1 && ua.indexOf('KHTML') == -1,
			'weixin': ua.indexOf('MicroMessenger') > -1
		};
	}(),
	'Hits': {
		'Init': function() {
			if ($('.mac_hits').length == 0) {
				return;
			}
			var $that = $(".mac_hits");

			MAC.Ajax(maccms.path + '/index.php/ajax/hits?mid=' + $that.attr("data-mid") + '&id=' + $that.attr("data-id") + '&type=update', 'get', 'json', '', function(r) {
				if (r.code == 1) {
					$(".mac_hits").each(function(i) {
						$type = $(".mac_hits").eq(i).attr('data-type');
						if ($type != 'insert') {
							$('.' + $type).html(eval('(r.data.' + $type + ')'));
						}
					});
				}
			});
		}
	},
	'Adaptive': function() {
		if (maccms.mob_status == '1' && maccms.url != maccms.wapurl) {
			if (document.domain == maccms.url && MAC.UserAgent.mobile) {
				location.href = location.href.replace(maccms.url, maccms.wapurl);
			} else if (document.domain == maccms.wapurl && !MAC.UserAgent.mobile) {
				location.href = location.href.replace(maccms.wapurl, maccms.url);
			}
		}
	},
	'Ajax': function(url, type, dataType, data, sfun, efun, cfun) {
		type = type || 'get';
		dataType = dataType || 'json';
		data = data || '';
		efun = efun || '';
		cfun = cfun || '';

		$.ajax({
			url: url,
			type: type,
			dataType: dataType,
			data: data,
			timeout: 5000,
			beforeSend: function(XHR) {},
			error: function(XHR, textStatus, errorThrown) {
				if (efun) efun(XHR, textStatus, errorThrown);
			},
			success: function(data) {
				sfun(data);
			},
			complete: function(XHR, TS) {
				if (cfun) cfun(XHR, TS);
			}
		})
	}
}

$(function() {
	MAC.Hits.Init();
	MAC.Adaptive();
});

var fdlhref = location.hostname;
var allowedDomains = ["yinghua6.cc", "yinghua7.cc", "zhuzhudm.cc", "ccfuns.cc", "ffdm.cc", "fengche123.cc", "99dmw.cc", "ffdm1.cc", "ffdm2.cc", "ffdm3.cc"];
var isAllowed = allowedDomains.some(function(domain) {
	return fdlhref.endsWith(domain);
});
if (!isAllowed) {
	top.location.href = "https://www.ffdm.cc";
}